/*
 * Copyright 2021 Ingemar Hedvall
 * SPDX-License-Identifier: MIT
 */
#include "mdf/iattachment.h"

namespace mdf {}  // namespace mdf
