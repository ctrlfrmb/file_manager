/*
 * Copyright 2022 Ingemar Hedvall
 * SPDX-License-Identifier: MIT
 */

#include "mdf/isourceinformation.h"

namespace mdf {}  // namespace mdf