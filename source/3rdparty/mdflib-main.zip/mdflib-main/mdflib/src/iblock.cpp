/*
* Copyright 2022 Ingemar Hedvall
* SPDX-License-Identifier: MIT
*/

#include "mdf/iblock.h"

namespace mdf {



}  // namespace mdf