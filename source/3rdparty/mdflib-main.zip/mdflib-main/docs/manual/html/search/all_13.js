var searchData=
[
  ['valid_5flist_5f_0',['valid_list_',['../classmdf_1_1_i_channel_observer.html#a0252fcfee4667888d7b9c27b1305ad73',1,'mdf::IChannelObserver']]],
  ['value_1',['Value',['../classmdf_1_1_e_tag.html#a618429cdb7939d8131be2a7f5d9e29c9',1,'mdf::ETag::Value(const T &amp;value)'],['../classmdf_1_1_e_tag.html#a683b267cc4b65258b43a230d66dda4af',1,'mdf::ETag::Value() const'],['../classmdf_1_1_e_tag.html#a1a133f407c8ac5cfbc23ef79680e08bf',1,'mdf::ETag::Value(const bool &amp;value)'],['../classmdf_1_1_e_tag.html#a593d3e749f09f6549f211b2828eaafd4',1,'mdf::ETag::Value() const'],['../classmdf_1_1_e_tag.html#a22a117bc0717b9fa045b45b2bfca8b14',1,'mdf::ETag::Value() const']]],
  ['value_2',['value',['../structmdf_1_1_text_conversion.html#abb8dcb08bdb4823c64dc267c17372c7b',1,'mdf::TextConversion']]],
  ['value_5flist_5f_3',['value_list_',['../classmdf_1_1_i_channel_conversion.html#a89939d082c0cc56f1c91bd77011b76df',1,'mdf::IChannelConversion']]],
  ['valuerangetotext_4',['ValueRangeToText',['../namespacemdf.html#aa69a00bf9910fb428ebe4a3d63e6ed89acf735855d80633285b031fce93468a19',1,'mdf']]],
  ['valuerangetovalue_5',['ValueRangeToValue',['../namespacemdf.html#aa69a00bf9910fb428ebe4a3d63e6ed89acfac125f526b65725b6ba6f353f2ffda',1,'mdf']]],
  ['valuetostring_6',['ValueToString',['../classmdf_1_1_i_event.html#aefad1fc487b4ac76e14a4aa48dd11bca',1,'mdf::IEvent']]],
  ['valuetotext_7',['ValueToText',['../namespacemdf.html#aa69a00bf9910fb428ebe4a3d63e6ed89a4fd994499bd4086f0b29736ea6f9d299',1,'mdf']]],
  ['valuetovalue_8',['ValueToValue',['../namespacemdf.html#aa69a00bf9910fb428ebe4a3d63e6ed89a20eef5d1dfda3b66f17b03b6d47e5d6e',1,'mdf']]],
  ['valuetovalueinterpolation_9',['ValueToValueInterpolation',['../namespacemdf.html#aa69a00bf9910fb428ebe4a3d63e6ed89a808b618e35ed2391cfab469e2d99d12a',1,'mdf']]],
  ['variablelength_10',['VariableLength',['../namespacemdf.html#aada23089f38b2f9a6a017ec2b1ec937dacf5e4bc4a94b24088e16c9c3afd40a2a',1,'mdf']]],
  ['version_11',['Version',['../classmdf_1_1_mdf_file.html#a317d4fc5b23edfa6ebba1455c8a23038',1,'mdf::MdfFile']]],
  ['virtual_12',['Virtual',['../namespacemdf_1_1_cn_flag.html#a6f1384f74040b449cb428b24a03e341a',1,'mdf::CnFlag']]],
  ['virtualdata_13',['VirtualData',['../namespacemdf.html#aada23089f38b2f9a6a017ec2b1ec937dabec26578f09660b1b47ec535f0c47c75',1,'mdf']]],
  ['virtualmaster_14',['VirtualMaster',['../namespacemdf.html#aada23089f38b2f9a6a017ec2b1ec937da309ed161ec249f7ffdbac36b65e55b75',1,'mdf']]],
  ['vlsd_5fbuffer_15',['vlsd_buffer',['../structmdf_1_1_sample_record.html#a4a63f6a32a636d7d68a4718b481e4aec',1,'mdf::SampleRecord']]],
  ['vlsd_5fdata_16',['vlsd_data',['../structmdf_1_1_sample_record.html#a83ddac95b1f8a3f9e6ecfdc65d3a500c',1,'mdf::SampleRecord']]],
  ['vlsdchannel_17',['VlsdChannel',['../namespacemdf_1_1_cg_flag.html#a87191dfeab36080d406ad2869471bc6d',1,'mdf::CgFlag']]],
  ['vlsddatastream_18',['VlsdDataStream',['../namespacemdf_1_1_cn_flag.html#aaa0966dc35ade7f95a6e4fcd279ee0ca',1,'mdf::CnFlag']]],
  ['vlsdrecordid_19',['VlsdRecordId',['../classmdf_1_1_i_channel.html#af0097710fe52be6fa446944cd9f126bf',1,'mdf::IChannel::VlsdRecordId(uint64_t record_id) const'],['../classmdf_1_1_i_channel.html#a34f93d53a8257129fbf322861c4b002c',1,'mdf::IChannel::VlsdRecordId() const']]],
  ['vlsdstorage_20',['VlsdStorage',['../namespacemdf.html#a7e87e4f5b259d4a96040c3729bc2d75ca147ee54090dbf77df17c23f9202ad0c3',1,'mdf']]]
];
