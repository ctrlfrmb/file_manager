var searchData=
[
  ['noconversion_0',['NoConversion',['../namespacemdf.html#aa69a00bf9910fb428ebe4a3d63e6ed89a27a2f55c82cd42b2957dd162121d2bb1',1,'mdf']]],
  ['none_1',['None',['../namespacemdf.html#a97db9dc7397318bc42aa8ba07f1880dfa6adf97f83acf6453d4a6a4b1070f3754',1,'mdf::None'],['../namespacemdf.html#a7d8062669e05a387de168820f98d4ff6a6adf97f83acf6453d4a6a4b1070f3754',1,'mdf::None']]]
];
