var searchData=
[
  ['text_0',['text',['../structmdf_1_1_text_conversion.html#a812a09632fe65898bf4d5f34b683eb51',1,'mdf::TextConversion::text'],['../structmdf_1_1_text_range_conversion.html#a9eab63d57ad445d920669481b6588c55',1,'mdf::TextRangeConversion::text']]],
  ['text_5fconversion_5flist_5f_1',['text_conversion_list_',['../classmdf_1_1_i_channel_conversion.html#a4608abe2e371b0f1bafdc08d1ec0d18a',1,'mdf::IChannelConversion']]],
  ['text_5frange_5fconversion_5flist_5f_2',['text_range_conversion_list_',['../classmdf_1_1_i_channel_conversion.html#a8cd52fdb9f836f0107c29f7931aec66b',1,'mdf::IChannelConversion']]],
  ['timestamp_3',['timestamp',['../structmdf_1_1_sample_record.html#a8b95d4a965339e190d873305e5ee9436',1,'mdf::SampleRecord']]]
];
