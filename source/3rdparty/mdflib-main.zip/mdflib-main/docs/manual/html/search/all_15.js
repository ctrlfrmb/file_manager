var searchData=
[
  ['xmlsnippet_0',['XmlSnippet',['../classmdf_1_1_i_meta_data.html#a811452751aafc0d09ccd838fc7fe2fd6',1,'mdf::IMetaData::XmlSnippet(const std::string &amp;text)=0'],['../classmdf_1_1_i_meta_data.html#a6cf79803061f65957c52f6f241dc957c',1,'mdf::IMetaData::XmlSnippet() const =0']]]
];
