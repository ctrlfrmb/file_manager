var searchData=
[
  ['language_0',['Language',['../classmdf_1_1_e_tag.html#a7d2d6a9ef7a10e61c444b869f368434a',1,'mdf::ETag::Language(const std::string &amp;language)'],['../classmdf_1_1_e_tag.html#ae83a161d97582909bbd75b42c9fbb1f2',1,'mdf::ETag::Language() const']]],
  ['lastdatagroup_1',['LastDataGroup',['../classmdf_1_1_i_header.html#a50dc52d8b7b7e6287743effac06bf0c9',1,'mdf::IHeader']]],
  ['latin1toutf8_2',['Latin1ToUtf8',['../classmdf_1_1_mdf_helper.html#a25f5958900a95201a49c558a1aa2d8ea',1,'mdf::MdfHelper']]],
  ['limit_3',['Limit',['../classmdf_1_1_i_channel.html#ab75df87353aaceb8ca1d809a99df7c17',1,'mdf::IChannel::Limit(double min, double max)'],['../classmdf_1_1_i_channel.html#a06e8995a869945f0cfd373350d2a3adc',1,'mdf::IChannel::Limit() const']]],
  ['localtimestamp_4',['LocalTimestamp',['../classmdf_1_1_local_timestamp.html#aa7736c16fd180969c68dde01c3603d03',1,'mdf::LocalTimestamp']]],
  ['logstring_5',['LogString',['../classmdf_1_1_mdf_log_stream.html#a4778a0b16469dc58f0ec7b8e9881bd83',1,'mdf::MdfLogStream']]]
];
