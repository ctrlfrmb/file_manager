var searchData=
[
  ['addattachment_0',['AddAttachment',['../classmdf_1_1_i_event.html#a789c845524ed6b2404d4b7ef11f3b6c4',1,'mdf::IEvent']]],
  ['addattachmentreference_1',['AddAttachmentReference',['../classmdf_1_1_i_channel.html#ab65be17a489e6188f0974084ba306326',1,'mdf::IChannel']]],
  ['addelementlink_2',['AddElementLink',['../classmdf_1_1_i_channel_hierarchy.html#a89bd719a3dee10bfef6ac7340387b2e2',1,'mdf::IChannelHierarchy']]],
  ['addscope_3',['AddScope',['../classmdf_1_1_i_event.html#a15556fb8188002e7aee57f225e861466',1,'mdf::IEvent']]],
  ['addtag_4',['AddTag',['../classmdf_1_1_e_tag.html#a8515961e529cff883e51a187a66ad2ef',1,'mdf::ETag']]],
  ['arraysize_5',['ArraySize',['../classmdf_1_1_i_channel.html#a128de0bc7aa39d1b877481bb4216d410',1,'mdf::IChannel::ArraySize(uint64_t array_size)'],['../classmdf_1_1_i_channel.html#ac16500cdb878b302e69fdc68edd8aa49',1,'mdf::IChannel::ArraySize() const'],['../classmdf_1_1_i_channel_observer.html#ae5b6e85bdf1a75b68d1c84a49c56da60',1,'mdf::IChannelObserver::ArraySize()']]],
  ['attachmentlist_6',['AttachmentList',['../classmdf_1_1_i_channel.html#a30b1815c3a1c78ff8318bbadabf97652',1,'mdf::IChannel']]],
  ['attachments_7',['Attachments',['../classmdf_1_1_i_event.html#afeadb85fff673a9149e26fa08d05121c',1,'mdf::IEvent::Attachments()'],['../classmdf_1_1_i_header.html#ae59da2d5fff2ce7d161d5035be70c109',1,'mdf::IHeader::Attachments()'],['../classmdf_1_1_mdf_file.html#a9350260abd0bec9d12e58bbe1a6ff9e8',1,'mdf::MdfFile::Attachments()']]],
  ['attachobserver_8',['AttachObserver',['../classmdf_1_1_i_sample_observer.html#a1b3f2246ffc18810c5bd0f0ba638a34d',1,'mdf::ISampleObserver']]],
  ['attachsampleobserver_9',['AttachSampleObserver',['../classmdf_1_1_i_data_group.html#aeaa9908c2cbdf59ebe35c70301f85504',1,'mdf::IDataGroup']]],
  ['author_10',['Author',['../classmdf_1_1_i_header.html#a6a8448aeb09eeb780cb7fb992e436085',1,'mdf::IHeader::Author(const std::string &amp;author)=0'],['../classmdf_1_1_i_header.html#a2dee10fa600a14af7637e53e688c90e7',1,'mdf::IHeader::Author() const =0']]],
  ['axisconversionlist_11',['AxisConversionList',['../classmdf_1_1_i_channel_array.html#a8820097d01912970d29ab09adcbd3c47',1,'mdf::IChannelArray::AxisConversionList() const'],['../classmdf_1_1_i_channel_array.html#acdac0f5bf567ceed6762fe68d8d56a19',1,'mdf::IChannelArray::AxisConversionList()']]],
  ['axislist_12',['AxisList',['../classmdf_1_1_i_channel_array.html#aac93a745e21bef7da392cc2ffaf3ebdc',1,'mdf::IChannelArray::AxisList() const'],['../classmdf_1_1_i_channel_array.html#a9058d869e9cf5f58b362796e4fcce22d',1,'mdf::IChannelArray::AxisList()']]],
  ['axisvalues_13',['AxisValues',['../classmdf_1_1_i_channel_array.html#acb69b31f9811450a3dac3a2457a0c358',1,'mdf::IChannelArray::AxisValues() const =0'],['../classmdf_1_1_i_channel_array.html#ae839c33230c82d7b3da2865f07ec3517',1,'mdf::IChannelArray::AxisValues()=0']]]
];
