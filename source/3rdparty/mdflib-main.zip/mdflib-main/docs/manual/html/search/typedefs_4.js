var searchData=
[
  ['mdflogfunction1_0',['MdfLogFunction1',['../namespacemdf.html#ac8fe12a2dfbfeec087a35bbd0eb166d3',1,'mdf']]],
  ['mdflogfunction2_1',['MdfLogFunction2',['../namespacemdf.html#a3d35caffa4b62757fd0790a4abec8b42',1,'mdf']]]
];
