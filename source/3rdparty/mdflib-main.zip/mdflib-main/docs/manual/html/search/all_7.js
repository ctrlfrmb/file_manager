var searchData=
[
  ['header_0',['Header',['../classmdf_1_1_mdf_file.html#a9000a84ff69bf5e5a0d17b936cc57a5b',1,'mdf::MdfFile::Header()'],['../classmdf_1_1_mdf_writer.html#aae1d91dced5a573d6862fc1db77c0468',1,'mdf::MdfWriter::Header()']]]
];
