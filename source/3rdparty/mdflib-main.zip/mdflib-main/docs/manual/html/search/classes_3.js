var searchData=
[
  ['localtimestamp_0',['LocalTimestamp',['../classmdf_1_1_local_timestamp.html',1,'mdf']]]
];
