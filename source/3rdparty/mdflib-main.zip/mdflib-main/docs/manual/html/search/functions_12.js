var searchData=
[
  ['value_0',['Value',['../classmdf_1_1_e_tag.html#a618429cdb7939d8131be2a7f5d9e29c9',1,'mdf::ETag::Value(const T &amp;value)'],['../classmdf_1_1_e_tag.html#a683b267cc4b65258b43a230d66dda4af',1,'mdf::ETag::Value() const'],['../classmdf_1_1_e_tag.html#a1a133f407c8ac5cfbc23ef79680e08bf',1,'mdf::ETag::Value(const bool &amp;value)'],['../classmdf_1_1_e_tag.html#a593d3e749f09f6549f211b2828eaafd4',1,'mdf::ETag::Value() const'],['../classmdf_1_1_e_tag.html#a22a117bc0717b9fa045b45b2bfca8b14',1,'mdf::ETag::Value() const']]],
  ['valuetostring_1',['ValueToString',['../classmdf_1_1_i_event.html#aefad1fc487b4ac76e14a4aa48dd11bca',1,'mdf::IEvent']]],
  ['version_2',['Version',['../classmdf_1_1_mdf_file.html#a317d4fc5b23edfa6ebba1455c8a23038',1,'mdf::MdfFile']]],
  ['vlsdrecordid_3',['VlsdRecordId',['../classmdf_1_1_i_channel.html#af0097710fe52be6fa446944cd9f126bf',1,'mdf::IChannel::VlsdRecordId(uint64_t record_id) const'],['../classmdf_1_1_i_channel.html#a34f93d53a8257129fbf322861c4b002c',1,'mdf::IChannel::VlsdRecordId() const']]]
];
