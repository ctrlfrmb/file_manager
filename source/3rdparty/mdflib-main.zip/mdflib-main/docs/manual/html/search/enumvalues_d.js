var searchData=
[
  ['polynomial_0',['Polynomial',['../namespacemdf.html#aa69a00bf9910fb428ebe4a3d63e6ed89a24ecfbe376a82f09ad48bffc6b8d6a87',1,'mdf']]]
];
