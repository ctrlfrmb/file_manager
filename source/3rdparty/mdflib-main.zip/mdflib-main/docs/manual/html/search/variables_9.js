var searchData=
[
  ['nof_5fvalues_5f_0',['nof_values_',['../classmdf_1_1_i_channel_conversion.html#a40d94e7de622b9b2c34ea4ca3660a983',1,'mdf::IChannelConversion']]]
];
