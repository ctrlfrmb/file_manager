var searchData=
[
  ['unit_0',['Unit',['../classmdf_1_1_e_tag.html#ae34ac912a1f10cb0257365c933a60705',1,'mdf::ETag::Unit(const std::string &amp;unit)'],['../classmdf_1_1_e_tag.html#a4e3a33535dc88d1e9d8ab6a059250185',1,'mdf::ETag::Unit() const'],['../classmdf_1_1_i_channel.html#a36a3b88bc8d1a5844d04289e89e826c4',1,'mdf::IChannel::Unit(const std::string &amp;unit)=0'],['../classmdf_1_1_i_channel.html#ac0d4d05b309f1fdf0428eb1d381887df',1,'mdf::IChannel::Unit() const =0'],['../classmdf_1_1_i_channel_conversion.html#a4469d265e48592ca50e759e758e67ada',1,'mdf::IChannelConversion::Unit(const std::string &amp;unit)=0'],['../classmdf_1_1_i_channel_conversion.html#a41ba68a1f526f260ad770e31671d0dba',1,'mdf::IChannelConversion::Unit() const =0'],['../classmdf_1_1_i_channel_observer.html#a944b4093b9e83896b2687a87618b787e',1,'mdf::IChannelObserver::Unit()']]],
  ['unitref_1',['UnitRef',['../classmdf_1_1_e_tag.html#a0881ba42ab06fb06127c461061220682',1,'mdf::ETag::UnitRef(const std::string &amp;unit_ref)'],['../classmdf_1_1_e_tag.html#acad404eda10b25976f58d957a322e2d6',1,'mdf::ETag::UnitRef() const']]],
  ['username_2',['UserName',['../classmdf_1_1_i_file_history.html#a6a40cce9d4617dfb8074b59b4864d894',1,'mdf::IFileHistory::UserName(const std::string &amp;user)'],['../classmdf_1_1_i_file_history.html#aa8705e037f371b6c121b45589cc0016e',1,'mdf::IFileHistory::UserName() const']]],
  ['utctimestamp_3',['UtcTimestamp',['../classmdf_1_1_utc_timestamp.html#a53c76498a6f7069a58304e1b4360ba8a',1,'mdf::UtcTimestamp']]],
  ['utf16toutf8_4',['Utf16ToUtf8',['../classmdf_1_1_mdf_helper.html#a6619fbbe8a58b58a53c64a804fa90d3d',1,'mdf::MdfHelper']]],
  ['utf8toutf16_5',['Utf8ToUtf16',['../classmdf_1_1_mdf_helper.html#abb37a8dee20837d7e1d973d26f49a9a1',1,'mdf::MdfHelper']]]
];
