---
layout: default
title: MDF Viewer
---

# MDF Viewer

The MDF Viewer is a simple GUI application that show the content of an MDF file.

![Sample MDF viewer](/assets/img/mdfviewer.png)

It can display block information and measured data in either a list or in a graph. The Gnuplot application is
used as plotting tool, so it needs to be installed.