
[TOC]
版本: v1.0.3
## 1. 配置文件概述
在项目中，我们使用了一个名为`fkvrc_tester.json`的配置文件来存储各种配置信息。配置文件主要包含四个部分：`config`、`test_prepare`、`test_case`和`test_finish`。

## 2. 配置项详解
### 2.1 config
这部分包含了项目的基本配置信息，如日志级别(`log_level`)，CAN设备的索引(`device_index`)和通道(`device_channel`)，以及万用表设备的地址(`device_address`)等。

### 2.2 test_prepare
这部分包含了测试准备阶段需要执行的命令。每个命令都是一个对象，包含了命令的类型(`type`)，名称(`name`)，以及延迟(`delay`)。

### 2.3 test_case
这部分包含了测试用例阶段需要执行的命令。每个命令都是一个对象，包含了命令的类型(`type`)，名称(`name`)，以及延迟(`delay`)。

### 2.4 test_finish
[可选节点]这部分包含了测试完成后需要执行的命令。每个命令都是一个对象，包含了命令的类型(`type`)，名称(`name`)，以及延迟(`delay`)。

## 3. 命令详解
命令对象包含了以下通用的属性：指令类型(`type`)，指令名称(`name`)，[可选属性]延时时间(`delay`)。

### 3.1 RSU命令
RSU命令包含以下选项：板卡名称，卡槽，通道，状态，超时时间毫秒。

### 3.2 VISA命令
VISA命令包含以下选项：测量名称（目前仅支持电压）、测试报告标签、nplc参数、量程。

## 4. 配置文件示例
以下是一个示例配置文件：

```json
{
	"config": {
		"log_level": 1,
		"can": {
			"device_index": 0,
			"device_channel": 0
		},
		"multimeter": {
			"device_address": "TCPIP0::192.168.201.1::inst0::INSTR"
		},
		"query": {
			"rsu": true,
			"rsu_wait": 50,
			"visa": true
		}
	},
	"test_prepare": {
		"command": [{
			"type": "BATCH",
			"name": "LOAD_CARD_48CH_2A",
			"slot": 3,
			"channels": [1, 2, 3, 4],
			"statuses": [
				"LOAD1_ON_PWR_NO", "LOAD1_ON_PWR_NO", "LOAD1_ON_PWR_NO", "LOAD1_ON_PWR_NO"
			]
		}
		]
	},
	"test_case": {
		"check_bus": true,
		"counter": 2,
		"command": [{
			"type": "BATCH",
			"rsu_name": "MATRIX_CARD_64X4",
			"rsu_slot": 4,
			"rsu_channels": [
				[1, 58],
				[2, 58],
				[3, 58],
				[4, 58]
			],
			"rsu_statuses": ["BUS_1", "BUS_2"],
			"visa_name": "VOLTAGE",
			"visa_tags": [
				"1",
				"2",
				"3",
				"4"
			],
			"visa_nplc": "100",
			"visa_measuring_range": "AUTO ON"
		}]
	},
	"test_finish": {
		"command": [{
			"type": "RSU",
			"name": "MATRIX_CARD_64X4",
			"slot": 4,
			"channel": 1,
			"status": "RESET_ALL_RELAY"
		},
			{
				"type": "RSU",
				"name": "LOAD_CARD_48CH_2A",
				"slot": 3,
				"channel": 1,
				"status": "RESET_ALL_RELAY"
			}
		]
	}
}
```

## 5. 程序使用说明

### 5.1 fkvrc_tester 使用说明

主程序，用于执行实际测试脚本，运行时依赖Linux版本的周立功USBCANFD200U库（libusbcanfd.so）、keysight万用表操作库（libiovisa.so）、丰柯测试库（libfkvrc.so）。

**硬件设备均使用USB方式收发数据，包括以下设备：RSU机箱、周立功can卡（自测设备USBCANFD200U）、keysight万用表（自测设备34461A）**

CANFD库与万用表库默认用户环境中已安装相关驱动程序，发布版本中不带相关库。

提供以下选项：

### `-h, --help`
显示帮助信息并退出。当使用这个选项时，程序会打印出所有可用的命令行选项及其说明，然后退出。

### `-c, --config`
自动创建系统测试文件。当使用这个选项时，程序会自动生成一个名为fkvrc_tester.json的配置文件。

### `-v, --version`
显示版本号并退出。当使用这个选项时，程序会打印出当前的版本号，然后退出。

### `-f, --file`
通过文件运行测试用例。这个选项需要一个参数，即包含测试用例的文件的路径。当使用这个选项时，程序会读取指定的文件，并根据文件中的内容运行测试用例。

使用方法如下：

```bash
sudo cp lib/* /usr/local/lib/
fkvrc_tester -f fkvrc_tester.json
```

**测试完毕后程序通缉目录下会多出两个文件：测试电压报表文件（fkvrc_tester.csv）、测试过程数据记录日志文件（fkvrc_tester_xxxx.log）**

### 5.2 fkvrc_simulation_tester 使用说明

仿真程序，用于没有设备的情况下，执行测试脚本。可检测脚本正确性，以及收发数据模拟跟踪（随机测试，会模拟失败情形）。

### 5.3 脚本说明

fkvrc_tester.sh、fkvrc_simulation_tester.sh脚本文件方便用户快速测试或模拟仿真。
