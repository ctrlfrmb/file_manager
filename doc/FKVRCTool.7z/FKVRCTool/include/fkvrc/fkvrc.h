﻿/**
 * @file    fkcanfd.h
 * @ingroup figkey
 * @brief
 * @author  leiwei
 * @date    2023.12.27
 * Copyright (c) figkey 2023-2033
 */

#pragma once

#ifndef FIGKEY_VRC_HPP
#define FIGKEY_VRC_HPP

#include "fkdef.h"

#ifdef __cplusplus
extern "C" {
#endif

FKVRC_API_RETURN openAllDevice(const char* configPath);

FKVRC_API_RETURN testAllCase();

FKVRC_API_RETURN closeAllDevice();

FKVRC_API_RETURN pasrseAndRunTestCase(const char* configPath);

FKVRC_API_RETURN openDevice(unsigned int devIdx);

FKVRC_API_RETURN openChannel(unsigned int devChn);

FKVRC_API_RETURN openChannelAndReceive(unsigned int devChn);

FKVRC_API_RETURN runDeviceByChannel(unsigned int devIdx, unsigned int devChn);

FKVRC_API_RETURN closeDevice();

FKVRC_API_RETURN queryCardInfoByPosition(unsigned char pos, unsigned int timeout_ms);

unsigned char showAllCardInfo();

FKVRC_API_RETURN resetCardHardwareByPosition(unsigned char pos, unsigned int timeout_ms) ;

FKVRC_API_RETURN setCardReplyMessageByPosition(unsigned char pos, unsigned int timeout_ms, unsigned char enable) ;

FKVRC_API_RETURN resetCardRelayByPosition(unsigned char pos, unsigned int timeout_ms) ;

unsigned char getCardTypeByPosition(unsigned char pos);

FKVRC_API_RETURN showCardRelayChannel(unsigned char type);

FKVRC_API_RETURN showCardRelayControl(unsigned char type, unsigned char channel);

FKVRC_API_RETURN sendCardCommandByPosition(unsigned char pos, unsigned char channel, unsigned char control, unsigned int timeout_ms) ;


#ifdef __cplusplus
};
#endif

#endif // FIGKEY_VRC_HPP
