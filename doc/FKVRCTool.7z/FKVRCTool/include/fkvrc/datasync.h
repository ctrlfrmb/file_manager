﻿/**
 * @file    datasync.h
 * @ingroup figkey
 * @brief
 * @author  leiwei
 * @date    2023.12.29
 * Copyright (c) figkey 2023-2033
 */

#pragma once

#ifndef FIGKEY_DATA_SYNC_HPP
#define FIGKEY_DATA_SYNC_HPP

#include <condition_variable>
#include <mutex>
#include <array>
#include "fkdef.h"

namespace figkey {
    enum class DataStatus : uint8_t {
        DEFAULT = 0,            //默认状态
        INPUT_CHECK_FAILED,     //输入校验失败
        SEND_MESSAGE_FAILED,    //发送失败
        WAIT_RESPONSE,          //等待响应
        RESPONSE_SUCCESS,       //响应成功
        RESPONSE_CHECK_FAILED,  //响应校验失败
        RESPONSE_ERROR,         //响应错误
        RESPONSE_STATUS_ERROR,  //响应状态错误
        RESPONSE_TIMEOUT        //响应超时
    };

    class DataSync {
    public:
        static constexpr uint8_t MAX_DATA_COUNT = FIGKEY_RSU_CARD_MAX_LENGTH;

        DataSync() ;

        DataStatus sendData(uint8_t index) ;

        DataStatus waitForResponse(uint8_t index, std::chrono::milliseconds timeout) ;

        DataStatus sendDataAndWaitForResponse(uint8_t index, uint32_t timeout);

        DataStatus receiveData(uint8_t index, DataStatus status) ;

    private:
        std::mutex mutex;
        std::condition_variable cv;
        std::array<DataStatus, MAX_DATA_COUNT> dataStatuses;
    };
} // namespace figkey

#endif // FIGKEY_DATA_SYNC_HPP
