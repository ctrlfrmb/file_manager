﻿/**
 * @file    rsu.h
 * @ingroup figkey
 * @brief
 * @author  leiwei
 * @date    2023.12.27
 * Copyright (c) figkey 2023-2033
 */

#pragma once

#ifndef FIGKEY_RSU_CRAD_HPP
#define FIGKEY_RSU_CRAD_HPP

#include "fkdef.h"
#include "datasync.h"
#include <string>
#include <vector>
#include <mutex>
#include <map>

namespace figkey {

    constexpr uint8_t RSUCardRequestCommandHigh{0xC0};
    constexpr uint8_t RSUCardResponseCommandHigh{0xA0};
    constexpr uint8_t RSUCardCommandDifference{0x20};
    constexpr uint8_t RSUCardResponseErrorHigh{0xE0};
    constexpr uint8_t RSUCardCanQueryValue{0x0};
    constexpr uint8_t RSUResetHardwareCommandByte2{0xF0};
    constexpr uint8_t RSUResetHardwareCommandByte3{0x01};
    constexpr uint8_t RSUReplyMessageCommandByte2{0xF2};
    constexpr uint8_t RSUReplyMessageDisable{0x0};
    constexpr uint8_t RSUReplyMessageEnable{0x01};
    constexpr uint8_t RSUResetRelayCommandByte2Byte3{0xCE};

    const std::map<uint8_t, std::string> RSUCardDefine= {
            {FIGKEY_RSU_CARD3_TYPE, "MATRIX_CARD_64X4"},
            {FIGKEY_RSU_CARD5_TYPE, "LOAD_CARD_48CH_2A"},
            {FIGKEY_RSU_CARD6_TYPE, "LOAD_CARD_16CH_12A"},
            {FIGKEY_RSU_CARD7_TYPE, "LOAD_CARD_8CH_30A"},
            {FIGKEY_RSU_CARD8_TYPE, "LOAD_CARD_32CH_6A"}
    };

    struct RSUCardInfo {
        std::string name;
        unsigned char type;
        std::array<uint8_t, FIGKEY_RSU_DATA_LENGTH> data;
    };

    class RSUCard {
    public:
        RSUCard(const RSUCard&) = delete;
        RSUCard(RSUCard&&) = delete;
        RSUCard& operator=(const RSUCard&) = delete;
        RSUCard& operator=(RSUCard&&) = delete;

        static RSUCard& getInstance() {
            static RSUCard obj;
            return obj;
        }

        void setCanChannel(unsigned int channel) { canChannel = channel;}

        bool receiveByCanFD(unsigned int ts, uint8_t id, std::vector<unsigned char>&& data);

        bool queryAllCardInfo(uint32_t timeout_ms) ;

        DataStatus queryCardInfoByPosition(uint8_t position, unsigned int timeout_ms) ;

        unsigned char showAllCardInfo() ;

        DataStatus sendCommandByPosition(uint8_t position, uint8_t byte2, uint8_t byte3, unsigned int timeout_ms) ;

        DataStatus resetHardwareByPosition(uint8_t position, unsigned int timeout_ms) ;

        DataStatus setReplyMessageByPosition(uint8_t position, unsigned int timeout_ms, unsigned char enable) ;

        DataStatus resetRelayByPosition(uint8_t position, unsigned int timeout_ms) ;

        unsigned char getCardType(uint8_t position) ;

        unsigned char getCanIdByCardName(const std::string& name) ;

        bool isGeneralCommand(const std::string& control, uint8_t data[FIGKEY_RSU_DATA_LENGTH]) ;

        bool checkPosition(uint8_t position) ;

        void addCardInfo(uint8_t type, uint8_t position) ;

        bool checkChannel(uint8_t type, uint8_t channel) ;

        unsigned char checkControl(uint8_t type, const std::string& control) ;

    private:

        RSUCard();

        ~RSUCard();

        void clearCardInfo();

        void clearCardInfoByPosition(uint8_t position);

        DataStatus sendMessageByPosition(uint8_t position, uint8_t byte2, uint8_t byte3) ;

#ifdef SELF_TEST_BY_RANDOM
        bool sendCardInfo(uint8_t id, const std::vector<unsigned char>& data);

        bool responseFixedCommand(uint8_t id, const std::vector<unsigned char>& data);

        bool responseAllCommand(uint8_t id, const std::vector<unsigned char>& data);
#endif

        bool parseCardInfo(const std::vector<unsigned char>& data);

        bool parseResponseCommand(const std::vector<unsigned char>& data);

    private:
        unsigned int canChannel;
        DataSync dataSync;

        std::mutex mutexInfo;
        std::map<uint8_t,RSUCardInfo> cardInfo;
    };
} // namespace figkey

#endif // FIGKEY_RSU_CRAD_HPP
