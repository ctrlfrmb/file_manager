﻿/**
 * @file    utils.h
 * @ingroup figkey
 * @brief
 * @author  leiwei
 * @date    2023.12.29
 * Copyright (c) figkey 2023-2033
 */

#pragma once

#ifndef FIGKEY_RSU_UTILS_HPP
#define FIGKEY_RSU_UTILS_HPP

#include "fkdef.h"
#include <vector>
#include <cstdint>
#include <memory>
#include <string>

namespace figkey {

    // Define the log levels
    enum class LogLevel : uint8_t {
        TRACE,
        DEBUG,
        INFO,
        WARN,
        ERROR,
        FATAL
    };

    // 在库的头文件中声明函数
    std::string getLibraryVersion();

    void createJsonConfigFile();

    void setLogLevel(uint8_t level);

    // Function to log a message
    void logMessage(LogLevel level, const char* tag, const std::string& message);

    void initializeEnvironment();

    void uninitializeEnvironment();

    void enableLogToFile(bool enable);

    namespace utils {
#ifdef SELF_TEST_BY_RANDOM
        bool findRequestCanId(uint8_t id);
#endif
        bool findResponseCanId(uint8_t id);

        bool areArraysEqual(const std::vector<unsigned char> &array1, const std::vector<unsigned char> &array2);

        bool sendRSUMessage(unsigned char channel, unsigned char id, unsigned char data[FIGKEY_RSU_DATA_LENGTH]);

        std::string uint8ToHexString(uint8_t value);
    }
} // namespace figkey

#endif // FIGKEY_RSU_UTILS_HPP
