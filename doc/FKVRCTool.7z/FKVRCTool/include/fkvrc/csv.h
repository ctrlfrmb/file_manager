﻿/**
 * @file    csv.h
 * @ingroup figkey
 * @brief
 * @author  leiwei
 * @date    2024.01.09
 * Copyright (c) figkey 2023-2033
 */

#pragma once

#ifndef FIGKEY_CSV_HPP
#define FIGKEY_CSV_HPP

#include <string>
#include <fstream>

namespace figkey {

// 定义一个测试数据的结构体
    struct VisaReadInfo {
        std::string name;
        std::string type;
        std::string result;
        std::string value;
    };

    class CSVWriter {
    public:
        CSVWriter(const std::string& fileName);

        void writeRow(const VisaReadInfo& info);
        virtual ~CSVWriter();
    private:
        std::ofstream mStream;
        unsigned int id_ = 1;  // Automatically incrementing ID.
    };

} // namespace figkey

#endif // FIGKEY_CSV_HPP
