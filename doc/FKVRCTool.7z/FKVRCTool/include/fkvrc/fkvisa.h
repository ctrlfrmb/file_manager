﻿/**
 * @file    visa.h
 * @ingroup figkey
 * @brief
 * @author  leiwei
 * @date    2024.01.04
 * Copyright (c) figkey 2023-2033
 */

#pragma once

#ifndef FIGKEY_VISA_COMMON_HPP
#define FIGKEY_VISA_COMMON_HPP

#include <visa.h>
#include <string>
#include <atomic>
#include <vector>
#include <memory>
#include "csv.h"

namespace figkey {

    class VisaCom
    {
    public:
        VisaCom(const VisaCom&) = delete;
        VisaCom(VisaCom&&) = delete;
        VisaCom& operator=(const VisaCom&) = delete;
        VisaCom& operator=(VisaCom&&) = delete;

        static VisaCom& getInstance() {
            static VisaCom obj;
            return obj;
        }

        bool openInstrument(const std::string& resource);

        std::vector<std::string> findAllResources();

        bool readVoltage(const std::string& tag, const std::string& nplc, const std::string& range);
        double readResistance();

        bool closeInstrument();

    private:
        VisaCom()=default;
        ~VisaCom();

    private:
        ViSession defaultRM{0};
        ViSession instr{0};

        std::atomic_bool isOpen{false};

        std::unique_ptr<CSVWriter> csvWriter{nullptr};
    };

} // namespace figkey

#endif // FIGKEY_VISA_COMMON_HPP
