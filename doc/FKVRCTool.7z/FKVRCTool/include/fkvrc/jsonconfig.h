﻿/**
 * @file    jsonconfig.h
 * @ingroup figkey
 * @brief
 * @author  leiwei
 * @date    2024.01.04
 * Copyright (c) figkey 2023-2033
 */

#pragma once

#ifndef FIGKEY_JSON_CONFIG_HPP
#define FIGKEY_JSON_CONFIG_HPP

#include <string>
#include <optional>
#include "json.hpp"
#include "fkdef.h"

namespace figkey {
    struct Command {
        FKVRC_MESSAGE_TYPE type{FKVRC_MESSAGE_TYPE_UNKNOWN};
        uint32_t delay{50};
        std::string name;
        std::optional<uint8_t> slot;
        std::optional<uint8_t> channel;
        std::optional<std::string> status;
        std::optional<uint32_t> timeout;
        std::optional<std::string> tag;
        std::optional<std::string> nplc;
        std::optional<std::string> range;
    };

    class JsonConfig {
    public:
        // Singleton instance
        static JsonConfig& getInstance();

        // Delete copy and move constructors and assignment operators
        JsonConfig(const JsonConfig&) = delete;
        JsonConfig(JsonConfig&&) = delete;
        JsonConfig& operator=(const JsonConfig&) = delete;
        JsonConfig& operator=(JsonConfig&&) = delete;

        // Method to check if a file exists
        bool doesFileExist(const std::string& filePath);

        // Method to parse a JSON file
        bool parseJsonFile(const std::string& filePath);

        void getLogLevel();

        // Method to get the CAN configuration
        bool getCanConfig(uint8_t& devIdx, uint8_t& devChn);

        // Method to get the multimeter configuration
        bool getMultimeterConfig(std::string& address);

        bool enableQueryRSU(uint32_t& timeout_ms);

        bool enableQueryVISA();

        bool enableQueryCAN();

        Command getRSUCommand(const nlohmann::json& json);
        Command getVISACommand(const nlohmann::json& json);

        bool getBatchRSUCommand(const nlohmann::json& json, std::vector<Command>& commands);

        std::vector<Command> getRSUCommands(const nlohmann::json& json, size_t &statusLength);
        std::vector<Command> getVISACommands(const nlohmann::json& json);
        bool combineCommands(const nlohmann::json& json, std::vector<Command>& commands);

        int parseTestPrepare(std::vector<Command>& commands);

        bool parseTestCase(uint32_t& counter, std::vector<Command>& commands);

        bool parseTestFinish(std::vector<Command>& commands);

    private:
        // Private constructor for singleton
        JsonConfig();
        ~JsonConfig();

        bool checkBus(const std::vector<Command>& commands);

        nlohmann::json jsonObj;
    };

} // namespace figkey

#endif // FIGKEY_JSON_CONFIG_HPP
