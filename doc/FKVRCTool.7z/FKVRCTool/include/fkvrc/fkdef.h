﻿/**
 * @file    fkrsudef.h
 * @ingroup figkey
 * @brief
 * @author  leiwei
 * @date    2024.01.02
 * Copyright (c) figkey 2023-2033
 */

#pragma once

#ifndef FIGKEY_VRC_DEFINE_HPP
#define FIGKEY_VRC_DEFINE_HPP

#ifdef __cplusplus
extern "C" {
#endif

#define FIGKEY_JSON_CONFIG_PATH "fkvrc_tester.json"
#define FIGKEY_CSV_FILE_PATH "fkvrc_tester.csv"
#define FIGKEY_LOG_TAG_SYSTEM "[system] "
#define FIGKEY_LOG_TAG_CONFIG "[config] "
#define FIGKEY_LOG_TAG_CAN "[can] "
#define FIGKEY_LOG_TAG_RSU "[rsu] "
#define FIGKEY_LOG_TAG_VISA "[visa] "
#define FIGKEY_LOG_TAG_TEST "[test] "
#define FIGKEY_LOG_USAGE_SEPARATOR "#"

#define FIGKEY_RSU_DATA_LENGTH 4
#define FIGKEY_CANFD_DATA_MAX_LENGTH 64
#define FIGKEY_VISA_DATA_MAX_LENGTH 64

#define FIGKEY_RSU_CARD_MAX_LENGTH 0x14
#define FIGKEY_RSU_CARD3_TYPE 0xC3
#define FIGKEY_RSU_CARD5_TYPE 0xC5
#define FIGKEY_RSU_CARD6_TYPE 0xC6
#define FIGKEY_RSU_CARD7_TYPE 0xC7
#define FIGKEY_RSU_CARD8_TYPE 0xC8

#define FIGKEY_RSU_CARD_TYPE_UNKNOWN 0x0
#define FIGKEY_RSU_CONTROL_STATUS_UNKNOWN 0xFF
#define FIGKEY_RSU_COMMAND_TIMEOUT 100

enum FKVRC_API_RETURN : unsigned char {
    FKVRC_NO_ERROR = 0x0,
    FKVRC_OPEN_CONFIG_FILE_FAILED,
    FKVRC_PARSE_DEVICE_CONFIG_FAILED,
    FKVRC_PARSE_TEST_PREPARE_FAILED,
    FKVRC_PARSE_TEST_CASE_FAILED,
    FKVRC_PARSE_TEST_FINISH_FAILED,
    FKVRC_CHECK_RSU_COMMAND_FAILED,
    FKVRC_CHECK_VISA_COMMAND_FAILED,
    FKVRC_OPEN_CAN_FAILED,
    FKVRC_START_CAN_CHANNEL_FAILED,
    FKVRC_START_CAN_RECEIVE_FAILED,
    FKVRC_SEND_CAN_MESSAGE_ERROR,
    FKVRC_CLOSE_CAN_FAILED,
    FKVRC_OPEN_VISA_FAILED,
    FKVRC_CLOSE_VISA_FAILED,
    FKVRC_QUERY_ALL_CARD_ERROR,
    FKVRC_INPUT_CARD_POSITION_ERROR,  //输入卡槽位置错误
    FKVRC_INPUT_CARD_TYPE_ERROR,      //输入卡槽类型错误
    FKVRC_INPUT_CARD_CHANNEL_ERROR,   //输入卡槽通道错误
    FKVRC_INPUT_CARD_CONTROL_ERROR,   //输入BUS、LOAD控制错误
    FKVRC_INPUT_CHECK_FAILED,         //输入校验失败
    FKVRC_SEND_MESSAGE_FAILED,        //发送失败
    FKVRC_RESPONSE_CHECK_FAILED,      //响应校验失败
    FKVRC_RESPONSE_ERROR,             //响应错误
    FKVRC_RESPONSE_STATUS_ERROR,      //响应状态错误
    FKVRC_RESPONSE_TIMEOUT,           //响应超时
    FKVRC_UNKNOWN                     //未知错误
};

enum FKVRC_RSU_GENARL_COMMAND : unsigned char {
    FKVRC_RSU_RESET_HARDWARE= 0xF0,
    FKVRC_RSU_REPLY_OFF = 0xF1,
    FKVRC_RSU_REPLY_ON = 0xF2,
    FKVRC_RSU_RESET_ALL_RELAY = 0xCE
};

enum FKVRC_C3_CHANNEL_BOUND : unsigned char {
    FKVRC_C3_CHANNEL_START = 0x01,
    FKVRC_C3_CHANNEL_END = 0x40
};

enum FKVRC_C3_BUS_STATUS : unsigned char {
    FKVRC_C3_BUS_OFF = 0x0,
    FKVRC_C3_BUS_1 = 0x01,
    FKVRC_C3_BUS_2 = 0x02,
    FKVRC_C3_BUS_3 = 0x03,
    FKVRC_C3_BUS_4 = 0x04
};

enum FKVRC_C3_BUS_CONTROL : unsigned char {
    FKVRC_C3_BUS_CONTROL_ALL_OFF = 0x0,
    FKVRC_C3_BUS_CONTROL_ALL_ON = 0x0F
};

enum FKVRC_C5_CHANNEL_BOUND : unsigned char {
    FKVRC_C5_CHANNEL_START = 0x01,
    FKVRC_C5_CHANNEL_END = 0x30
};

enum FKVRC_C5_LOAD_CONTROL : unsigned char {
    FKVRC_C5_LOAD_OFF = 0x0,
    FKVRC_C5_LOAD1_ON_PWR_NC = 0x10,
    FKVRC_C5_LOAD1_ON_PWR_NO = 0x11,
    FKVRC_C5_LOAD2_ON_PWR_NC = 0x20,
    FKVRC_C5_LOAD2_ON_PWR_NO = 0x21
};

enum FKVRC_C6_CHANNEL_BOUND : unsigned char {
    FKVRC_C6_CHANNEL_START = 0x01,
    FKVRC_C6_CHANNEL_END = 0x10
};

enum FKVRC_C6_LOAD_CONTROL : unsigned char {
    FKVRC_C6_LOAD_OFF = 0x0,
    FKVRC_C6_LOAD_ON_PWR_NC = 0x10,
    FKVRC_C6_LOAD_ON_PWR_NO = 0x11
};

enum FKVRC_C7_CHANNEL_BOUND : unsigned char {
    FKVRC_C7_CHANNEL_START = 0x01,
    FKVRC_C7_CHANNEL_END = 0x08
};

enum FKVRC_C7_LOAD_CONTROL : unsigned char {
    FKVRC_C7_LOAD_OFF = 0x0,
    FKVRC_C7_LOAD_ON = 0x10
};

enum FKVRC_C8_CHANNEL_BOUND : unsigned char {
    FKVRC_C8_CHANNEL_START = 0x01,
    FKVRC_C8_CHANNEL_END = 0x20
};

enum FKVRC_C8_LOAD_CONTROL : unsigned char {
    FKVRC_C8_LOAD_OFF = 0x0,
    FKVRC_C8_LOAD_ON_PWR_NC = 0x10,
    FKVRC_C8_LOAD_ON_PWR_NO = 0x11
};

enum FKVRC_MESSAGE_TYPE : unsigned char {
    FKVRC_MESSAGE_RSU = 0x0,
    FKVRC_MESSAGE_VISA,
    FKVRC_MESSAGE_TYPE_UNKNOWN
};

enum FKVRC_MESSAGE_VISA_TYPE : unsigned char {
    FKVRC_MESSAGE_VISA_VOLTAGE = 0x0,
    FKVRC_MESSAGE_VISA_RESISTANCE,
    FKVRC_MESSAGE_VISA_CURRENT
};

struct FKVRCMessageRSUInfo {
    unsigned char id;
    unsigned char data[FIGKEY_RSU_DATA_LENGTH];
    unsigned int timeout;
};

struct FKVRCMessageVisaInfo {
    FKVRC_MESSAGE_VISA_TYPE type;
    char tag[FIGKEY_VISA_DATA_MAX_LENGTH];
    char nplc[FIGKEY_VISA_DATA_MAX_LENGTH];
    char range[FIGKEY_VISA_DATA_MAX_LENGTH];
};

struct FKVRCMessageInfo {
    FKVRC_MESSAGE_TYPE type;
    union {
        FKVRCMessageRSUInfo rsu;
        FKVRCMessageVisaInfo visa;
    };
    unsigned int delay;
};


#ifdef __cplusplus
};
#endif

#endif // FIGKEY_VRC_DEFINE_HPP
