﻿/**
 * @file    canfd.h
 * @ingroup figkey
 * @brief
 * @author  leiwei
 * @date    2023.12.26
 * Copyright (c) figkey 2023-2033
 */

#pragma once

#ifndef FIGKEY_CANFD_COMMON_HPP
#define FIGKEY_CANFD_COMMON_HPP

#include "zcan.h"
#include <vector>
#include <atomic>
#include <string>
#include <functional>

namespace figkey {
    constexpr U32 DevUsbCanFD200UType{33};
    constexpr U32 DevUsbCanFD200UIndex{0};
    constexpr U32 ReceiveCanMessageTimeout{100};

    using ReceiveCallback = std::function<bool(unsigned int ts, uint8_t, std::vector<unsigned char>)>;

    enum class CanFDStatus : uint8_t {
        DEFAULT = 0,            //默认状态
        DEVICE_OPENED,          //设备已打开
        CHANNEL_STARTED         //通道已启动
    };

    /**
     * @class CanFDCom
     * @brief 用于发送 CAN FD 消息的类。
     *        封装了与周立功 CAN FD 设备通信所需的基本操作。
     */
    class CanFDCom {
    public:
        CanFDCom(const CanFDCom&) = delete;
        CanFDCom(CanFDCom&&) = delete;
        CanFDCom& operator=(const CanFDCom&) = delete;
        CanFDCom& operator=(CanFDCom&&) = delete;

        static CanFDCom& getInstance() {
            static CanFDCom obj;
            return obj;
        }

        void setReceiveCallback(ReceiveCallback callback);

        bool openDevice(U32 index=DevUsbCanFD200UIndex);

        bool openChannel(U32 channel) ;

        bool setTxTimeout(U32 timeout=2000) ;

        bool startReceive(U32 timeout=ReceiveCanMessageTimeout) ;

        bool send(ZCAN_20_MSG&& canMsg);

        void receive(U32 timeout);

        bool closeDevice();

    private:

        CanFDCom();

        ~CanFDCom();

        bool isValid(CanFDStatus status, const std::string& prompt, const std::string& err) const;

    private:
        U32 devType; ///< 设备类型。
        U32 devIndex; ///< 设备索引。
        U32 devChannel;
        std::atomic<CanFDStatus> devStatus; ///< 设备状态。

        std::atomic<bool> receiveRun;
        ReceiveCallback receiveCallback;
    };

} // namespace figkey

#endif // FIGKEY_CANFD_COMMON_HPP
