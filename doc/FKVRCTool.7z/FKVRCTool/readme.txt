项目名称：FKVRCTool v1.0.3

项目简介：
FKVRCTool v1.0.3是一个用于电压测试的项目。

目录结构：
- FKVRCTool_v1.0.3：项目的主目录
  - FKVRCTool说明文档.pdf：项目的使用说明文档
  - ReleaseNote.txt：项目的版本信息文档
  - RSU CAN总线通讯协议 230515.pdf：项目的CAN总线通讯协议文档
  - fkvrc_tester.json：项目的测试脚本文件
  - bin：项目的可执行文件目录
    - fkvrc_tester：项目的执行主文件
    - fkvrc_tester.sh：项目快速测试执行脚本
    - fkvrc_simulation_tester: 项目的仿真测试执行主文件
    - fkvrc_simulation_tester.sh：项目快速仿真测试执行脚本
  - lib：项目的库文件目录
    - libfkvrc.so：项目的库文件
  - lib_simulation：项目的仿真库文件目录
    - libfkvrc.so：项目的仿真库文件
  - test：项目的实测数据目录

使用说明：
请参阅`FKVRCTool说明文档.pdf`文件。

版本信息：
请参阅`ReleaseNote.txt`文件。

