#!/bin/bash
# 本脚本用于Ubuntu系统自动化编译

set -e

# 获取输入参数
param=$1

# 根据输入参数选择编译选项
if [ "$param" == "1" ]; then
    cmake_option="-DCMAKE_BUILD_TYPE=Debug -DSELF_TEST_NO_DEVICE=ON -DENABLE_SELF_TEST=ON"
else
    cmake_option="-DCMAKE_BUILD_TYPE=Debug -DSELF_TEST_NO_DEVICE=OFF -DENABLE_SELF_TEST=OFF"
fi

# 定义变量
FKVRCTool_dir="$(pwd)/FKVRCTool_v1.0.3"
# 检查目录是否存在，如果不存在则创建
if [ ! -d "$FKVRCTool_dir" ]; then
  mkdir -p "$FKVRCTool_dir"
fi
echo "=== FKVRCTool_dir: $FKVRCTool_dir ==="

# 获取脚本所在路径
function get_script_dir(){
    # echo `pwd`
    wp=`pwd`
    # echo $0
    fp=$0
    dirp=`dirname $fp`
    # echo $dirp
    scrip_dir=${wp}/${dirp}
    # echo $scrip_dir
}

# 获取脚本所在路径
get_script_dir $0
if [ $? != 0 ]
then
    echo "获取脚本路径函数异常!"
    exit 1
fi

# 进到脚本所在目录
cd $scrip_dir

if [ -d build ]
then
    rm -rf build/*
else
    mkdir build
fi

cd build

# build here
cmake ${cmake_option} -DCMAKE_INSTALL_PREFIX=$FKVRCTool_dir ../

make -j8
make install

chmod -R 755 $FKVRCTool_dir

# 检查目录是否存在
if [ ! -d "$FKVRCTool_dir" ]; then
  echo "Directory $FKVRCTool_dir does not exist."
  exit 1
fi

# 压缩目录
#tar -czf "$FKVRCTool_dir.tar.gz" "$FKVRCTool_dir"
#echo "Directory $FKVRCTool_dir has been compressed to $FKVRCTool_dir.tar.gz."

cd ..
if [ -d build ]
then
    rm -rf build
fi

echo "=== Done ==="
