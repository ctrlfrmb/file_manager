﻿#include "fkvisa.h"
#include "utils.h"
#include <cstdio>
#include <cstring>
#include <thread>
#include <chrono>

namespace figkey {

#ifdef SELF_TEST_NO_DEVICE
    bool VisaCom::openInstrument(const std::string &/*resource*/) {
        csvWriter = std::make_unique<CSVWriter>(FIGKEY_CSV_FILE_PATH);
        if (!csvWriter)
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_VISA, "create csv writer failed: "+std::string(FIGKEY_CSV_FILE_PATH));
        else
            logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, "create csv writer success: "+std::string(FIGKEY_CSV_FILE_PATH));
        isOpen = true;
        return true;
    }
#else
    bool VisaCom::openInstrument(const std::string &resource) {
        ViStatus status = viOpenDefaultRM(&defaultRM);
        if (status < VI_SUCCESS) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_VISA, "open default resource manager failed, Error code: "+std::to_string(status));
            return false;
        }

        status = viOpen(defaultRM, (ViRsrc)resource.c_str(), VI_NO_LOCK, 0, &instr);
        if (status < VI_SUCCESS)
        {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_VISA, "There was a problem opening the connection to the instrument, Error code: "+std::to_string(status));
            return false;
        }

        csvWriter = std::make_unique<CSVWriter>(FIGKEY_CSV_FILE_PATH);
        if (!csvWriter)
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_VISA, "create csv writer failed: "+std::string(FIGKEY_CSV_FILE_PATH));
        else
            logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, "create csv writer success: "+std::string(FIGKEY_CSV_FILE_PATH));

        isOpen = true;
        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, "open multimeter success, resource: "+resource);

        for (int i = 0; i < 3; ++i) {
            status = viWrite(instr, (ViBuf) ":*RST;:*IDN?;", 14, VI_NULL);
            if (status >= VI_SUCCESS)
                break;
        }
        return true;
    }
#endif

    bool VisaCom::closeInstrument() {
        isOpen = false;

        if (csvWriter) {
            csvWriter.reset();
            logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, "close csv writer success");
        }

        if (instr) {
            viClose(instr);
            instr = VI_NULL;
            logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, "close multimeter success");
        }
        if (defaultRM) {
            viClose(defaultRM);
            defaultRM = VI_NULL;
        }

        return true;
    }

    VisaCom::~VisaCom() {
        closeInstrument();
    }

    std::vector<std::string> VisaCom::findAllResources() {
        ViStatus status = viOpenDefaultRM(&defaultRM);
        if (status < VI_SUCCESS) {
            return {};  // 出错时返回一个空vector
        }

        ViSession   findList;
        ViUInt32    numInstrs;
        ViChar      instrDescriptor[VI_FIND_BUFLEN];
        std::vector<std::string> resources;

        status = viFindRsrc(defaultRM, "?*", &findList, &numInstrs, instrDescriptor);
        if (status < VI_SUCCESS) {
            return {};
        }

        resources.emplace_back(instrDescriptor);

        for (ViUInt32 i = 1; i < numInstrs; ++i) {
            status = viFindNext(findList, instrDescriptor);
            if (status >= VI_SUCCESS) {
                resources.emplace_back(instrDescriptor);
            }
        }

        viClose(findList);

        for (auto& resource : resources) {
            logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, "find multimeter resource: "+resource);
        }
        return resources;
    }

    bool VisaCom::readVoltage(const std::string& tag, const std::string& nplc, const std::string& /*range*/) {
        double voltage{-1.0};
        ViStatus status{VI_SUCCESS};
#ifndef SELF_TEST_NO_DEVICE
        if (!isOpen) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_VISA, "multimeter is not open");
            return false;
        }
//        {
//            for (int i = 0; i < 3; ++i) {
//                status = viWrite(instr, (ViBuf) ":FUNC \"VOLT:DC\";:VOLT:DC:RANG:AUTO ON;", 39, VI_NULL);
//                if (status >= VI_SUCCESS) {
//                    logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, tag + " command execute success for :FUNC \"VOLT:DC\";:VOLT:DC:RANG:AUTO ON;");
//                    break;
//                }
//            }
//        }

        if (!nplc.empty()) {
            char volNplc[64];
            snprintf(volNplc, sizeof(volNplc), ":VOLT:IMP:AUTO ON;:VOLT:NPLC %s;", nplc.c_str());
            for (int i = 0; i < 3; ++i) {
                status = viWrite(instr, (ViBuf) volNplc, (ViUInt32) strlen(volNplc), VI_NULL);
                if (status >= VI_SUCCESS) {
                    logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, tag + " command execute success for "+ volNplc);
                    break;
                }
            }
        }

//        if (!range.empty()) {
//            char volRange[32];
//            snprintf(volRange, 32, "RES:RANG:%s", range.c_str());
//            for (int i = 0; i < 3; ++i) {
//                status = viWrite(instr, (ViBuf) volRange, (ViUInt32) strlen(volRange), VI_NULL);
//                if (status >= VI_SUCCESS) {
//                    logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, tag + " command execute success for "+ volRange);
//                }
//            }
//        }

        for (int i = 0; i < 3; ++i) {
            //viWrite(instr, (ViBuf) ":SAMP:COUN 1;:TRIG:SOUR IMM;:READ?;", 36, VI_NULL);
            viWrite(instr, (ViBuf) "MEAS:VOLT:DC?", 13, VI_NULL);

            ViChar buffer[256];
            status = viRead(instr, (ViBuf) buffer, sizeof(buffer), VI_NULL);
            if (status >= VI_SUCCESS) {
                voltage = atof(buffer);
                break;
            }
        }

        // 发送重置指令到仪器
        // ViUInt32 retCount;
        // viWrite(instr, (ViBuf)"*RST", 5, &retCount); // Reset to default settings
#else
        if (!nplc.empty()) {
           logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, tag + " command execute success for nplc "+ nplc);
        }
#endif
        if (csvWriter) {
            VisaReadInfo info{tag, "Voltage", (status < VI_SUCCESS) ? "Failed" : "Success", std::to_string(voltage)};
            csvWriter->writeRow(info);
        }

        if (status < VI_SUCCESS) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_VISA,
                       tag + " read voltage failed, error code: " + std::to_string(status));
            return false;
        }

        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_VISA, tag + " read voltage: " + std::to_string(voltage));
        return true;
    }

    double VisaCom::readResistance() {
        viWrite(instr, (ViBuf)"MEAS:RES?\n", 10, VI_NULL);

        ViChar buffer[256];
        viRead(instr, (ViBuf)buffer, 256, VI_NULL);

        return atof(buffer);
    }
}
