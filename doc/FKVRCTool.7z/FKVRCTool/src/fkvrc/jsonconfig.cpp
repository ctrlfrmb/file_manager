﻿#include "jsonconfig.h"
#include "utils.h"
#include <fstream>
#include <iostream>

namespace figkey {

    // Singleton instance
    JsonConfig &JsonConfig::getInstance() {
        static JsonConfig instance;
        return instance;
    }

    JsonConfig::JsonConfig() {
        initializeEnvironment();
    }

    JsonConfig::~JsonConfig() {
        uninitializeEnvironment();
    }

    // Method to check if a file exists
    bool JsonConfig::doesFileExist(const std::string &filePath) {
        std::ifstream file(filePath);
        return file.good();
    }

    // Method to parse a JSON file
    bool JsonConfig::parseJsonFile(const std::string &filePath) {
        try {
            std::ifstream file(filePath);
            if (file.good()) {
                file >> jsonObj;
                logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_CONFIG, "parse json file " + filePath + " success");

                getLogLevel();
                return true;
            }
        } catch (nlohmann::json::parse_error &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse json file " + filePath + " failed, " + e.what());
            return false;
        }

        logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse json file " + filePath + " failed");
        return false;
    }

    void JsonConfig::getLogLevel() {
        try {
            auto level = jsonObj["config"]["log_level"];
            if (nullptr != level) {
                setLogLevel(level);
            }
        }
        catch (nlohmann::json::type_error &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, std::string("get log level failed, ") + e.what());
        }
    }

    // Method to get the CAN configuration
    bool JsonConfig::getCanConfig(uint8_t &devIdx, uint8_t &devChn) {
        try {
            auto index = jsonObj["config"]["can"]["device_index"];
            auto channel = jsonObj["config"]["can"]["device_channel"];
            if (nullptr != index && nullptr != channel) {
                devIdx = index;
                devChn = channel;
                return true;
            }
        }
        catch (nlohmann::json::type_error &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, std::string("get can config failed, ") + e.what());
            return false;
        }

        logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG,
                   "get can config failed, like {\"can\":{\"device_index\":0,\"device_channel\":0}}");
        return false;
    }

    // Method to get the multimeter configuration
    bool JsonConfig::getMultimeterConfig(std::string &devAddr) {
        try {
            auto address = jsonObj["config"]["multimeter"]["device_address"];
            if (nullptr != address) {
                devAddr = address;
                return true;
            }
        }
        catch (nlohmann::json::type_error &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG,
                       std::string("get multimeter config failed, ") + e.what());
            return false;
        }

        logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG,
                   "get multimeter config failed, like {\"multimeter\":{\"device_address\": \"USB::0x1234::0x5678::A22-5::INSTR\"}}");
        return false;
    }

    bool JsonConfig::enableQueryRSU(uint32_t &timeout_ms) {
        try {
            auto rsu = jsonObj["config"]["query"]["rsu"];
            if (nullptr == rsu)
                return false;

            auto timeout = jsonObj["config"]["query"]["rsu_wait"];
            if (nullptr != timeout)
                timeout_ms = timeout;

            return rsu;
        }
        catch (nlohmann::json::type_error &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG,
                       std::string("get query config tag rsu failed, ") + e.what());
        }

        return false;
    }

    bool JsonConfig::enableQueryVISA() {
        try {
            auto visa = jsonObj["config"]["query"]["visa"];
            if (nullptr == visa)
                return false;

            return visa;
        }
        catch (nlohmann::json::type_error &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG,
                       std::string("get query config tag visa failed, ") + e.what());
        }

        return false;
    }

    bool JsonConfig::enableQueryCAN() {
        try {
            auto can = jsonObj["config"]["query"]["can"];
            if (nullptr == can)
                return false;

            return can;
        }
        catch (nlohmann::json::type_error &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG,
                       std::string("get query config tag can failed, ") + e.what());
        }

        return false;
    }

    Command JsonConfig::getRSUCommand(const nlohmann::json &json) {
        Command cmd;
        cmd.type = FKVRC_MESSAGE_TYPE_UNKNOWN;

        try {
            if (!json.contains("name") || !json["name"].is_string()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU command failed: 'name' tag is missing or is not a string.");
                return cmd;
            }
            if (!json.contains("slot") || !json["slot"].is_number_unsigned()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU command failed: 'slot' tag is missing or is not an unsigned number.");
                return cmd;
            }
            if (!json.contains("channel") || !json["channel"].is_number_unsigned()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU command failed: 'channel' tag is missing or is not an unsigned number.");
                return cmd;
            }
            if (!json.contains("status") || !json["status"].is_string()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU command failed: 'status' tag is missing or is not a string.");
                return cmd;
            }

            cmd.type = FKVRC_MESSAGE_RSU;
            cmd.name = json["name"].get<std::string>();
            cmd.slot = json["slot"].get<uint8_t>();
            cmd.channel = json["channel"].get<uint8_t>();
            cmd.status = json["status"].get<std::string>();

            cmd.delay = json.value("delay", 50);
            if (json.contains("timeout") && !json["timeout"].is_null()) {
                if (!json["timeout"].is_number_unsigned()) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU command failed: 'timeout' tag is not an unsigned number.");
                    return cmd;
                }
                cmd.timeout = json["timeout"].get<uint32_t>();
            }
        } catch (const nlohmann::json::exception &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU command failed: JSON parsing error or type mismatch: " + std::string(e.what()));
        }

        return cmd;
    }

    Command JsonConfig::getVISACommand(const nlohmann::json &json) {
        Command cmd;
        cmd.type = FKVRC_MESSAGE_TYPE_UNKNOWN;

        try {
            if (!json.contains("name") || !json["name"].is_string()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse VISA command failed: 'name' tag is missing or is not a string.");
                return cmd;
            }
            if (!json.contains("tag") || !json["tag"].is_string()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse VISA command failed: 'tag' tag is missing or is not a string.");
                return cmd;
            }
            if (!json.contains("nplc") || !json["nplc"].is_string()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse VISA command failed: 'nplc' tag is missing or is not a string.");
                return cmd;
            }

            cmd.type = FKVRC_MESSAGE_VISA;
            cmd.name = json["name"].get<std::string>();
            cmd.tag = json["tag"].get<std::string>();
            cmd.nplc = json["nplc"].get<std::string>();

            cmd.delay = json.value("delay", 50);
            if (json.contains("measuring_range") && !json["measuring_range"].is_null()) {
                if (!json["measuring_range"].is_string()) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse VISA command failed: 'measuring_range' tag is not a string.");
                    return cmd;
                }
                cmd.range = json["measuring_range"].get<std::string>();
            }
        } catch (const nlohmann::json::exception &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse VISA command failed: JSON parsing error or type mismatch: " + std::string(e.what()));
        }

        return cmd;
    }

    bool JsonConfig::getBatchRSUCommand(const nlohmann::json &json, std::vector<Command> &commands) {
        try {
            if (!json.contains("channels") || !json["channels"].is_array() || json["channels"].empty()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch RSU command failed: 'channels' tag is missing or is not an array or is empty.");
                return false;
            }

            if (!json.contains("statuses") || !json["statuses"].is_array() || json["statuses"].empty() || json["statuses"].size() != json["channels"].size()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch RSU command failed: 'statuses' tag is missing or is not an array or is empty or does not match the size of 'channels'.");
                return false;
            }

            if (!json.contains("name") || !json["name"].is_string()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch RSU command failed: 'name' tag is missing or is not a string.");
                return false;
            }

            if (!json.contains("slot") || !json["slot"].is_number_unsigned()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch RSU command failed: 'slot' tag is missing or is not an unsigned number.");
                return false;
            }

            Command cmd;
            cmd.type = FKVRC_MESSAGE_RSU;
            cmd.name = json["name"].get<std::string>();
            cmd.slot = json["slot"].get<uint8_t>();
            auto channels = json["channels"];
            auto statuses = json["statuses"];
            for (size_t i = 0; i < channels.size(); ++i) {
                if (!channels[i].is_number_unsigned() || !statuses[i].is_string()) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch RSU command failed: Type mismatch for 'channels' or 'statuses' at index " + std::to_string(i) + ".");
                    return false;
                }
                cmd.channel = channels[i].get<uint8_t>();
                cmd.status = statuses[i].get<std::string>();

                commands.push_back(cmd);
            }
        }
        catch (const nlohmann::json::exception &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch RSU command failed: JSON parsing error or type mismatch: " + std::string(e.what()));
            return false;
        }

        return !commands.empty();
    }

    std::vector<Command> JsonConfig::getRSUCommands(const nlohmann::json &json, size_t &statusLength) {
        std::vector<Command> commands;
        try {
            if (!json.contains("rsu_statuses") || !json["rsu_statuses"].is_array() || json["rsu_statuses"].empty()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU commands failed: 'rsu_statuses' tag is missing or is not an array or is empty.");
                return commands;
            }
            statusLength = json["rsu_statuses"].size();

            if (!json.contains("rsu_channels") || !json["rsu_channels"].is_array() || json["rsu_channels"].empty()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU commands failed: 'rsu_channels' tag is missing or is not an array or is empty.");
                return commands;
            }

            if (!json.contains("rsu_name") || !json["rsu_name"].is_string()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU commands failed: 'rsu_name' tag is missing or is not a string.");
                return commands;
            }

            if (!json.contains("rsu_slot") || !json["rsu_slot"].is_number_unsigned()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU commands failed: 'rsu_slot' tag is missing or is not an unsigned number.");
                return commands;
            }

            Command cmd;
            cmd.type = FKVRC_MESSAGE_RSU;
            cmd.name = json["rsu_name"].get<std::string>();
            cmd.slot = json["rsu_slot"].get<uint8_t>();
            auto channels = json["rsu_channels"];
            for (const auto &channelGroup: channels) {
                if (!channelGroup.is_array() || channelGroup.empty() || channelGroup.size() != statusLength) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU commands failed: channel group format is invalid or length does not match status array.");
                    return commands;
                }

                for (size_t i = 0; i < statusLength; ++i) {
                    if (!channelGroup[i].is_number_unsigned() || !json["rsu_statuses"][i].is_string()) {
                        logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU commands failed: Type mismatch for 'rsu_channels' or 'rsu_statuses' at index " + std::to_string(i) + ".");
                        return commands;
                    }

                    cmd.channel = channelGroup[i].get<uint8_t>();
                    cmd.status = json["rsu_statuses"][i].get<std::string>();

                    cmd.delay = json.value("delay", 50);
                    if (json.contains("timeout") && !json["timeout"].is_null()) {
                        if (!json["timeout"].is_number_unsigned()) {
                            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse RSU commands failed: Type mismatch for 'timeout'.");
                            return commands;
                        }
                        cmd.timeout = json["timeout"].get<uint32_t>();
                    }

                    commands.push_back(cmd);
                }
            }
        }
        catch (const nlohmann::json::exception &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch RSU commands failed: JSON parsing error or type mismatch: " + std::string(e.what()));
        }

        return commands;
    }

    std::vector<Command> JsonConfig::getVISACommands(const nlohmann::json &json) {
        std::vector<Command> commands;
        try {
            if (!json.contains("visa_tags") || !json["visa_tags"].is_array() || json["visa_tags"].empty()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch VISA commands failed: 'visa_tags' tag is missing or is not an array or is empty.");
                return commands;
            }

            if (!json.contains("visa_name") || !json["visa_name"].is_string()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch VISA commands failed: 'visa_name' tag is missing or is not a string.");
                return commands;
            }

            if (!json.contains("visa_nplc") || !json["visa_nplc"].is_string()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch VISA commands failed: 'visa_nplc' tag is missing or is not a string.");
                return commands;
            }

            Command cmd;
            cmd.type = FKVRC_MESSAGE_VISA;
            cmd.name = json["visa_name"].get<std::string>();
            cmd.nplc = json["visa_nplc"].get<std::string>();
            for (const auto &tag: json["visa_tags"]) {
                if (!tag.is_string()) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch VISA commands failed: Type mismatch for 'visa_tags'.");
                    return commands;
                }

                cmd.tag = tag.get<std::string>();

                cmd.delay = json.value("delay", 50);
                if (json.contains("visa_measuring_range") && !json["visa_measuring_range"].is_null()) {
                    if (!json["visa_measuring_range"].is_string()) {
                        logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch VISA commands failed: Type mismatch for 'visa_measuring_range'.");
                        return commands;
                    }
                    cmd.range = json["visa_measuring_range"].get<std::string>();
                }

                commands.push_back(cmd);
            }
        }
        catch (const nlohmann::json::exception &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse batch VISA command failed: JSON parsing error or type mismatch: " + std::string(e.what()));
        }

        return commands;
    }

    bool JsonConfig::combineCommands(const nlohmann::json &json, std::vector<Command> &commands) {
        size_t statusLength = 0;
        std::vector<Command> rsuCommands = getRSUCommands(json, statusLength);
        std::vector<Command> visaCommands = getVISACommands(json);

        if (rsuCommands.empty() || visaCommands.empty())
            return false;

        if (rsuCommands.size() / statusLength != visaCommands.size()) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG,
                       "parse batch commands failed, the number of RSU instructions does not match the number of VISA instructions");
            return false;
        }

        for (size_t i = 0; i < visaCommands.size(); ++i) {
            for (size_t j = 0; j < statusLength; ++j) {
                commands.push_back(rsuCommands[i * statusLength + j]);
            }

            commands.push_back(visaCommands[i]);

            for (size_t j = 0; j < statusLength; ++j) {
                Command busOffCommand = rsuCommands[i * statusLength + j];
                busOffCommand.status = "BUS_OFF";
                commands.push_back(busOffCommand);
            }
        }

        return true;
    }

    int JsonConfig::parseTestPrepare(std::vector<Command> &commands) {
        std::vector<Command>().swap(commands);

        try {
            auto prepare = jsonObj["test_prepare"];
            if (!prepare.is_object()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test prepare failed: 'test_prepare' tag is missing or is not an object.");
                return 0;
            }

            auto cmds = prepare["command"];
            if (!cmds.is_array() || cmds.empty()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test prepare failed: 'command' tag is missing, is not an array, or is empty.");
                return -1;
            }

            for (const auto &cmd : cmds) {
                if (!cmd.is_object() || !cmd.contains("type") || !cmd["type"].is_string()) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse command failed: 'type' tag is missing or is not a string.");
                    return false;
                }

                if (cmd["type"] != "RSU" && cmd["type"] != "BATCH") {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse command failed: 'type' value is invalid, must be 'RSU' or 'BATCH'.");
                    return false;
                }

                if (cmd["type"] == "BATCH") {
                    if (!getBatchRSUCommand(cmd, commands)) {
                        return false;
                    }
                } else if (cmd["type"] == "RSU") {
                    Command command = getRSUCommand(cmd);
                    if (command.type == FKVRC_MESSAGE_TYPE_UNKNOWN) {
                        return false;
                    }
                    commands.push_back(command);
                }
            }
        } catch (nlohmann::json::type_error &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test prepare failed: JSON parsing error or type mismatch: " + std::string(e.what()));
            return -1;
        }

        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_CONFIG, "parse test prepare success! [" + std::to_string(commands.size()) + "] commands will be executed.");
        return commands.size();
    }

    bool JsonConfig::checkBus(const std::vector<Command> &commands) {
        bool isCheck{true};
        auto bus = jsonObj["test_case"]["check_bus"];
        if ((nullptr != bus) && bus.is_boolean())
            isCheck = bus;

        if (!isCheck)
            return true;

        std::string allBusOn{""};
        std::string allBusOff{""};
        for (auto &cmd: commands) {
            if (cmd.channel.has_value()) {
                if (cmd.status.has_value()) {
                    if (cmd.status.value() == "BUS_OFF") {
                        if (!allBusOff.empty())
                            allBusOff += FIGKEY_LOG_USAGE_SEPARATOR;
                        allBusOff += std::to_string(cmd.channel.value());
                    } else if (cmd.status.value().find("BUS_") != std::string::npos) {
                        if (!allBusOn.empty())
                            allBusOn += FIGKEY_LOG_USAGE_SEPARATOR;
                        allBusOn += std::to_string(cmd.channel.value());
                    }
                }
            }
        }

        if (allBusOn != allBusOff) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG,
                       "parse test case failed, bus inconsistent status , bus on channel: " + allBusOn +
                       ", bus off channel: " + allBusOff);
            return false;
        }
        return true;
    }

    bool JsonConfig::parseTestCase(uint32_t &counter, std::vector<Command> &commands) {
        std::vector<Command>().swap(commands);

        try {
            auto testCase = jsonObj["test_case"];
            if (!testCase.is_object()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test case failed: 'test_case' tag is missing or is not an object.");
                return false;
            }

            auto count = testCase["counter"];
            if (!count.is_number_unsigned()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test case failed: 'counter' tag is missing or is not an unsigned number.");
                return false;
            }
            counter = count.get<uint32_t>();

            auto cmds = testCase["command"];
            if (!cmds.is_array() || cmds.empty()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test case failed: 'command' tag is missing, is not an array, or is empty.");
                return false;
            }

            for (const auto &cmd : cmds) {
                if (!cmd.is_object() || !cmd.contains("type") || !cmd["type"].is_string()) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse command failed: 'type' tag is missing or is not a string.");
                    return false;
                }

                if (cmd["type"] != "RSU" && cmd["type"] != "VISA" && cmd["type"] != "BATCH") {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse command failed: 'type' value is invalid, must be 'RSU', 'VISA', or 'BATCH'.");
                    return false;
                }

                if (cmd["type"] == "BATCH") {
                    if (!combineCommands(cmd, commands)) {
                        return false;
                    }
                } else if (cmd["type"] == "RSU") {
                    Command command = getRSUCommand(cmd);
                    if (command.type == FKVRC_MESSAGE_TYPE_UNKNOWN) {
                        return false;
                    }
                    commands.push_back(command);
                } else if (cmd["type"] == "VISA") {
                    Command command = getVISACommand(cmd);
                    if (command.type == FKVRC_MESSAGE_TYPE_UNKNOWN) {
                        return false;
                    }
                    commands.push_back(command);
                }
            }

            if (commands.empty()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test case failed: no commands to execute.");
                return false;
            }

            if (!checkBus(commands)) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test case failed: bus check failed.");
                return false;
            }
        } catch (nlohmann::json::type_error &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test case failed: JSON parsing error or type mismatch: " + std::string(e.what()));
            return false;
        }

        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_CONFIG, "parse test case success! [" + std::to_string(commands.size()) + "] commands will be executed.");
        return true;
    }

    bool JsonConfig::parseTestFinish(std::vector<Command> &commands) {
        std::vector<Command>().swap(commands);

        try {
            auto finish = jsonObj["test_finish"];
            if (!finish.is_object()) {
                // No 'test_finish' tag is fine, means nothing to do at test finish.
                return true;
            }

            auto cmds = finish["command"];
            if (!cmds.is_array() || cmds.empty()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test finish failed: 'command' tag is missing, is not an array, or is empty.");
                return false;
            }

            for (const auto &cmd : cmds) {
                Command command = getRSUCommand(cmd);
                if (command.type == FKVRC_MESSAGE_TYPE_UNKNOWN) {
                    return false;
                }
                commands.push_back(command);
            }

            if (commands.empty()) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test finish failed: no commands to execute.");
                return false;
            }
        } catch (nlohmann::json::type_error &e) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CONFIG, "parse test finish failed: JSON parsing error or type mismatch: " + std::string(e.what()));
            return false;
        }

        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_CONFIG, "parse test finish success! [" + std::to_string(commands.size()) + "] commands will be executed.");
        return true;
    }
}
