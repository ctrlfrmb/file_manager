﻿#include "datasync.h"

namespace figkey {

    DataSync::DataSync() {dataStatuses.fill(DataStatus::DEFAULT);}

    DataStatus DataSync::sendData(uint8_t index) {
        std::unique_lock<std::mutex> lock(mutex);
        if (index < MAX_DATA_COUNT) {
            dataStatuses[index] = DataStatus::WAIT_RESPONSE;
            cv.notify_all();
            return dataStatuses[index];
        }
        return dataStatuses[index];
    }

    DataStatus DataSync::waitForResponse(uint8_t index, std::chrono::milliseconds timeout) {
        std::unique_lock<std::mutex> lock(mutex);
        if (index < MAX_DATA_COUNT) {
            if (!cv.wait_for(lock, timeout,
                             [this, index]() { return dataStatuses[index] != DataStatus::WAIT_RESPONSE; })) {
                dataStatuses[index] = DataStatus::RESPONSE_TIMEOUT;
                return dataStatuses[index];
            }
            return dataStatuses[index];
        }
        return dataStatuses[index];
    }

    DataStatus DataSync::sendDataAndWaitForResponse(uint8_t index, uint32_t timeout) {
        std::unique_lock<std::mutex> lock(mutex);
        if (index < MAX_DATA_COUNT) {
            dataStatuses[index] = DataStatus::WAIT_RESPONSE;
            cv.notify_all();
            if(!cv.wait_for(lock, std::chrono::milliseconds(timeout), [this, index]() { return dataStatuses[index] != DataStatus::WAIT_RESPONSE; })) {
                dataStatuses[index] = DataStatus::RESPONSE_TIMEOUT;
                return dataStatuses[index];
            }
            return dataStatuses[index];
        }
        return dataStatuses[index];
    }

    DataStatus DataSync::receiveData(uint8_t index, DataStatus status) {
        std::unique_lock<std::mutex> lock(mutex);
        if (index < MAX_DATA_COUNT && dataStatuses[index] == DataStatus::WAIT_RESPONSE) {
            dataStatuses[index] = status;
            cv.notify_all();
            return dataStatuses[index];
        }
        return dataStatuses[index];
    }
}
