﻿#include "csv.h"

namespace figkey {

    CSVWriter::CSVWriter(const std::string& fileName)
            : mStream(fileName) {
        // Write the CSV header.
        mStream << "ID,Test Name,Test Type,Test Result,Test Value\n";
    }

    void CSVWriter::writeRow(const VisaReadInfo& info) {
        mStream << id_++ << ","  // prepend the ID.
                << info.name << ","
                << info.type << ","
                << info.result << ","
                << info.value << "\n";
    }

    CSVWriter::~CSVWriter() {
        mStream.close();
    }

} // namespace figkey
