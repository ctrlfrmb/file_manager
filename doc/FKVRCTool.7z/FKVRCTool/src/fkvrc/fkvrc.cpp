﻿#include "fkvrc.h"
#include "jsonconfig.h"
#include "canfd.h"
#include "rsu.h"
#include "fkvisa.h"
#include "utils.h"
#include <memory>
#include <iostream>
#include <thread>

static auto& config = figkey::JsonConfig::getInstance();
static auto& can = figkey::CanFDCom::getInstance();
static auto& rsu = figkey::RSUCard::getInstance();
static auto& visa = figkey::VisaCom::getInstance();

static void canReceiveBindRsuProcessor() {
    figkey::ReceiveCallback receive = std::bind(&figkey::RSUCard::receiveByCanFD, &rsu,
                                        std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);
    can.setReceiveCallback(receive);
}

FKVRC_API_RETURN openAllDevice(const char* configPath) {
    using namespace figkey;
    if (!config.parseJsonFile(configPath))
        return FKVRC_OPEN_CONFIG_FILE_FAILED;

    if (config.enableQueryVISA())
        visa.findAllResources();

    uint8_t devIdx{0};
    uint8_t devChn{0};
    if (!config.getCanConfig(devIdx, devChn))
        return FKVRC_PARSE_DEVICE_CONFIG_FAILED;

    std::string devAddr{""};
    if (!config.getMultimeterConfig(devAddr))
        return FKVRC_PARSE_DEVICE_CONFIG_FAILED;

#ifdef SELF_TEST_NO_DEVICE
    visa.openInstrument(devAddr);
#else
    if (!visa.openInstrument(devAddr))
        return FKVRC_OPEN_VISA_FAILED;

    if (!can.openDevice(devIdx))
        return FKVRC_OPEN_CAN_FAILED;

    if (!can.openChannel(devChn))
        return FKVRC_START_CAN_CHANNEL_FAILED;

    can.setTxTimeout();
    rsu.setCanChannel(devChn);

    if (!can.startReceive())
        return FKVRC_START_CAN_RECEIVE_FAILED;
#endif

    canReceiveBindRsuProcessor();

    uint32_t timeout{2000};
    if (config.enableQueryRSU(timeout))
        rsu.queryAllCardInfo(timeout);

    return FKVRC_NO_ERROR;
}

FKVRC_API_RETURN closeAllDevice() {
    FKVRC_API_RETURN ret{FKVRC_NO_ERROR};
    if (!visa.closeInstrument())
        ret = FKVRC_CLOSE_VISA_FAILED;

    if (!can.closeDevice())
        ret = FKVRC_CLOSE_CAN_FAILED;

    return ret;
}

FKVRC_API_RETURN checkTestCommand(std::vector<figkey::Command>& cmd, std::vector<FKVRCMessageInfo>& info) {
    std::vector<FKVRCMessageInfo>().swap(info);
    if (cmd.empty())
        return FKVRC_NO_ERROR;

    for (auto& c : cmd) {
        FKVRCMessageInfo msg;
        memset(&msg, 0, sizeof(FKVRCMessageInfo));
        msg.type = c.type;
        msg.delay = c.delay;

        if (c.type == FKVRC_MESSAGE_RSU) {
            msg.rsu.id = rsu.getCanIdByCardName(c.name);
            if (msg.rsu.id == FIGKEY_RSU_CARD_TYPE_UNKNOWN)
                return FKVRC_CHECK_RSU_COMMAND_FAILED;
            msg.rsu.data[0] = msg.rsu.id;

            msg.rsu.data[1] = c.slot.value_or(FIGKEY_RSU_CONTROL_STATUS_UNKNOWN);
            if (!rsu.checkPosition(msg.rsu.data[1]))
                return FKVRC_CHECK_RSU_COMMAND_FAILED;

            if (!rsu.isGeneralCommand(c.status.value_or(""), msg.rsu.data)) {
                msg.rsu.data[2] = c.channel.value_or(FIGKEY_RSU_CONTROL_STATUS_UNKNOWN);
                if (!rsu.checkChannel(msg.rsu.id, msg.rsu.data[2]))
                    return FKVRC_CHECK_RSU_COMMAND_FAILED;

                msg.rsu.data[3] = rsu.checkControl(msg.rsu.id, c.status.value_or(""));
                if (msg.rsu.data[3] == FIGKEY_RSU_CONTROL_STATUS_UNKNOWN)
                    return FKVRC_CHECK_RSU_COMMAND_FAILED;
            }

            msg.rsu.timeout = c.timeout.value_or(FIGKEY_RSU_COMMAND_TIMEOUT);
            rsu.addCardInfo(msg.rsu.id, msg.rsu.data[1]);
        }
        else {
            if (c.tag.has_value())
                memccpy(msg.visa.tag, c.tag.value().c_str(), 0, sizeof(msg.visa.tag));
            else
                memccpy(msg.visa.tag, "VOLT", 0, sizeof(msg.visa.tag));
            if (c.nplc.has_value())
                memccpy(msg.visa.nplc, c.nplc.value().c_str(), 0, sizeof(msg.visa.nplc));
            if (c.range.has_value())
                memccpy(msg.visa.range, c.range.value().c_str(), 0, sizeof(msg.visa.range));
        }
        info.push_back(msg);
    }

    return FKVRC_NO_ERROR;
}

static FKVRC_API_RETURN runTestCommand(const uint32_t& counter, const std::vector<FKVRCMessageInfo>& info) {
    for (auto& msg : info) {
        if (msg.type == FKVRC_MESSAGE_RSU) {
            rsu.sendCommandByPosition(msg.rsu.data[1], msg.rsu.data[2], msg.rsu.data[3], msg.rsu.timeout);
        }
        else {
            std::string tag{msg.visa.tag};
            tag += "_"+std::to_string(counter+1);
            visa.readVoltage(tag, msg.visa.nplc, msg.visa.range);
        }

        if (msg.delay > 0)
            std::this_thread::sleep_for(std::chrono::milliseconds(msg.delay));
    }

    return FKVRC_NO_ERROR;
}

FKVRC_API_RETURN testAllCase() {
    std::vector<figkey::Command> commands;
    std::vector<FKVRCMessageInfo> info;

    auto num{config.parseTestPrepare(commands)};
    if (num < 0)
        return FKVRC_PARSE_TEST_PREPARE_FAILED;
    else if (num > 0) {
        auto ret{checkTestCommand(commands, info)};
        if (FKVRC_NO_ERROR != ret)
            return ret;

        runTestCommand(0, info);
    }

    uint32_t counter{0};
    if (!config.parseTestCase(counter, commands))
        return FKVRC_PARSE_TEST_CASE_FAILED;

    auto ret{checkTestCommand(commands, info)};
    if (FKVRC_NO_ERROR != ret)
        return ret;

    for (uint32_t i = 0; i < counter; i++)
        runTestCommand(i, info);

    if (!config.parseTestFinish(commands))
        return FKVRC_PARSE_TEST_FINISH_FAILED;

    if (!commands.empty()) {
        ret = checkTestCommand(commands, info);
        if (FKVRC_NO_ERROR != ret)
            return ret;

        runTestCommand(0, info);
    }
    return FKVRC_NO_ERROR;
}

FKVRC_API_RETURN pasrseAndRunTestCase(const char* configPath) {
    figkey::enableLogToFile(true);
    auto ret{openAllDevice(configPath)};
    if (FKVRC_NO_ERROR != ret)
        return ret;

    testAllCase();

    ret = closeAllDevice();
    figkey::enableLogToFile(false);
    return ret;
}

FKVRC_API_RETURN openDevice(unsigned int devIdx)
{
    if (!can.openDevice(devIdx))
        return FKVRC_OPEN_CAN_FAILED;

    return FKVRC_NO_ERROR;
}

FKVRC_API_RETURN openChannel(unsigned int devChn) {
    if (!can.openChannel(devChn))
        return FKVRC_START_CAN_CHANNEL_FAILED;

    can.setTxTimeout();
    rsu.setCanChannel(devChn);

    return FKVRC_NO_ERROR;
}

FKVRC_API_RETURN openChannelAndReceive(unsigned int devChn) {
    if (FKVRC_NO_ERROR != openChannel(devChn))
        return FKVRC_START_CAN_CHANNEL_FAILED;

    if (!can.startReceive())
        return FKVRC_START_CAN_RECEIVE_FAILED;

    canReceiveBindRsuProcessor();
    return FKVRC_NO_ERROR;
}

FKVRC_API_RETURN runDeviceByChannel(unsigned int devIdx, unsigned int devChn)
{
    if (FKVRC_NO_ERROR != openDevice(devIdx))
        return FKVRC_OPEN_CAN_FAILED;

    auto ret{openChannelAndReceive(devChn)};
    if (FKVRC_NO_ERROR != ret)
        return ret;

    return FKVRC_NO_ERROR;
}

FKVRC_API_RETURN closeDevice() {
    if (!can.closeDevice())
        return FKVRC_CLOSE_CAN_FAILED;

    return FKVRC_NO_ERROR;
}

static FKVRC_API_RETURN getResponseReturnCode(figkey::DataStatus status) {
    switch (status) {
        case figkey::DataStatus::RESPONSE_SUCCESS:
            return FKVRC_NO_ERROR;
        case figkey::DataStatus::INPUT_CHECK_FAILED:
            return FKVRC_INPUT_CHECK_FAILED;
        case figkey::DataStatus::SEND_MESSAGE_FAILED:
            return FKVRC_SEND_MESSAGE_FAILED;
        case figkey::DataStatus::RESPONSE_CHECK_FAILED:
            return FKVRC_RESPONSE_CHECK_FAILED;
        case figkey::DataStatus::RESPONSE_ERROR:
            return FKVRC_RESPONSE_ERROR;
        case figkey::DataStatus::RESPONSE_STATUS_ERROR:
            return FKVRC_RESPONSE_STATUS_ERROR;
        case figkey::DataStatus::RESPONSE_TIMEOUT:
            return FKVRC_RESPONSE_TIMEOUT;
        default:
            break;
    }

    return FKVRC_RESPONSE_ERROR;
}

FKVRC_API_RETURN queryCardInfoByPosition(unsigned char pos, unsigned int timeout_ms) {
    auto res{rsu.queryCardInfoByPosition(pos, timeout_ms)};

    return getResponseReturnCode(res);
}

unsigned char showAllCardInfo() {
    return rsu.showAllCardInfo();
}

FKVRC_API_RETURN resetCardHardwareByPosition(unsigned char pos, unsigned int timeout_ms) {
    auto res{rsu.resetHardwareByPosition(pos, timeout_ms)};

    return getResponseReturnCode(res);
}

FKVRC_API_RETURN setCardReplyMessageByPosition(unsigned char pos, unsigned int timeout_ms, unsigned char enable) {
    auto res{rsu.setReplyMessageByPosition(pos, timeout_ms, enable)};

    return getResponseReturnCode(res);
}

FKVRC_API_RETURN resetCardRelayByPosition(unsigned char pos, unsigned int timeout_ms) {
    auto res{rsu.resetRelayByPosition(pos, timeout_ms)};

    return getResponseReturnCode(res);
}

unsigned char getCardTypeByPosition(unsigned char pos) {
    return rsu.getCardType(pos);
}

FKVRC_API_RETURN showCardRelayChannel(unsigned char type) {
    switch (type) {
        case FIGKEY_RSU_CARD3_TYPE:
            printf("板卡C3通道的可选范围（%u~%u), 其中通道0控制继电器是否串电阻\n", FKVRC_C3_CHANNEL_START, FKVRC_C3_CHANNEL_END);
            return FKVRC_NO_ERROR;
        case FIGKEY_RSU_CARD5_TYPE:
            printf("板卡C5通道的可选范围（%u~%u)\n", FKVRC_C5_CHANNEL_START, FKVRC_C5_CHANNEL_END);
            return FKVRC_NO_ERROR;
        case FIGKEY_RSU_CARD6_TYPE:
            printf("板卡C6通道的可选范围（%u~%u)\n", FKVRC_C6_CHANNEL_START, FKVRC_C6_CHANNEL_END);
            return FKVRC_NO_ERROR;
        case FIGKEY_RSU_CARD7_TYPE:
            printf("板卡C7通道的可选范围（%u~%u)\n", FKVRC_C7_CHANNEL_START, FKVRC_C7_CHANNEL_END);
            return FKVRC_NO_ERROR;
        case FIGKEY_RSU_CARD8_TYPE:
            printf("板卡C8通道的可选范围（%u~%u)\n", FKVRC_C8_CHANNEL_START, FKVRC_C8_CHANNEL_END);
            return FKVRC_NO_ERROR;
        default:
            printf("\033[31mRS板卡：请输入有效卡槽，或者重新查询插槽对应信息\033[0m\n");
            break;
    }

    return FKVRC_INPUT_CARD_TYPE_ERROR;
}

FKVRC_API_RETURN showCardRelayControl(unsigned char type, unsigned char channel) {
    switch (type) {
        case FIGKEY_RSU_CARD3_TYPE:
            if (FKVRC_C3_CHANNEL_START == channel) {
                printf("板卡C3通道0继电器是否串电阻：%u 不串电阻、%u 串电阻\n", FKVRC_C3_BUS_CONTROL_ALL_OFF, FKVRC_C3_BUS_CONTROL_ALL_ON);
            } else if (channel <= FKVRC_C3_CHANNEL_END) {
                printf("板卡C3通道%u可切换的继电器范围：%u~%u\n", channel, FKVRC_C3_BUS_1, FKVRC_C3_BUS_4);
            } else {
                printf("\033[31m无效通道值[%u]，板卡C3的通道范围（%u~%u)\033[0m\n", channel, FKVRC_C3_CHANNEL_START, FKVRC_C3_CHANNEL_END);
                return FKVRC_INPUT_CARD_CHANNEL_ERROR;
            }
            return FKVRC_NO_ERROR;
        case FIGKEY_RSU_CARD5_TYPE:
            if ((channel >= FKVRC_C5_CHANNEL_START) && (channel <= FKVRC_C5_CHANNEL_END)) {
                printf("板卡C5通道%u负载控制可选值：%u LOAD全断开、%u LOAD1打开通电、%u LOAD1打开不通电、%u LOAD2打开通电、%u LOAD2打开不通电\n",
                       channel, FKVRC_C5_LOAD_OFF, FKVRC_C5_LOAD1_ON_PWR_NC, FKVRC_C5_LOAD1_ON_PWR_NO, FKVRC_C5_LOAD2_ON_PWR_NC, FKVRC_C5_LOAD2_ON_PWR_NO);
            } else {
                printf("\033[31m无效通道值[%u]，板卡C5的通道范围（%u~%u)\033[0m\n", channel, FKVRC_C5_CHANNEL_START, FKVRC_C5_CHANNEL_END);
                return FKVRC_INPUT_CARD_CHANNEL_ERROR;
            }
            return FKVRC_NO_ERROR;
        case FIGKEY_RSU_CARD6_TYPE:
            if ((channel >= FKVRC_C6_CHANNEL_START) && (channel <= FKVRC_C6_CHANNEL_END)) {
                printf("板卡C6通道%u负载控制可选值：%u LOAD全断开、%u LOAD打开通电、%u LOAD打开不通电\n",
                       channel, FKVRC_C6_LOAD_OFF, FKVRC_C6_LOAD_ON_PWR_NC, FKVRC_C6_LOAD_ON_PWR_NO);
            } else {
                printf("\033[31m无效通道值[%u]，板卡C6的通道范围（%u~%u)\033[0m\n", channel, FKVRC_C6_CHANNEL_START, FKVRC_C6_CHANNEL_END);
                return FKVRC_INPUT_CARD_CHANNEL_ERROR;
            }
            return FKVRC_NO_ERROR;
        case FIGKEY_RSU_CARD7_TYPE:
            if ((channel >= FKVRC_C7_CHANNEL_START) && (channel <= FKVRC_C7_CHANNEL_END)) {
                printf("板卡C7通道%u负载控制可选值：%u LOAD断开、%u LOAD打开\n",
                       channel, FKVRC_C7_LOAD_OFF, FKVRC_C7_LOAD_ON);
            } else {
                printf("\033[31m无效通道值[%u]，板卡C7的通道范围（%u~%u)\033[0m\n", channel, FKVRC_C7_CHANNEL_START, FKVRC_C7_CHANNEL_END);
                return FKVRC_INPUT_CARD_CHANNEL_ERROR;
            }
            return FKVRC_NO_ERROR;
        case FIGKEY_RSU_CARD8_TYPE:
            if ((channel >= FKVRC_C8_CHANNEL_START) && (channel <= FKVRC_C8_CHANNEL_END)) {
                printf("板卡C8通道%u负载控制可选值：%u LOAD全断开、%u LOAD打开通电、%u LOAD打开不通电\n",
                       channel, FKVRC_C8_LOAD_OFF, FKVRC_C8_LOAD_ON_PWR_NC, FKVRC_C8_LOAD_ON_PWR_NO);
            } else {
                printf("\033[31m无效通道值[%u]，板卡C8的通道范围（%u~%u)\033[0m\n", channel, FKVRC_C8_CHANNEL_START, FKVRC_C8_CHANNEL_END);
                return FKVRC_INPUT_CARD_CHANNEL_ERROR;
            }
            return FKVRC_NO_ERROR;
        default:
            printf("\033[31mRS板卡：请输入有效卡槽，或者重新查询插槽对应信息\033[0m\n");
            break;
    }

    return FKVRC_INPUT_CARD_TYPE_ERROR;
}

static FKVRC_API_RETURN checkInputCommandParameterForC3(unsigned char channel, unsigned char control) {
    if (channel > FKVRC_C3_CHANNEL_END) {
            printf("\033[31m无效通道值[%u]，板卡C3通道范围（%u~%u）\033[0m\n", channel,
                   FKVRC_C3_CHANNEL_START, FKVRC_C3_CHANNEL_END);
            return FKVRC_INPUT_CARD_CHANNEL_ERROR;
        }

    if (FKVRC_C3_CHANNEL_START == channel) {
        if ((control != FKVRC_C3_BUS_CONTROL_ALL_OFF) && (control != FKVRC_C3_BUS_CONTROL_ALL_ON)) {
            printf("\033[31m无效控制值[%u]：板卡C3通道0继电器是否串电阻：%u 不串电阻、%u 串电阻\033[0m\n", control,
                   FKVRC_C3_BUS_CONTROL_ALL_OFF, FKVRC_C3_BUS_CONTROL_ALL_ON);
            return FKVRC_INPUT_CARD_CONTROL_ERROR;
        }
    }
    else {
        if (control > FKVRC_C3_BUS_4) {
            printf("\033[31m无效控制值[%u]：板卡C3通道%u可切换的继电器范围：%u~%u\033[0m\n", control, channel,
                   FKVRC_C3_BUS_1, FKVRC_C3_BUS_4);
            return FKVRC_INPUT_CARD_CONTROL_ERROR;
        }
    }

    return FKVRC_NO_ERROR;
}

static FKVRC_API_RETURN checkInputCommandParameterForC5(unsigned char channel, unsigned char control) {
    if ((channel < FKVRC_C5_CHANNEL_START) || (channel > FKVRC_C5_CHANNEL_END)) {
        printf("\033[31m无效通道值[%u]，板卡C5的通道范围（%u~%u)\033[0m\n", channel, FKVRC_C5_CHANNEL_START, FKVRC_C5_CHANNEL_END);
        return FKVRC_INPUT_CARD_CHANNEL_ERROR;
    }

    switch (control) {
        case FKVRC_C5_LOAD_OFF:
        case FKVRC_C5_LOAD1_ON_PWR_NC:
        case FKVRC_C5_LOAD1_ON_PWR_NO:
        case FKVRC_C5_LOAD2_ON_PWR_NC:
        case FKVRC_C5_LOAD2_ON_PWR_NO:
            return FKVRC_NO_ERROR;
        default:
            printf("\033[31m无效控制值[%u]，板卡C5通道%u负载控制可选值：%u LOAD全断开、%u LOAD1打开通电、%u LOAD1打开不通电、%u LOAD2打开通电、%u LOAD2打开不通电\033[0m\n",
                   control, channel, FKVRC_C5_LOAD_OFF, FKVRC_C5_LOAD1_ON_PWR_NC, FKVRC_C5_LOAD1_ON_PWR_NO, FKVRC_C5_LOAD2_ON_PWR_NC, FKVRC_C5_LOAD2_ON_PWR_NO);
            break;

    }

    return FKVRC_INPUT_CARD_CONTROL_ERROR;
}

static FKVRC_API_RETURN checkInputCommandParameterForC6(unsigned char channel, unsigned char control) {
    if ((channel < FKVRC_C6_CHANNEL_START) || (channel > FKVRC_C6_CHANNEL_END)) {
        printf("\033[31m无效通道值[%u]，板卡C6的通道范围（%u~%u)\033[0m\n", channel, FKVRC_C6_CHANNEL_START, FKVRC_C6_CHANNEL_END);
        return FKVRC_INPUT_CARD_CHANNEL_ERROR;
    }

    switch (control) {
        case FKVRC_C6_LOAD_OFF:
        case FKVRC_C6_LOAD_ON_PWR_NC:
        case FKVRC_C6_LOAD_ON_PWR_NO:
            return FKVRC_NO_ERROR;
        default:
            printf("\033[31m无效控制值[%u]，板卡C6通道%u负载控制可选值：%u LOAD全断开、%u LOAD打开通电、%u LOAD打开不通电\033[0m\n",
                   control, channel, FKVRC_C6_LOAD_OFF, FKVRC_C6_LOAD_ON_PWR_NC, FKVRC_C6_LOAD_ON_PWR_NO);
            break;

    }

    return FKVRC_INPUT_CARD_CONTROL_ERROR;
}

static FKVRC_API_RETURN checkInputCommandParameterForC7(unsigned char channel, unsigned char control) {
    if ((channel < FKVRC_C7_CHANNEL_START) || (channel > FKVRC_C7_CHANNEL_END)) {
        printf("\033[31m无效通道值[%u]，板卡C7的通道范围（%u~%u)\033[0m\n", channel, FKVRC_C7_CHANNEL_START, FKVRC_C7_CHANNEL_END);
        return FKVRC_INPUT_CARD_CHANNEL_ERROR;
    }

    switch (control) {
        case FKVRC_C7_LOAD_OFF:
        case FKVRC_C7_LOAD_ON:
            return FKVRC_NO_ERROR;
        default:
            printf("\033[31m无效控制值[%u]，板卡C7通道%u负载控制可选值：%u LOAD断开、%u LOAD打开\033[0m\n",
                   control, channel, FKVRC_C7_LOAD_OFF, FKVRC_C7_LOAD_ON);
            break;

    }

    return FKVRC_INPUT_CARD_CONTROL_ERROR;
}

static FKVRC_API_RETURN checkInputCommandParameterForC8(unsigned char channel, unsigned char control) {
    if ((channel < FKVRC_C8_CHANNEL_START) || (channel > FKVRC_C8_CHANNEL_END)) {
        printf("\033[31m无效通道值[%u]，板卡C8的通道范围（%u~%u)\033[0m\n", channel, FKVRC_C8_CHANNEL_START, FKVRC_C8_CHANNEL_END);
        return FKVRC_INPUT_CARD_CHANNEL_ERROR;
    }

    switch (control) {
        case FKVRC_C8_LOAD_OFF:
        case FKVRC_C8_LOAD_ON_PWR_NC:
        case FKVRC_C8_LOAD_ON_PWR_NO:
            return FKVRC_NO_ERROR;
        default:
            printf("\033[31m无效控制值[%u]，板卡C8通道%u负载控制可选值：%u LOAD全断开、%u LOAD打开通电、%u LOAD打开不通电\033[0m\n",
                   control, channel, FKVRC_C8_LOAD_OFF, FKVRC_C8_LOAD_ON_PWR_NC, FKVRC_C8_LOAD_ON_PWR_NO);
            break;

    }

    return FKVRC_INPUT_CARD_CONTROL_ERROR;
}

static FKVRC_API_RETURN checkInputCommandParameter(unsigned char pos, unsigned char channel, unsigned char control) {
    auto type{rsu.getCardType(pos)};
    switch (type) {
        case FIGKEY_RSU_CARD3_TYPE:
            return checkInputCommandParameterForC3(channel, control);
        case FIGKEY_RSU_CARD5_TYPE:
            return checkInputCommandParameterForC5(channel, control);
        case FIGKEY_RSU_CARD6_TYPE:
            return checkInputCommandParameterForC6(channel, control);
        case FIGKEY_RSU_CARD7_TYPE:
            return checkInputCommandParameterForC7(channel, control);
        case FIGKEY_RSU_CARD8_TYPE:
            return checkInputCommandParameterForC8(channel, control);
        default:
            printf("\033[31m未知的板卡：请输入有效卡槽，或者重新查询插槽对应信息\033[0m\n");
    }

    return FKVRC_INPUT_CARD_POSITION_ERROR;
}

FKVRC_API_RETURN sendCardCommandByPosition(unsigned char pos, unsigned char channel, unsigned char control, unsigned int timeout_ms) {
    auto check{checkInputCommandParameter(pos, channel, control)};
    if (FKVRC_NO_ERROR != check)
        return check;

    auto res{rsu.sendCommandByPosition(pos, channel, control, timeout_ms)};

    return getResponseReturnCode(res);
}
