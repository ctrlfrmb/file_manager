﻿#include "rsu.h"
#include "utils.h"
#include <iostream>
#include <iomanip>
#include <thread>

namespace figkey {

    RSUCard::RSUCard() : canChannel(0) {
    }

    RSUCard::~RSUCard() {
        clearCardInfo();
    }

    void RSUCard::clearCardInfo() {
        std::unique_lock<std::mutex> locker(mutexInfo);
        std::map<uint8_t, RSUCardInfo>().swap(cardInfo);
    }

    void RSUCard::clearCardInfoByPosition(uint8_t position) {
        std::unique_lock<std::mutex> locker(mutexInfo);
        auto iter = cardInfo.find(position);
        if (iter == cardInfo.end())
            return;

        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_RSU, "remove old slot "+std::to_string(position));
        cardInfo.erase(iter);
    }

    DataStatus RSUCard::sendMessageByPosition(uint8_t position, uint8_t byte2, uint8_t byte3) {
        std::unique_lock<std::mutex> locker(mutexInfo);
        if (cardInfo.empty()) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "the system did not recognize any board information, please query again.");
            return DataStatus::INPUT_CHECK_FAILED;
        }

        auto iter = cardInfo.find(position);
        if (iter == cardInfo.end()) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "unrecognized card slot "+std::to_string(position)+", please refer to the following information: ");
            showAllCardInfo();
            return DataStatus::INPUT_CHECK_FAILED;
        }

        std::array<uint8_t, FIGKEY_RSU_DATA_LENGTH> arr{iter->second.type, position, byte2, byte3};
        iter->second.data = arr;
        locker.unlock();

        if (!utils::sendRSUMessage(canChannel, arr[0], arr.data()))
            return DataStatus::SEND_MESSAGE_FAILED;

        return DataStatus::RESPONSE_SUCCESS;
    }

#ifdef SELF_TEST_BY_RANDOM
    bool RSUCard::sendCardInfo(uint8_t id, const std::vector<unsigned char>& data) {
        if (!utils::findRequestCanId(id) || (id != RSUCardRequestCommandHigh) || (data.size() != FIGKEY_RSU_DATA_LENGTH))
            return false;

        std::vector<unsigned char> queryPos{0xC0, data[1], 0xFF, 0xFF};
        std::vector<unsigned char> queryAll{0xC0, 0xFF, 0xFF, 0xFF};
        if (utils::areArraysEqual(queryAll, data)) {
            uint8_t size{static_cast<uint8_t>(random() % (RSUCardDefine.size() *3))};
            if (size > 0) {
                if (size > FIGKEY_RSU_CARD_MAX_LENGTH)
                    size = FIGKEY_RSU_CARD_MAX_LENGTH;
                std::cout << "收到查询板卡命令，即将模拟回复" << static_cast<int>(size) << "个板卡信息" << std::endl;
                auto iter = RSUCardDefine.begin();
                uint8_t pos{0};
                for (; (pos < size); ++iter) {
                    if (iter == RSUCardDefine.end())
                        iter = RSUCardDefine.begin();
                    uint8_t check = (random() % 12) ? 0xFF : 0x00;
                    uint8_t canData[FIGKEY_RSU_DATA_LENGTH]{iter->first, ++pos, check, 0xFF};
                    utils::sendRSUMessage(canChannel, RSUCardResponseCommandHigh, canData);
                }
            } else
                std::cerr << "模拟查询板卡超时，即不发送板卡信息" << std::endl;
        } else if (utils::areArraysEqual(queryPos, data)) {
            auto index = random() % RSUCardDefine.size();
            if (index > 0) {
                std::cout << "收到查询单个板卡命令，即将模拟回复板卡信息" << std::endl;
                // 获取第二个元素
                auto iter = std::next(RSUCardDefine.begin(), index-1);
                if (iter != RSUCardDefine.end()) {
                    uint8_t check = (random() % 11) ? 0xFF : 0x00;
                    uint8_t canData[FIGKEY_RSU_DATA_LENGTH]{iter->first, data[1], check, 0xFF};
                    utils::sendRSUMessage(canChannel, RSUCardResponseCommandHigh, canData);
                }
            } else
                std::cerr << "模拟查询板卡位置超时，即不发送板卡信息" << std::endl;
        } else {
            std::cerr << "查询板卡指令校验失败，查询命令形如：0xC0, 0xFF, 0xFF, 0xFF" << std::endl;
        }

        return true;
    }

    bool RSUCard::responseFixedCommand(uint8_t id, const std::vector<unsigned char>& data) {
        if (!utils::findRequestCanId(id) || (data.size() != FIGKEY_RSU_DATA_LENGTH))
            return false;

        if ((RSUResetHardwareCommandByte2 != data[2]) && (RSUReplyMessageCommandByte2 != data[2])
            && (RSUResetRelayCommandByte2Byte3 != data[2]))
            return false;

        uint8_t canId(id-RSUCardCommandDifference);
        uint8_t canData[FIGKEY_RSU_DATA_LENGTH]{canId, data[1], data[2], data[3]};

        uint8_t check0 = random() % 31;
        if (check0 < 2)
            canData[0] = check0;
        else if (check0 < 5)
            canData[0] = id + RSUCardCommandDifference;
        else if (0 == (random() % 20))
            canData[3] = 0xFF;

        if (RSUResetHardwareCommandByte2 == data[2])
            std::cout << "收到硬件重启命令，即将模拟回复硬件重启结果" << std::endl;
        else if (RSUReplyMessageCommandByte2 == data[2])
            std::cout << "收到使能回复命令，即将模拟回复使能结果" << std::endl;
        else if (RSUResetRelayCommandByte2Byte3 == data[2])
            std::cout << "收到继电器重启命令，即将模拟回复继电器重启结果" << std::endl;
        utils::sendRSUMessage(canChannel, canId, canData);
        return true;
    }

    bool RSUCard::responseAllCommand(uint8_t id, const std::vector<unsigned char>& data) {
        if (!utils::findRequestCanId(id) || (data.size() != FIGKEY_RSU_DATA_LENGTH))
            return false;

        uint8_t canId(id-RSUCardCommandDifference);
        uint8_t canData[FIGKEY_RSU_DATA_LENGTH]{canId, data[1], data[2], data[3]};

        uint8_t check0 = random() % 11;
        if (0 == check0)
            canData[0] = id + RSUCardCommandDifference;

        std::cout << "收到继电器控制命令，即将模拟回复继电器控制结果" << std::endl;
        utils::sendRSUMessage(canChannel, canId, canData);
        return true;
    }
#endif

    bool RSUCard::parseCardInfo(const std::vector<unsigned char>& data) {
        auto cardIter = RSUCardDefine.find(data[0]);
        if (cardIter == RSUCardDefine.end()) {
            dataSync.receiveData(data[1], DataStatus::RESPONSE_CHECK_FAILED);
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                       "parse device response for query command failed：unrecognized card type " + utils::uint8ToHexString(data[0]));
            return false;
        }

        std::vector<unsigned char> cards{data[0],data[1], 0xFF, 0xFF};
        if (!utils::areArraysEqual(cards, data)) {
            dataSync.receiveData(data[1], DataStatus::RESPONSE_CHECK_FAILED);
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                       "parse device response for query command failed：data verification failed on card slot " + std::to_string(data[1]));
            return false;
        }

        RSUCardInfo info{cardIter->second,data[0],{0,0,0,0}};
        {
            std::unique_lock<std::mutex> locker(mutexInfo);
            cardInfo.emplace(data[1], info);
        }

        if (DataStatus::RESPONSE_SUCCESS == dataSync.receiveData(data[1], DataStatus::RESPONSE_SUCCESS))
            logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_RSU,
                       "device response for query command by card slot "+ std::to_string(data[1]) + " successfully");
        else
            logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_RSU,
                       "device response for query command successfully: card slot "+ std::to_string(data[1]));
        return true;
    }

    bool RSUCard::parseResponseCommand(const std::vector<unsigned char>& data) {
        uint8_t type{FIGKEY_RSU_CONTROL_STATUS_UNKNOWN};
        std::vector<unsigned char> checkData;
        {
            std::unique_lock<std::mutex> locker(mutexInfo);
            auto cardIter = cardInfo.find(data[1]);
            if (cardIter == cardInfo.end()) {
                dataSync.receiveData(data[1], DataStatus::RESPONSE_CHECK_FAILED);
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                           "parse device response failed：unrecognized card slot " + std::to_string(data[1]));
                return false;
            }

            type = cardIter->second.type;
            for (auto &d: cardIter->second.data)
                checkData.emplace_back(d);
        }

        if (type == (data[0] - RSUCardCommandDifference)) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                       "card slot " + std::to_string(data[1]) + " device response error "+ utils::uint8ToHexString(data[0]));
            dataSync.receiveData(data[1], DataStatus::RESPONSE_ERROR);
            return false;
        }

        checkData[0] -= RSUCardCommandDifference;
        if (!utils::areArraysEqual(checkData, data)) {
            if (checkData[0] == data[0]) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                           "card slot " + std::to_string(data[1]) + " device response status error ");
                dataSync.receiveData(data[1], DataStatus::RESPONSE_STATUS_ERROR);
                return false;
            }

            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                       "card slot " + std::to_string(data[1]) + " device response check error ");
            dataSync.receiveData(data[1], DataStatus::RESPONSE_CHECK_FAILED);
            return false;
        }

        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_RSU, "card slot " + std::to_string(data[1]) + " device response success ");
        dataSync.receiveData(data[1], DataStatus::RESPONSE_SUCCESS);
        return true;
    }

    bool RSUCard::receiveByCanFD(unsigned int /*ts*/, uint8_t id, std::vector<unsigned char>&& data) {
#ifdef SELF_TEST_BY_RANDOM
        if (sendCardInfo(id, data))
            return true;

        if (responseFixedCommand(id, data))
            return true;

        if (responseAllCommand(id, data))
            return true;
#endif

        if (!utils::findResponseCanId(id)) {
            logMessage(LogLevel::WARN, FIGKEY_LOG_TAG_RSU, "non-rus message");
            return false;
        }

        if (data.size() == FIGKEY_RSU_DATA_LENGTH) {
            if (id == RSUCardResponseCommandHigh)
                return parseCardInfo(data);
            else
                return parseResponseCommand(data);
        }

        logMessage(LogLevel::WARN, FIGKEY_LOG_TAG_RSU, "unusual rus message");
        return false;
    }

    bool RSUCard::queryAllCardInfo(uint32_t timeout_ms) {
        clearCardInfo();
        uint8_t data[FIGKEY_RSU_DATA_LENGTH] { 0xC0, 0xFF, 0xFF, 0xFF};
        if (!utils::sendRSUMessage(canChannel, data[0], data))
            return false;

        if (timeout_ms < 500)
            timeout_ms = 500;
        std::this_thread::sleep_for(std::chrono::milliseconds(timeout_ms));
        showAllCardInfo();
        return true;
    }

    DataStatus RSUCard::queryCardInfoByPosition(uint8_t position, unsigned int timeout_ms)  {
        if (position > FIGKEY_RSU_CARD_MAX_LENGTH) {
            std::cerr << "卡槽位置错误，正确位置范围0x00~"<<std::hex<<static_cast<int>(FIGKEY_RSU_CARD_MAX_LENGTH)<<std::endl;
            return DataStatus::INPUT_CHECK_FAILED;
        }

        clearCardInfoByPosition(position);

        uint8_t data[FIGKEY_RSU_DATA_LENGTH] { 0xC0, position, 0xFF, 0xFF};
        if (!utils::sendRSUMessage(canChannel, data[0], data))
            return DataStatus::SEND_MESSAGE_FAILED;

        auto status{dataSync.sendDataAndWaitForResponse(position, timeout_ms)};
        if (DataStatus::RESPONSE_TIMEOUT == status) {
            std::cerr << "卡槽位置"<<static_cast<int>(position)<<"信息查询超时" << std::endl;
            return status;
        }

        return status;
    }

    unsigned char RSUCard::showAllCardInfo() {
        std::unique_lock<std::mutex> locker(mutexInfo);
        for (const auto &info: cardInfo)
            logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_RSU,
                       "card slot:" + std::to_string(info.first) + ", card name：" + info.second.name + "，card type：" +
                               utils::uint8ToHexString(info.second.type));

        return cardInfo.size();
    }

    DataStatus RSUCard::sendCommandByPosition(uint8_t position, uint8_t byte2, uint8_t byte3, unsigned int timeout_ms) {
        auto status{sendMessageByPosition(position, byte2, byte3)};
        if (DataStatus::RESPONSE_SUCCESS != status) return status;

        status = dataSync.sendDataAndWaitForResponse(position, timeout_ms);
        if (DataStatus::RESPONSE_TIMEOUT == status) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "slot "+std::to_string(position)+" wait device response timeout: "+std::to_string(timeout_ms)+"ms");
            return status;
        }

        return status;
    }

    DataStatus RSUCard::resetHardwareByPosition(uint8_t position, unsigned int timeout_ms) {
        return sendCommandByPosition(position, RSUResetHardwareCommandByte2, RSUResetHardwareCommandByte3, timeout_ms);
    }

    DataStatus RSUCard::setReplyMessageByPosition(uint8_t position, unsigned int timeout_ms, unsigned char enable) {
        return sendCommandByPosition(position, RSUReplyMessageCommandByte2, enable?RSUReplyMessageEnable:RSUReplyMessageDisable, timeout_ms);
    }

    DataStatus RSUCard::resetRelayByPosition(uint8_t position, unsigned int timeout_ms) {
        return sendCommandByPosition(position, RSUResetRelayCommandByte2Byte3, RSUResetRelayCommandByte2Byte3, timeout_ms);
    }

    unsigned char RSUCard::getCardType(uint8_t position) {
        std::unique_lock<std::mutex> locker(mutexInfo);
        auto iter = cardInfo.find(position);
        if (iter == cardInfo.end())
            return FIGKEY_RSU_CARD_TYPE_UNKNOWN;

        return iter->second.type;
    }

    unsigned char RSUCard::getCanIdByCardName(const std::string& name) {
        std::string names("");
        for (const auto& info: RSUCardDefine) {
            if (info.second == name)
                return info.first;

            if (!names.empty())
                names += FIGKEY_LOG_USAGE_SEPARATOR;
            names+= info.second;
        }

        logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "card name invalid, must be "+names);
        return FIGKEY_RSU_CARD_TYPE_UNKNOWN;
    }

    bool RSUCard::checkPosition(uint8_t position) {
        if (position > FIGKEY_RSU_CARD_MAX_LENGTH) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "card slot invalid, must be 0~"+std::to_string(FIGKEY_RSU_CARD_MAX_LENGTH));
            return false;
        }

        return true;
    }

    void RSUCard::addCardInfo(uint8_t type, uint8_t position) {
        std::unique_lock<std::mutex> locker(mutexInfo);
        auto iter = cardInfo.find(position);
        if (iter != cardInfo.end())
            return;

        RSUCardInfo info{RSUCardDefine.at(type),type,{0,0,0,0}};
        cardInfo.emplace(position, info);
    }

    bool RSUCard::isGeneralCommand(const std::string& control, uint8_t data[FIGKEY_RSU_DATA_LENGTH]) {
        static std::map<std::string, FKVRC_RSU_GENARL_COMMAND> generalCommand = {
                {"RESET_HARDWARE", FKVRC_RSU_RESET_HARDWARE},
                {"REPLY_OFF", FKVRC_RSU_REPLY_OFF},
                {"REPLY_ON", FKVRC_RSU_REPLY_ON},
                {"RESET_ALL_RELAY", FKVRC_RSU_RESET_ALL_RELAY}};

        auto iter = generalCommand.find(control);
        if (iter == generalCommand.end())
            return false;

        switch (iter->second) {
            case FKVRC_RSU_RESET_HARDWARE:
                data[2] = RSUResetHardwareCommandByte2;
                data[3] = RSUResetHardwareCommandByte3;
                break;
            case FKVRC_RSU_REPLY_OFF:
                data[2] = RSUReplyMessageCommandByte2;
                data[3] = RSUReplyMessageDisable;
                break;
            case FKVRC_RSU_REPLY_ON:
                data[2] = RSUReplyMessageCommandByte2;
                data[3] = RSUReplyMessageEnable;
                break;
            case FKVRC_RSU_RESET_ALL_RELAY:
                data[2] = RSUResetRelayCommandByte2Byte3;
                data[3] = RSUResetRelayCommandByte2Byte3;
                break;
            default:
                return false;
        }
        return true;
    }

    bool RSUCard::checkChannel(uint8_t type, uint8_t channel) {
        switch (type) {
            case FIGKEY_RSU_CARD3_TYPE:
                if ((channel < FKVRC_C3_CHANNEL_START) || (channel > FKVRC_C3_CHANNEL_END)) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "c3 channel invalid, must be "+std::to_string(FKVRC_C3_CHANNEL_START)+"~"+std::to_string(FKVRC_C3_CHANNEL_END));
                    return false;
                }
                break;
            case FIGKEY_RSU_CARD5_TYPE:
                if ((channel < FKVRC_C5_CHANNEL_START) || (channel > FKVRC_C5_CHANNEL_END)) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "c5 channel invalid, must be "+std::to_string(FKVRC_C5_CHANNEL_START)+"~"+std::to_string(FKVRC_C5_CHANNEL_END));
                    return false;
                }
                break;
            case FIGKEY_RSU_CARD6_TYPE:
                if ((channel < FKVRC_C6_CHANNEL_START) || (channel > FKVRC_C6_CHANNEL_END)) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "c6 channel invalid, must be "+std::to_string(FKVRC_C6_CHANNEL_START)+"~"+std::to_string(FKVRC_C6_CHANNEL_END));
                    return false;
                }
                break;
            case FIGKEY_RSU_CARD7_TYPE:
                if ((channel < FKVRC_C7_CHANNEL_START) || (channel > FKVRC_C7_CHANNEL_END)) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "c7 channel invalid, must be "+std::to_string(FKVRC_C7_CHANNEL_START)+"~"+std::to_string(FKVRC_C7_CHANNEL_END));
                    return false;
                }
                break;
            case FIGKEY_RSU_CARD8_TYPE:
                if ((channel < FKVRC_C8_CHANNEL_START) || (channel > FKVRC_C8_CHANNEL_END)) {
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "c8 channel invalid, must be "+std::to_string(FKVRC_C8_CHANNEL_START)+"~"+std::to_string(FKVRC_C8_CHANNEL_END));
                    return false;
                }
                break;
            default:
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU, "card type invalid, current type is "+utils::uint8ToHexString(type));
                return false;
        }

        return true;
    }

    unsigned char RSUCard::checkControl(uint8_t type, const std::string& control) {
        static std::map<std::string, FKVRC_C3_BUS_STATUS> c3BusMap = {
                {"BUS_OFF", FKVRC_C3_BUS_OFF},
                {"BUS_1",   FKVRC_C3_BUS_1},
                {"BUS_2",   FKVRC_C3_BUS_2},
                {"BUS_3",   FKVRC_C3_BUS_3},
                {"BUS_4",   FKVRC_C3_BUS_4}
        };

        static std::map<std::string, FKVRC_C5_LOAD_CONTROL> c5CtrlMap = {
                {"LOAD_OFF",        FKVRC_C5_LOAD_OFF},
                {"LOAD1_ON_PWR_NC", FKVRC_C5_LOAD1_ON_PWR_NC},
                {"LOAD1_ON_PWR_NO", FKVRC_C5_LOAD1_ON_PWR_NO},
                {"LOAD2_ON_PWR_NC", FKVRC_C5_LOAD2_ON_PWR_NC},
                {"LOAD2_ON_PWR_NO", FKVRC_C5_LOAD2_ON_PWR_NO}
        };

        static std::map<std::string, FKVRC_C6_LOAD_CONTROL> c6CtrlMap = {
                {"LOAD_OFF",       FKVRC_C6_LOAD_OFF},
                {"LOAD_ON_PWR_NC", FKVRC_C6_LOAD_ON_PWR_NC},
                {"LOAD_ON_PWR_NO", FKVRC_C6_LOAD_ON_PWR_NO}
        };

        static std::map<std::string, FKVRC_C7_LOAD_CONTROL> c7CtrlMap = {
                {"LOAD_OFF", FKVRC_C7_LOAD_OFF},
                {"LOAD_ON",  FKVRC_C7_LOAD_OFF}
        };

        static std::map<std::string, FKVRC_C8_LOAD_CONTROL> c8CtrlMap = {
                {"LOAD_OFF",       FKVRC_C8_LOAD_OFF},
                {"LOAD_ON_PWR_NC", FKVRC_C8_LOAD_ON_PWR_NC},
                {"LOAD_ON_PWR_NO", FKVRC_C8_LOAD_ON_PWR_NO}
        };

        switch (type) {
            case FIGKEY_RSU_CARD3_TYPE: {
                auto iter = c3BusMap.find(control);
                if (iter != c3BusMap.end())
                    return iter->second;
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                           "c3 bus control invalid, must be BUS_OFF, BUS_1, BUS_2, BUS_3 or BUS_4");
            }
                break;
            case FIGKEY_RSU_CARD5_TYPE: {
                auto iter = c5CtrlMap.find(control);
                if (iter != c5CtrlMap.end())
                    return iter->second;
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                           "c5 load control invalid, must be LOAD_OFF, LOAD1_ON_PWR_NC, LOAD1_ON_PWR_NO, LOAD2_ON_PWR_NC or LOAD2_ON_PWR_NO");
            }
                break;
            case FIGKEY_RSU_CARD6_TYPE: {
                auto iter = c6CtrlMap.find(control);
                if (iter != c6CtrlMap.end())
                    return iter->second;
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                           "c6 load control invalid, must be LOAD_OFF, LOAD_ON_PWR_NC or LOAD_ON_PWR_NO");
            }
                break;
            case FIGKEY_RSU_CARD7_TYPE: {
                auto iter = c7CtrlMap.find(control);
                if (iter != c7CtrlMap.end())
                    return iter->second;
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                           "c7 load control invalid, must be LOAD_OFF or LOAD_ON");
            }
                break;
            case FIGKEY_RSU_CARD8_TYPE: {
                auto iter = c8CtrlMap.find(control);
                if (iter != c8CtrlMap.end())
                    return iter->second;
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                           "c8 load control invalid, must be LOAD_OFF, LOAD_ON_PWR_NC or LOAD_ON_PWR_NO");
            }
                break;
            default:
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_RSU,
                           "card type invalid, current type is " + utils::uint8ToHexString(type));

                break;
        }

        return FIGKEY_RSU_CONTROL_STATUS_UNKNOWN;
    }

}
