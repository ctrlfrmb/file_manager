﻿#include "utils.h"
#include "logger.hpp"
#include "thread_pool.hpp"
#include "canfd.h"
#include <iostream>
#include <algorithm>
#include <chrono>
#include <iomanip>

// 在一个源文件中初始化
const std::string FKVRC_VERSION = FKVRC_VERSION_STRING;
std::unique_ptr<opensource::ctrlfrmb::Logger> g_logger;

static std::string logPrefixFunction() {
    auto now = std::chrono::steady_clock::now();
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;

    auto now_c = std::chrono::system_clock::now();
    auto timer = std::chrono::system_clock::to_time_t(now_c);

    std::tm bt{};
    localtime_r(&timer, &bt);

    std::ostringstream oss;
    oss << std::put_time(&bt, "%Y-%m-%d %H:%M:%S");
    oss << '.' << std::setfill('0') << std::setw(3) << ms.count();

    return oss.str();
}

namespace figkey {

    // 在库的源文件中实现函数
    std::string getLibraryVersion() {
        return "libfkvrc version: fk20240110_v"+std::string(FKVRC_VERSION_STRING);
    }

    void createJsonConfigFile() {
        std::string jsonContent = R"({
        "config": {
            "log_level": 1,
            "can": {
                "device_index": 0,
                "device_channel": 0
            },
            "multimeter": {
                "device_address": "USB0::0x2A8D::0x1401::MY57227015::0::INSTR"
            },
            "query": {
                "rsu": true,
                "rsu_wait": 50,
                "visa": true
            }
        },
        "test_prepare": {
            "command": [
                {
                    "type": "RSU",
                    "name": "LOAD_CARD_48CH_2A",
                    "slot": 3,
                    "channel": 1,
                    "status": "LOAD1_ON_PWR_NO",
                    "timeout": 1000
                },
                {
                    "type": "RSU",
                    "name": "LOAD_CARD_48CH_2A",
                    "slot": 3,
                    "channel": 11,
                    "status": "LOAD2_ON_PWR_NC",
                    "timeout": 1000,
                    "delay": 50
                }
            ]
        },
        "test_case": {
            "check_bus": true,
            "counter": 2,
            "command": [
                {
                    "type": "RSU",
                    "name": "MATRIX_CARD_64X4",
                    "slot": 4,
                    "channel": 1,
                    "status": "BUS_1",
                    "timeout": 1000
                },
                {
                    "type": "RSU",
                    "name": "MATRIX_CARD_64X4",
                    "slot": 4,
                    "channel": 58,
                    "status": "BUS_2",
                    "timeout": 1000
                },
                {
                    "type": "VISA",
                    "name": "VOLTAGE",
                    "tag": "BUS1_BUS1",
                    "nplc": "10",
                    "measuring_range": "AUTO ON"
                },
                {
                    "type": "RSU",
                    "name": "MATRIX_CARD_64X4",
                    "slot": 4,
                    "channel": 1,
                    "status": "BUS_OFF",
                    "timeout": 1000
                },
                {
                    "type": "RSU",
                    "name": "MATRIX_CARD_64X4",
                    "slot": 4,
                    "channel": 58,
                    "status": "BUS_OFF",
                    "timeout": 1000
                }
            ]
        },
        "test_finish": {
            "command": [
                {
                    "type": "RSU",
                    "name": "LOAD_CARD_48CH_2A",
                    "slot": 3,
                    "channel": 1,
                    "status": "LOAD_OFF",
                    "timeout": 1000
                },
                {
                    "type": "RSU",
                    "name": "LOAD_CARD_48CH_2A",
                    "slot": 3,
                    "channel": 11,
                    "status": "LOAD_OFF",
                    "timeout": 1000
                }
            ]
        }
    })";

        std::ofstream configFile("fkvrc_tester_bysystem.json");
        if (configFile.is_open()) {
            configFile << jsonContent;
            configFile.close();
            logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_SYSTEM, "fkvrc_tester_bysystem.json created successfully");
        } else {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_SYSTEM, "fkvrc_tester_bysystem.json created failed");
        }
    }

    void setLogLevel(uint8_t level) {
        if (g_logger) {
            switch (level) {           // 期望状态
                case 0:
                    g_logger->setLevel(opensource::ctrlfrmb::LogLevel::TRACE);
                    break;
                case 1:
                    g_logger->setLevel(opensource::ctrlfrmb::LogLevel::DEBUG);
                    break;
                case 2:
                    g_logger->setLevel(opensource::ctrlfrmb::LogLevel::INFO);
                    break;
                case 3:
                    g_logger->setLevel(opensource::ctrlfrmb::LogLevel::WARN);
                    break;
                case 4:
                    g_logger->setLevel(opensource::ctrlfrmb::LogLevel::ERROR);
                    break;
                case 5:
                    g_logger->setLevel(opensource::ctrlfrmb::LogLevel::FATAL);
                    break;
                default:
                    g_logger->setLevel(opensource::ctrlfrmb::LogLevel::DEBUG);
                    break;
            }
        }
    }

    void logMessage(LogLevel level, const char *tag, const std::string &message) {
        std::string log{tag + message};
        if (g_logger) {
            switch (level) {           // 期望状态
                case LogLevel::INFO:
                    g_logger->info(log);
                    break;
                case LogLevel::WARN:
                    g_logger->warn(log);
                    break;
                case LogLevel::ERROR:
                    g_logger->error(log);
                    break;
                case LogLevel::FATAL:
                    g_logger->fatal(log);
                    break;
                default:
                    g_logger->debug(log);
                    break;
            }
        } else
            std::cerr << log << std::endl;
    }

    void initializeEnvironment() {
        using namespace opensource::ctrlfrmb;
        g_logger = std::make_unique<Logger>();
        if (nullptr == g_logger) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_SYSTEM, "initialize environment failed, logger nullptr");
            return;
        }

        g_logger->setPrefixCallback(logPrefixFunction);

        // 获取线程池的实例
        opensource::ctrlfrmb::ThreadPool &pool = opensource::ctrlfrmb::ThreadPool::Instance();
        // 设置线程池参数
        pool.set(6, 2, 600); // 设置最大线程数为6，最小线程数为2，线程超时时间为600秒

        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_SYSTEM, getLibraryVersion());
        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_SYSTEM, "initialize environment success");
    }

    void uninitializeEnvironment() {
        if (g_logger) {
            using namespace opensource::ctrlfrmb;
            g_logger->disableFileWrite();

            // 关闭线程池
            opensource::ctrlfrmb::ThreadPool::Instance().shutdown();
        }
    }

    void enableLogToFile(bool enable) {
        if (g_logger) {
            using namespace opensource::ctrlfrmb;
#ifdef SELF_TEST_NO_DEVICE
            FileLoggerConfig config{"./", "fkvrc_simulation_", ".log", 1024 * 1024 * 10, 10, true};
#else
            FileLoggerConfig config{"./", "fkvrc_report_", ".log", 1024 * 1024 * 10, 10, true};
#endif
            if (enable) {
                g_logger->enableFileWrite(config);
            } else {
                g_logger->disableFileWrite();
            }
        }
    }

    namespace utils {
#ifdef SELF_TEST_BY_RANDOM
        bool findRequestCanId(uint8_t id) {
            static const uint8_t ids[6] = {0xC0, 0xC3, 0xC5, 0xC6, 0xC7, 0xC8};
            for (const auto &val: ids) {
                if (id == val)
                    return true;
            }
            return false;
        }
#endif

        bool findResponseCanId(uint8_t id) {
            static const uint8_t ids[6] = {0xA0, 0xA3, 0xA5, 0xA6, 0xA7, 0xA8};
            for (const auto &val: ids) {
                if (id == val)
                    return true;
            }
            return false;
        }

        bool areArraysEqual(const std::vector<unsigned char> &array1, const std::vector<unsigned char> &array2) {
            // 首先检查两个数组的长度是否都为4
            if (array1.size() != array2.size()) {
                return false;
            }

            // 使用 std::equal 函数比较两个数组是否相等
            return std::equal(std::begin(array1), std::end(array1), std::begin(array2));;
        }

        static ZCAN_20_MSG getRSUSendMessage(U8 channel, U8 id, U8 data[FIGKEY_RSU_DATA_LENGTH]) {
            // 构建 CAN 消息
            ZCAN_20_MSG canMsg{};
            canMsg.hdr.ts = 0; // 硬件接收时间戳，结构体用于发送时无效，无需填充。时间戳单位为百微秒
#ifdef SELF_TEST_BY_RANDOM
            canMsg.hdr.inf.txm = 2; //发送方式，0为正常模式，2为自发自收（仅用于自测）。
#else
            canMsg.hdr.inf.txm = 0; //发送方式，0为正常模式，2为自发自收（仅用于自测）。
#endif
            canMsg.hdr.inf.fmt = 0; // 0-CAN帧 can2.0，1-CANFD帧
            canMsg.hdr.inf.sdf = 0; // 0-数据帧，1-远程帧
            canMsg.hdr.inf.sef = 0; // 0-标准帧，1-扩展帧
            canMsg.hdr.inf.err = 0; // 0-正常帧，1-错误帧
            canMsg.hdr.inf.brs = 0; // 0-CANFD不加速 1M+1M ，1-CANFD加速 1M+4M
            canMsg.hdr.inf.est = 0; //错误状态，0-积极错误，1-消极错误
            canMsg.hdr.pad = 0;
            canMsg.hdr.chn = channel; //通道号，必须填充，必须与发送函数transmit发送时必须保持通道号一致，否则会发送失败
            canMsg.hdr.len = FIGKEY_RSU_DATA_LENGTH; //用于控制CAN帧数据段的实际有效长度，即DLC
            canMsg.hdr.id = id; // id: bit0~6, checksum of data0~N
            for (auto i = 0; i < canMsg.hdr.len; i++) {
                canMsg.dat[i] = data[i];
            }

            return canMsg;
        }

        bool sendRSUMessage(unsigned char channel, unsigned char id, unsigned char data[FIGKEY_RSU_DATA_LENGTH]) {
            auto canMsg{getRSUSendMessage(channel, id, data)};
            if (!CanFDCom::getInstance().send(std::move(canMsg)))
                return false;

            return true;
        }

        std::string uint8ToHexString(uint8_t value) {
            char hexValue[3];
            snprintf(hexValue, sizeof(hexValue), "%02x", value);
            return std::string(hexValue);
        }
    }
}
