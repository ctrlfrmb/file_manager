﻿#include "canfd.h"
#include "utils.h"
#include "thread_pool.hpp"
#include <iostream>
#include <iomanip>

namespace figkey {

    CanFDCom::CanFDCom()
            : devType(DevUsbCanFD200UType), devIndex(DevUsbCanFD200UIndex), devChannel(0), devStatus(CanFDStatus::DEFAULT),
              receiveRun(false), receiveCallback(nullptr)
            {
            }

    CanFDCom::~CanFDCom() {
        closeDevice();
    }

    bool CanFDCom::isValid(CanFDStatus status, const std::string& prompt, const std::string& err) const {
        if (devStatus >= status) {
            if (!prompt.empty())
                logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_CAN, prompt);
            return true;
        }

        if (!err.empty()) {
            switch (status) {               // 期望状态
                case CanFDStatus::DEVICE_OPENED:  // 设备已打开
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CAN, err+"please turn on the can device first");
                    break;
                case CanFDStatus::CHANNEL_STARTED:  // 通道已启动
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CAN, err+"please enable the can channel first");
                    break;
                default:
                    logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CAN, err+"unknown error");
                    break;
            }
        }
        return false;
    }

    void CanFDCom::setReceiveCallback(ReceiveCallback callback) {
        receiveCallback = std::move(callback);
    }

    bool CanFDCom::openDevice(U32 index) {
        if (isValid(CanFDStatus::DEVICE_OPENED, "can card is opened", "")) return true;

        devIndex = index;
        if (!VCI_OpenDevice(devType, devIndex, 0)) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CAN, "failed to open can device, devType:"+std::to_string(devType)+", devIndex: "+std::to_string(devIndex));
            return false;
        }

        devStatus = CanFDStatus::DEVICE_OPENED;
        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_CAN, "open the can device successfully, devType:"+std::to_string(devType)+", devIndex: "+std::to_string(devIndex));
        return true;
    }

    bool CanFDCom::openChannel(U32 channel) {
        if (!isValid(CanFDStatus::DEVICE_OPENED, "", "failed to enable can channel, ")) return false;

        // 初始化 CAN 配置
        ZCAN_INIT initConfig;
        initConfig.clk = 60000000; // 设置时钟, V1.01销售版本USBCANFD-200U的时钟为60MHz，V1.03则为80MHz。一般情况下统一60MHz即可
        initConfig.mode = 0; // bit1设为0为ISO标准，设为1为BOSCH标准，一般只用ISO标准；bit0设置为0为正常模式，设置为1为只听模式
#if 1  // #500K+2M
        initConfig.aset.tseg1  =   7;
        initConfig.aset.tseg2  =   2;
        initConfig.aset.sjw    =   2;
        initConfig.aset.smp    =   0;
        initConfig.aset.brp    =   9;
        initConfig.dset.tseg1  =   22;
        initConfig.dset.tseg2  =   5;
        initConfig.dset.sjw    =   2;
        initConfig.dset.smp    =   0;
        initConfig.dset.brp    =   0;
#else
        // aset-仲裁域波特率设置，dset-数据域波特率设置。
        initConfig.aset.tseg1 = 46; // 46:1M tseg1为CAN帧的位的成员，具体值由ZCANPRO软件，【工具】中的波特率计算器算出。
        initConfig.aset.tseg2 = 11; // tseg2为CAN帧的位的成员，具体值由ZCANPRO软件，【工具】中的波特率计算器算出。
        initConfig.aset.sjw = 3; // sjw为同步跳转宽度，具体值由ZCANPRO软件，【工具】中的波特率计算器算出
        initConfig.aset.smp = 0; // 采样点，此处只当做自行备注用，值填多少都不生效（实际生成的波特率的采样点由其它参数决定）
        initConfig.aset.brp = 2; // 分频，具体值由ZCANPRO软件，【工具】中的波特率计算器算出
        initConfig.dset.tseg1 = 14; //14:1M 10:4M
        initConfig.dset.tseg2 = 3;
        initConfig.dset.sjw = 3;
        initConfig.dset.smp = 0;
        initConfig.dset.brp = 0;
#endif
        if (!VCI_InitCAN(devType, devIndex, channel, &initConfig)) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CAN, "failed to initialize can channel"+std::to_string(channel));
            return false;
        }

        if (!VCI_StartCAN(devType, devIndex, channel)) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CAN, "failed to enable can channel "+std::to_string(channel));
            return false;
        }

        devChannel = channel;
        devStatus = CanFDStatus::CHANNEL_STARTED;
        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_CAN, "can channel "+std::to_string(channel)+" enabled successfull");
        return true;
    }

    bool CanFDCom::setTxTimeout(U32 timeout) {
        if (!isValid(CanFDStatus::DEVICE_OPENED, "", "timeout setting failed, ")) return false;

        enum {
            CMD_CAN_FILTER = 0x14,
            CMD_CAN_TRES = 0x18,
            CMD_CAN_TX_TIMEOUT = 0x44,
            CMD_CAN_TTX = 0x16,
            CMD_CAN_TTX_CTL = 0x17,
        };

        // transmit timeout , default 2 seconds
        if (!VCI_SetReference(devType, devIndex, 0, CMD_CAN_TX_TIMEOUT, &timeout)) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CAN, "timeout setting failed, devType:"+std::to_string(devType)+", devIndex: "+std::to_string(devIndex));
            //return false;
        }

        // terminal resistor
        U32 on = 1;
        if (!VCI_SetReference(devType, devIndex, 0, CMD_CAN_TRES, &on)) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CAN, "terminal close signal capture setting failed, devType:"+std::to_string(devType)+", devIndex: "+std::to_string(devIndex));
            //return false;
        }

        return true;
    }

    bool CanFDCom::startReceive(U32 timeout) {
        if (!isValid(CanFDStatus::CHANNEL_STARTED, "", "Failed to enable can channel to receive messages, ")) return false;

        if (receiveRun) return true;

        // 获取线程池的实例
        receiveRun = true;
        auto recv = std::bind(&CanFDCom::receive, &CanFDCom::getInstance(), std::placeholders::_1);
        auto& pool = opensource::ctrlfrmb::ThreadPool::Instance();
        pool.submit(recv, timeout);

        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_CAN, "enable can channel "+std::to_string(devChannel)+" to receive messages successfully");
        return true;
    }

    bool CanFDCom::send(ZCAN_20_MSG&& canMsg) {
#ifdef SELF_TEST_NO_DEVICE
        char buffer[256];
        snprintf(buffer, sizeof(buffer), "can%d，id: 0x%02X, len: %d, data: %02X %02X %02X %02X",
                 devChannel, canMsg.hdr.id, canMsg.hdr.len, canMsg.dat[0], canMsg.dat[1], canMsg.dat[2], canMsg.dat[3]);

        logMessage(LogLevel::DEBUG, FIGKEY_LOG_TAG_CAN, "send message: "+std::string(buffer));

        if (receiveCallback) {
            auto id {static_cast<uint8_t>(canMsg.hdr.id&0xFF)};
            std::vector<U8> data(canMsg.dat, canMsg.dat+canMsg.hdr.len);

            snprintf(buffer, sizeof(buffer), "can%d，id: 0x%02X, len: %d, data: %02X %02X %02X %02X",
                     devChannel, canMsg.hdr.id, canMsg.hdr.len, canMsg.dat[0], canMsg.dat[1], canMsg.dat[2], canMsg.dat[3]);
            logMessage(LogLevel::DEBUG, FIGKEY_LOG_TAG_CAN, "receive message: "+std::string(buffer));

            opensource::ctrlfrmb::ThreadPool::Instance().submit(receiveCallback, canMsg.hdr.ts, id, data);
        }
        return true;
#else
        if (!isValid(CanFDStatus::CHANNEL_STARTED, "", "message sending failed, ")) return false;

        char buffer[256];
        snprintf(buffer, sizeof(buffer), "can%d，id: 0x%02X, len: %d, data: %02X %02X %02X %02X",
                 devChannel, canMsg.hdr.id, canMsg.hdr.len, canMsg.dat[0], canMsg.dat[1], canMsg.dat[2], canMsg.dat[3]);

        auto num{VCI_Transmit(devType, devIndex, devChannel, &canMsg, 1)};
        if (num != 1) {
            logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CAN, "message sending failed, "+std::string(buffer));
            return false;
        }

        logMessage(LogLevel::DEBUG, FIGKEY_LOG_TAG_CAN, "send message: "+std::string(buffer));
        return true;
#endif
    }

    void CanFDCom::receive(U32 timeout) {
        auto& pool = opensource::ctrlfrmb::ThreadPool::Instance();

        // 接收逻辑
        U32 num;
        ZCAN_20_MSG canMsg;
        while (receiveRun) {
            num = VCI_Receive(devType, devIndex, devChannel, &canMsg, 1, timeout);

            if ((num > 0) && (canMsg.hdr.len > 0)) {
                // 处理接收到的消息
                if (receiveCallback) {
                    auto id {static_cast<uint8_t>(canMsg.hdr.id&0xFF)};
                    std::vector<U8> data(canMsg.dat, canMsg.dat+canMsg.hdr.len);

                    char buffer[256];
                    snprintf(buffer, sizeof(buffer), "can%d，id: 0x%02X, len: %d, data: %02X %02X %02X %02X",
                             devChannel, canMsg.hdr.id, canMsg.hdr.len, canMsg.dat[0], canMsg.dat[1], canMsg.dat[2], canMsg.dat[3]);
                    logMessage(LogLevel::DEBUG, FIGKEY_LOG_TAG_CAN, "receive message: "+std::string(buffer));

                    pool.submit(receiveCallback, canMsg.hdr.ts, id, data);
                }
            }
        }

        logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_CAN, "can"+std::to_string(devChannel)+" stopped receiving messages");
    }

    bool CanFDCom::closeDevice() {
        if (receiveRun) {
            receiveRun = false;
            std::this_thread::sleep_for(std::chrono::milliseconds(ReceiveCanMessageTimeout));
        }

        if (CanFDStatus::DEFAULT != devStatus) {
            if (!VCI_CloseDevice(devType, devIndex)) {
                logMessage(LogLevel::ERROR, FIGKEY_LOG_TAG_CAN, "failed to close can device, devType:"+std::to_string(devType)+", devIndex: "+std::to_string(devIndex));
                return false;
            }

            logMessage(LogLevel::INFO, FIGKEY_LOG_TAG_CAN, "close can device successfully, devType:"+std::to_string(devType)+", devIndex: "+std::to_string(devIndex));
            devStatus = CanFDStatus::DEFAULT ;
        }

        return true;
    }
}
