#include <iostream>
#include <cstring>
#include "fkvrc.h"
#include "utils.h"
#include <filesystem>

bool fileExists(const std::string& filePath) {
    return std::filesystem::exists(filePath);
}

static void showUsage(){
    std::cout << "Usage: fkvrc_tester [options]" << std::endl;
    std::cout << "Options:" << std::endl;
    std::cout << "  -h, --help\t\t\tShow this help message and exit" << std::endl;
    std::cout << "  -c, --config\t\t\tAuto create test file by system" << std::endl;
    std::cout << "  -v, --version\t\t\tShow version number and exit" << std::endl;
    std::cout << "  -f, --file\t\t\tRun test case by file" << std::endl;
}

int main(int argc, char *argv[]) {
    if (argc > 2) {
        if (strcmp(argv[1], "-f") == 0 || strcmp(argv[1], "--file") == 0) {
            if (fileExists(argv[2])) {
                pasrseAndRunTestCase(argv[2]);
            } else {
                std::cerr << "File not found: " << argv[2] << std::endl;
                return 0;
            }
        }
        else {
            showUsage();
            return 0;
        }
    }
    else if (argc == 2) {
        if (strcmp(argv[1], "-h") == 0 || strcmp(argv[1], "--help") == 0) {
            showUsage();
            return 0;
        }
        else if (strcmp(argv[1], "-v") == 0 || strcmp(argv[1], "--version") == 0) {
            std::cout << figkey::getLibraryVersion() << std::endl;
            return 0;
        }
        else if (strcmp(argv[1], "-c") == 0 || strcmp(argv[1], "--config") == 0) {
            figkey::createJsonConfigFile();
        }
        else {
            showUsage();
            return 0;
        }
    }
    else {
        if (fileExists(FIGKEY_JSON_CONFIG_PATH)) {
            pasrseAndRunTestCase(FIGKEY_JSON_CONFIG_PATH);
        } else {
            showUsage();
            return 0;
        }
    }

    return 0;
}
