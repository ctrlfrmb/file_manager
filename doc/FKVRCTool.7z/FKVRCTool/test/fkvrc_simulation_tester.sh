#!/bin/bash
# 本脚本用于Ubuntu系统自动化编译

set -e

# 获取脚本所在路径
function get_script_dir(){
    # echo `pwd`
    wp=`pwd`
    # echo $0
    fp=$0
    dirp=`dirname $fp`
    # echo $dirp
    scrip_dir=${wp}/${dirp}
    # echo $scrip_dir
}

# 获取脚本所在路径
get_script_dir $0
if [ $? != 0 ]
then
    echo "获取脚本路径函数异常!"
    exit 1
fi

export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:${scrip_dir}/../lib_simulation
#./fkvrc_simulation_tester -c
if [ -f "fkvrc_tester.json" ]; then
    #mv fkvrc_tester_bysystem.json fkvrc_tester.json
    ./fkvrc_simulation_tester
    echo "仿真测试结束"
else
    echo "仿真失败：测试脚本生成失败！"
fi

