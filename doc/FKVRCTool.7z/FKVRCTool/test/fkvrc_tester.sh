#!/bin/bash
# 本脚本用于Ubuntu系统自动化编译

set -e

# 获取脚本所在路径
function get_script_dir(){
    # echo `pwd`
    wp=`pwd`
    # echo $0
    fp=$0
    dirp=`dirname $fp`
    # echo $dirp
    scrip_dir=${wp}/${dirp}
    # echo $scrip_dir
}

# 获取脚本所在路径
get_script_dir $0
if [ $? != 0 ]
then
    echo "获取脚本路径函数异常!"
    exit 1
fi

if [ -d "../lib" ]; then
    sudo cp ../lib/* /usr/local/lib/
    sudo ldconfig
    sudo ./fkvrc_tester
else
    echo "测试失败：缺少必要库！"
fi

