#include"windows.h"

extern int SpeedTest();
extern int DkTest(void);
int main()
{
	DkTest();
	return 0;
}