#pragma once
#include "stdint.h"

#define ERRCODE_NOERR 0
#define ERRCODE_MEMERR 1
#define ERRCODE_PROTOCOLIDERR 2
#define ERRCODE_PROTOCOLOPENED 3
#define ERRCODE_LANRECERR  4
#define ERRCODE_INVALID_DEVICE_ID 5
#define ERRCODE_INVALID_PROTOCOL_ID 6
#define ERRCODE_INVALID_MSG 10
#define ERRCODE_FAILED  7
#define ERRCODE_TIMEOUT 8
#define ERRCODE_BUFFER_EMPTY 9
#define ERRCODE_OPENDEV_FAILED 11

typedef void* SHANDLE;
typedef unsigned char      UINT8_T;
typedef unsigned short     UINT16_T;
typedef unsigned int       UINT32_T;

enum DEVICETYPE
{
	eNULL = 0,
	eLAN = 1,
	eUSB = 2,
	eCOM = 3,
	ePXI = 4
};

enum SPEED_WORKMODE
{
	eNORMAL = 0,
	eMISTEEH = 1,
	eCHANGEAK = 2,
	eCUSTOM = 3,
};


typedef struct WriteDataCmdDataType
{
	uint16_t WorkMode; //SPEED_WORKMODE
	uint16_t Parter1;
	uint16_t Parter2;
}WriteDataCmdDataType;

typedef struct WriteAnCmdDataType
{
	uint16_t TxQuiescentCurrent_mA;//��̬����
	uint16_t TxSinkCurrent_mA;//��������
	uint16_t TxPulseCurrent_mA;//�������

	uint16_t RxQuiescentCurrent_mA;//��̬����
	uint16_t RxSinkCurrent_mA;//��������
	uint16_t RxPulseCurrent_mA;//�������	
}WriteAnCmdDataType;

typedef struct SpeedSimReadDataType
{
	uint8_t  chanl1;
	uint8_t  mode1;
	uint16_t Frz1;
	uint16_t AkOrDutyCycle1;

	uint8_t  chanl2;
	uint8_t  mode2;
	uint16_t Frz2;
	uint16_t AkOrDutyCycle2;
}SpeedSimReadDataType;



SHANDLE FkSpeedOpenDev(UINT32_T device_type, UINT32_T device_index, UINT32_T reserved);

int FkSpeedCloseDev(SHANDLE device_handle);

int FkSpeedWriteData(SHANDLE device_handle, uint8_t Chanl, WriteDataCmdDataType Data);

int FkSpeedConfigAn(SHANDLE device_handle, uint8_t Chanl, WriteAnCmdDataType AnData);

int FkSpeedReadData(SHANDLE device_handle, SpeedSimReadDataType* pData);

