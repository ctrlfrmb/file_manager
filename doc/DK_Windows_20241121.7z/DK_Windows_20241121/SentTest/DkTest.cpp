
#include "DkApi.h"
#pragma comment(lib,"FkDkSentDll.lib")
#pragma comment(lib, "winmm.lib")
#include"stdio.h"
#include <windows.h>
#include <thread>


//unsigned long getCurTimestamp()
//{
//	return GetTickCount();
//}

int DkTest(void)
{
	int Ret = 0;
	SHANDLE DkSentDevHandle = FkDkSentOpenDev(eCOM, 5, 0);
	if (DkSentDevHandle == NULL)
	{
		printf("Open Com Fail\r\n");
		return -1;
	}
	else
	{
		printf("Open Com Sucess\r\n");
	}


	Ret = FkDkSentInit(DkSentDevHandle, 0, 0, 0, 0);


	Ret = FkDkSentInit(DkSentDevHandle, 1, 0, 0, 0);

	auto wirteThread = std::thread([&]() {
		int ret;
		DkMsgDataType WriteMsg, WriteMsg1;

		WriteMsg.Chanl = 0;
		WriteMsg.Stus = 2;
		WriteMsg.Nb0 = 1;
		WriteMsg.Nb1 = 2;
		WriteMsg.Nb2 = 3;
		WriteMsg.Nb3 = 4;
		WriteMsg.Nb4 = 5;
		WriteMsg.Nb5 = 6;

		//Ret = FkDkSentWriteChanl(DkSentDevHandle,0,&WriteMsg);

		WriteMsg1.Chanl = 1;
		WriteMsg1.Stus = 0xF;
		WriteMsg1.Nb0 = 15;
		WriteMsg1.Nb1 = 15;
		WriteMsg1.Nb2 = 13;
		WriteMsg1.Nb3 = 12;
		WriteMsg1.Nb4 = 11;
		WriteMsg1.Nb5 = 10;
		//Ret = FkDkSentWriteChanl(DkSentDevHandle, 1, &WriteMsg);

		for (int i = 0; i < 100; i++) {
			Sleep(10);
			auto startTime = timeGetTime();
			ret = FkDkSentWriteChanlAll(DkSentDevHandle, &WriteMsg, &WriteMsg1);
			auto processTime = timeGetTime() - startTime;
			printf("wirte %d result: %d, process time:%d ms\n", i + 1, ret, processTime);
		}
		}
	);

	auto readThread = std::thread([&]() {
		int ret;
		DkMsgRdDataType RdDataChanl1;
		DkMsgRdDataType RdDataChanl2;
		for (int i = 0; i < 100; i++) {
			Sleep(10);
			auto startTime = timeGetTime();
			ret = FkDkSentRead(DkSentDevHandle, &RdDataChanl1, &RdDataChanl2);
			auto processTime = timeGetTime() - startTime;
			printf("read %d result: %d, process time:%d ms\n", i + 1, ret, processTime);
		}
		}
	);

	if (wirteThread.joinable()) {
		wirteThread.join();
	}

	if (readThread.joinable()) {
		readThread.join();
	}

	Ret = FkDkSentDeInit(DkSentDevHandle, 0);
	Ret = FkDkSentDeInit(DkSentDevHandle, 1);

	Ret = FkDkSentCloseDev(DkSentDevHandle);
	return 0;
}