//#include "FkSpeedDll.h"
//#pragma comment(lib,"FkSpeedDll.lib")
//#include"stdio.h"
//#include <windows.h>
//
//int SpeedTest()
//{
//	SHANDLE SpeedDevHandle = FkSpeedOpenDev(eCOM, 5, 0);
//	if (SpeedDevHandle == NULL)
//	{
//		printf("Open Com Fail\r\n");
//		return -1;
//	}
//	else
//	{
//		printf("Open Com Sucess\r\n");
//	}
//	printf("�����������\r\n");
//	WriteDataCmdDataType TestCmdData;
//	TestCmdData.WorkMode = eCUSTOM;
//	TestCmdData.Parter1 = 100;
//	TestCmdData.Parter2 = 0x55;
//	FkSpeedWriteData(SpeedDevHandle,0, TestCmdData);
//	
//	TestCmdData.WorkMode = eNORMAL;
//	//TestCmdData.Parter1 = 100;
//	//TestCmdData.Parter2 = 0x55;
//	FkSpeedWriteData(SpeedDevHandle, 1, TestCmdData);
//	Sleep(10000);//
//
//	/*��ȡ*/
//	SpeedSimReadDataType SpeedSimReadData;
//	int Ret =  FkSpeedReadData(SpeedDevHandle, &SpeedSimReadData);
//
//	printf("���Ըı�AKֵ\r\n");
//	TestCmdData.WorkMode = eCHANGEAK;
//	TestCmdData.Parter1 = 10;
//	TestCmdData.Parter2 = 0x12;
//	FkSpeedWriteData(SpeedDevHandle, 1, TestCmdData);
//	Sleep(10000);//
//
//	printf("����ȱ��\r\n");
//	TestCmdData.WorkMode = eCUSTOM;
//	TestCmdData.Parter1 = 1000;
//	TestCmdData.Parter2 = 0x55;
//	FkSpeedWriteData(SpeedDevHandle, 0, TestCmdData);
//	TestCmdData.WorkMode = eMISTEEH;
//	TestCmdData.Parter1 = 9;
//	TestCmdData.Parter2 = 1;
//	FkSpeedWriteData(SpeedDevHandle, 1, TestCmdData);
//	Sleep(10000);//
//	printf("��λ���\r\n");
//	TestCmdData.WorkMode = eNORMAL;
//	//TestCmdData.Parter1 = 100;
//	//TestCmdData.Parter2 = 0x55;
//	FkSpeedWriteData(SpeedDevHandle, 0, TestCmdData);
//	FkSpeedWriteData(SpeedDevHandle, 1, TestCmdData);
//	printf("�ر�\r\n");
//	FkSpeedCloseDev(SpeedDevHandle);
//
//
//	return 0;
//}
