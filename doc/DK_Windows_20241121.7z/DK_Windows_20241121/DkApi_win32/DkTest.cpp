
#include "DkApi.h"
#pragma comment(lib,"FkDkSentDll.lib")
#include"stdio.h"
#include <windows.h>

//#include <assert.h>


//#define assert(x) if(x){ printf("Ret:%X",x); return x;}

int DkTest(void)
{
	int Ret = 0;
	SHANDLE DkSentDevHandle = FkDkSentOpenDev(eCOM, 5, 0);
	if (DkSentDevHandle == NULL)
	{
		printf("Open Com Fail\r\n");
		return -1;
	}
	else
	{
		printf("Open Com Sucess\r\n");
	}


	Ret = FkDkSentInit(DkSentDevHandle,0,0,0);

	Ret = FkDkSentInit(DkSentDevHandle, 1, 0, 0);

	DkMsgDataType WriteMsg,WriteMsg1;

	WriteMsg.Chanl = 0;
	WriteMsg.Stus = 2;
	WriteMsg.Nb0 = 1;
	WriteMsg.Nb1 = 2;
	WriteMsg.Nb2 = 3;
	WriteMsg.Nb3 = 4;
	WriteMsg.Nb4 = 5;
	WriteMsg.Nb5 = 6;

	//Ret = FkDkSentWriteChanl(DkSentDevHandle,0,&WriteMsg);

	WriteMsg1.Chanl = 1;
	WriteMsg1.Stus = 0xF;
	WriteMsg1.Nb0 = 15;
	WriteMsg1.Nb1 = 15;
	WriteMsg1.Nb2 = 13;
	WriteMsg1.Nb3 = 12;
	WriteMsg1.Nb4 = 11;
	WriteMsg1.Nb5 = 10;
	//Ret = FkDkSentWriteChanl(DkSentDevHandle, 1, &WriteMsg);

	Ret = FkDkSentWriteChanlAll(DkSentDevHandle,&WriteMsg,&WriteMsg1);

	Sleep(100);
	DkMsgRdDataType RdDataChanl1;
	DkMsgRdDataType RdDataChanl2;
	Ret = FkDkSentRead(DkSentDevHandle,&RdDataChanl1, &RdDataChanl2);


	Ret = FkDkSentDeInit(DkSentDevHandle,0);
	Ret = FkDkSentDeInit(DkSentDevHandle, 1);

	Ret = FkDkSentCloseDev(DkSentDevHandle);
	return 0;
}