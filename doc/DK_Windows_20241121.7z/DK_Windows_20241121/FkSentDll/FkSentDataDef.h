#pragma once
#include"stdint.h"

typedef void* SHANDLE;
typedef unsigned char      UINT8_T;
typedef unsigned short     UINT16_T;
typedef unsigned int       UINT32_T;



typedef struct FastDataType
{
	uint8_t NbType;
	uint8_t Nb[6];
	uint8_t NbNum;
}FastDataType;


typedef struct SlowDataType
{
	uint8_t SlowIDType;
	uint8_t SlowID;
	uint16_t SlowData;
}SlowDataType;



typedef struct WriteDataCmdDataType
{
	uint16_t WorkMode;
	uint16_t Parter1;
	uint16_t Parter2;
}WriteDataCmdDataType;

typedef struct WriteAnCmdDataType
{
	uint16_t TxQuiescentCurrent_mA;//��̬����
	uint16_t TxSinkCurrent_mA;//��������
	uint16_t TxPulseCurrent_mA;//�������

	uint16_t RxQuiescentCurrent_mA;//��̬����
	uint16_t RxSinkCurrent_mA;//��������
	uint16_t RxPulseCurrent_mA;//�������	
}WriteAnCmdDataType;

typedef struct SpeedSimReadDataType
{
	uint8_t  chanl1;
	uint8_t  mode1;
	uint16_t Frz1;
	uint16_t AkOrDutyCycle1;

	uint8_t  chanl2;
	uint8_t  mode2;
	uint16_t Frz2;
	uint16_t AkOrDutyCycle2;
}SpeedSimReadDataType;
