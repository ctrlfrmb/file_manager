#pragma once
#include "stdint.h"
#include"FkSentDataDef.h"

#define ERRCODE_NOERR 0
#define ERRCODE_MEMERR 1
#define ERRCODE_PROTOCOLIDERR 2
#define ERRCODE_PROTOCOLOPENED 3
#define ERRCODE_LANRECERR  4
#define ERRCODE_INVALID_DEVICE_ID 5
#define ERRCODE_INVALID_PROTOCOL_ID 6
#define ERRCODE_INVALID_MSG 10
#define ERRCODE_FAILED  7
#define ERRCODE_TIMEOUT 8
#define ERRCODE_BUFFER_EMPTY 9
#define ERRCODE_OPENDEV_FAILED 11


//SHANDLE FkSentOpenDev(UINT32_T device_type, UINT32_T device_index, UINT32_T reserved);
//
//int FkVciCloseDev(SHANDLE device_handle);
//
//int FkSpcWriteFsDataToBuf(SHANDLE device_handle, uint8_t Chanl, uint8_t index, FastDataType* pData);
//
//int FkSpcWriteSlDataToBuf(SHANDLE device_handle, uint8_t Chanl, uint8_t index, SlowDataType* pData);
//
//int FkSpcCfgTimeMode(SHANDLE device_handle, uint8_t Chanl, uint8_t IdleEnFlang, uint8_t RollingModeFlag, uint16_t CycleCnt);
//
//int FkSpcCfgTrigerMode(SHANDLE device_handle, uint8_t Chanl, uint8_t RollingModeFlag, uint8_t DelayOutPutTick, uint8_t SlotID, uint8_t TotalSlotNum);
//
//int FkSpcMsgCfg(SHANDLE device_handle, uint8_t Chanl, uint8_t SyncTick, uint8_t TickVal);
//
//int FkSpcOutPutCfg(SHANDLE device_handle, uint8_t Chanl, uint8_t TrsmitEnFlag, uint8_t StusValue, uint8_t TotoalFsMsgNum, uint8_t TotoalSlMsgNum);

SHANDLE FkSpeedOpenDev(UINT32_T device_type, UINT32_T device_index, UINT32_T reserved);

int FkSpeedCloseDev(SHANDLE device_handle);

int FkSpeedWriteData(SHANDLE device_handle, uint8_t Chanl, WriteDataCmdDataType Data);

int FkSpeedConfigAn(SHANDLE device_handle, uint8_t Chanl, WriteAnCmdDataType AnData);

int FkSpeedReadData(SHANDLE device_handle, SpeedSimReadDataType* pData);


