#include"pch.h"
#include"SentProtocol.h"
#include"VciDebugCf.h"
#include"j2534_v0404.h"
#include"BaseDevice.h"

SentProtocol::SentProtocol(void* drvhandle)
{
	debugout("SentProtocol Create ...\r\n");
	DeviceDrvHandle = drvhandle;
	WorkMode = 0;
	ProtocolID = ePROTOCOL_SENT;
	DataEventHandle = CreateEventA(
		NULL,		// default security attributes
		TRUE,		// manual-reset event
		FALSE,		// initial state is nonsignaled
		NULL);		// object name
	CommondEventHandle = CreateEventA(
		NULL,		// default security attributes
		TRUE,		// manual-reset event
		FALSE,		// initial state is nonsignaled
		NULL);		// object name
}

SentProtocol::~SentProtocol()
{
	debugout("SentProtocol Delete ...\r\n");

}
/// <summary>
/// 
/// </summary>
/// <param name="msg"></param>
void SentProtocol::ProtocolDealMsg(void* msg)
{
	debugout("SentProtocol ProtocolDealMsg Chanl:%d...\r\n", ChanlNum);

	ProtocolDataType* ResponseDataPtr = (ProtocolDataType*)msg;//�����յ�������ת��ΪЭ������
	if (CommondCheckBuf[0] != ResponseDataPtr->protocolid)//�����Ϊ��Э��ͨ�����ݲ������� ֱ�ӷ���
	{
		return;
	}

	/*��֤�Ƿ�Ϊָ��ر���*/
	if (
		CommondCheckBuf[1] == ResponseDataPtr->protocolcmd //��ǰ�����Command
		)//��ǰ����� ͨ��
	{
		debugout("Recieve CommondCheck Msg...\r\n");
		memcpy(CommondCheckBuf, msg, (ResponseDataPtr->datalen + 6));
		SetEvent(CommondEventHandle);
	}
	else//Э������
	{
		debugout("DEV�������͵���Ϣ...\r\n");
		///*�����ݴ����PassThruMsg ����ŵ�������*/
		//if (
		//	CMDCODE_RXMSG == ResponseDataPtr->protocolcmd
		//	)/*PROTOCOL_ACAN ����*/
		//{
		//	debugout("Recevie One Can Msg...\r\n");

		//	//����Ҫ���� ������  ��ǰ������KWPģʽ�� ���� RAWģʽ��  ��λ��һֱ������RAW ģʽ��

		//	FkVciDataType msgrx;
		//	memcpy((void*)&msgrx, ResponseDataPtr->pData, ResponseDataPtr->datalen);/*���� ���ݵ� FkVciDataType ��*/
		//	PushMsg(msgrx);
		//	SetEvent(DataEventHandle);
		//}
	}
}
/// <summary>
/// 
/// </summary>
/// <param name="data"></param>
/// <param name="len"></param>
/// <param name="Timeout"></param>
/// <returns></returns>
int SentProtocol::TrsmitWithResponse(uint8_t* data, int len, uint32_t Timeout)
{
	if (DeviceDrvHandle != NULL)/*�豸��Ϊ��*/
	{
		BaseDevice* dev = (BaseDevice*)DeviceDrvHandle;//��ȡӲ�����
		ProtocolDataType* ReqDataPtr = (ProtocolDataType*)data;
		ProtocolDataType* ResponseDataPtr = (ProtocolDataType*)CommondCheckBuf; //������ת��ΪЭ������
		ResetEvent(CommondEventHandle);//����յ�֮ǰ��event����
		ResponseDataPtr->protocolid = ReqDataPtr->protocolid;//Э��ID
		ResponseDataPtr->protocolcmd = ReqDataPtr->protocolcmd;//Э�鹦��
		ResponseDataPtr->protocolchanl = ReqDataPtr->protocolchanl;//Э��ͨ��

		dev->DevTrsmit(data, len);
		/*�ȴ�DEV�������ݲ��ж�*/
		if (WaitForSingleObjectEx(CommondEventHandle, Timeout, true) == WAIT_OBJECT_0)/*�ȴ��豸�ͷ�*/
		{
			//��ȡbuf�е����ݲ��ж����
			if (ResponseDataPtr->pData[0] != 0)
			{
				debugout("TrsmitWithResponse ErrCode:%02X\r\n", ResponseDataPtr->pData[0]);
				return ERRCODE_FAILED;
			}
			ResetEvent(CommondEventHandle);
		}
		else//�ȴ���ʱ
		{
			debugout("TrsmitWithResponse WaitRspMsg TimeOut!\r\n");
			return ERRCODE_TIMEOUT;

		}
	}
	else
	{
		debugout("Device Is Null\r\n");
		return ERRCODE_INVALID_DEVICE_ID;

	}
	debugout("TrsmitWithResponse Sucess!\r\n");
	return ERRCODE_NOERR;
}




int SentProtocol::SpcWriteFsDataToBuf(uint8_t Chanl,uint8_t Index, FastDataType* pData)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = Chanl;
	ReqDataPtr->protocolcmd = WR_FASTDATA_BUF;
	ReqDataPtr->protocolid = ePROTOCOL_SENT;	
	ReqDataPtr->datalen = 9;
	ReqDataPtr->pData[0] = Index;
	memcpy((ReqDataPtr->pData+1), pData, 8);
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}


int SentProtocol::SpcWriteSlDataToBuf(uint8_t Chanl, uint8_t Index, SlowDataType* pData)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = Chanl;
	ReqDataPtr->protocolcmd = WR_SLOWDATA_BUF;
	ReqDataPtr->protocolid = ePROTOCOL_SENT;
	ReqDataPtr->datalen = 5;
	ReqDataPtr->pData[0] = Index;
	memcpy((ReqDataPtr->pData+1), pData, 4);
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}
int SentProtocol::SpcCfgTimeMode(uint8_t Chanl, uint8_t IdleEnFlang, uint8_t RollingModeFlag, uint16_t CycleCnt)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = Chanl;
	ReqDataPtr->protocolcmd = WR_SPC_TIMEMODE;
	ReqDataPtr->protocolid = ePROTOCOL_SENT;
	ReqDataPtr->datalen = 4;

	ReqDataPtr->pData[0] = IdleEnFlang;
	ReqDataPtr->pData[1] = RollingModeFlag;
	ReqDataPtr->pData[2] = (uint8_t)(CycleCnt&0xff);
	ReqDataPtr->pData[3] = (uint8_t)((CycleCnt>>8)&0xff);

	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}

int SentProtocol::SpcCfgTrigerMode(uint8_t Chanl, uint8_t RollingModeFlag, uint8_t DelayOutPutTick, uint8_t SlotID, uint8_t TotalSlotNum)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = Chanl;
	ReqDataPtr->protocolcmd = WR_SPC_TRIGERMODE;
	ReqDataPtr->protocolid = ePROTOCOL_SENT;
	ReqDataPtr->datalen = 4;
	ReqDataPtr->pData[0] = RollingModeFlag;
	ReqDataPtr->pData[1] = DelayOutPutTick;
	ReqDataPtr->pData[2] = SlotID;
	ReqDataPtr->pData[3] = TotalSlotNum;
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}

int SentProtocol::SpcMsgCfg(uint8_t Chanl, uint8_t SyncTick, uint8_t TickVal)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = Chanl;
	ReqDataPtr->protocolcmd = WR_SPC_MSGTYPE;
	ReqDataPtr->protocolid = ePROTOCOL_SENT;
	ReqDataPtr->datalen = 2;
	ReqDataPtr->pData[0] = SyncTick;
	ReqDataPtr->pData[1] = TickVal;
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}

int SentProtocol::SpcOutPutCfg(uint8_t Chanl, uint8_t TrsmitEnFlag, uint8_t StusValue, uint8_t TotoalFsMsgNum, uint8_t TotoalSlMsgNum)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = Chanl;
	ReqDataPtr->protocolcmd = WR_SPC_OUTPUT;
	ReqDataPtr->protocolid = ePROTOCOL_SENT;
	ReqDataPtr->datalen = 4;
	ReqDataPtr->pData[0] = TrsmitEnFlag;
	ReqDataPtr->pData[1] = StusValue;
	ReqDataPtr->pData[2] = TotoalFsMsgNum;
	ReqDataPtr->pData[3] = TotoalSlMsgNum;
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}
