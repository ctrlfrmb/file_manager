#pragma once
#include"BaseProtocol.h"
#include"FkSentDataDef.h"

enum
{
	INIT = 0,
	DK_INIT = 0x10,
	DK_WRITECHANL = 0x20,
	DK_WRITEALL = 0x30,
	DK_READ = 0x40,
	DK_DEINIT = 0x50,
};
typedef struct DkMsgDataType
{
	uint8_t Chanl;
	uint8_t Stus;
	uint8_t Nb0;
	uint8_t Nb1;
	uint8_t Nb2;
	uint8_t Nb3;
	uint8_t Nb4;
	uint8_t Nb5;
}DkMsgDataType;


typedef struct DkMsgRdDataType
{

	uint8_t Stus;
	uint8_t Nb0;
	uint8_t Nb1;
	uint8_t Nb2;
	uint8_t Nb3;
	uint8_t Nb4;
	uint8_t Nb5;
	uint8_t CRC;
}DkMsgRdDataType;

class DkSent : public BaseProtocol
{
public:
	DkSent(void* drvhandle);
	~DkSent();
	void ProtocolDealMsg(void* msg);
	int TrsmitWithResponse(uint8_t* data, int len, uint32_t Timeout);
	int DkSentInit(uint8_t chanl, uint8_t CoverMode, uint8_t DataFomat, uint8_t Val);
	int DkSentWriteChanl(uint8_t chanl, DkMsgDataType* pData);
	int DkSentWriteChanlAll(DkMsgDataType* pDataCh1, DkMsgDataType* pDataCh2);
	int DkSentDeInit(uint8_t chanl);
	int DkSentReadData(DkMsgRdDataType* pReadBackChanl1, DkMsgRdDataType* pReadBackChanl2);


private:

	uint8_t WorkMode;
};