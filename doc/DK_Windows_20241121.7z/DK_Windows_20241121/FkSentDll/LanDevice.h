#pragma once

#pragma comment(lib, "ws2_32.lib")
#include "BaseDevice.h"
#include"winsock.h"

#define LAN_PORT_NUM 21001

class LanDevice :public BaseDevice
{
public:
	LanDevice();
	~LanDevice();

	virtual int DevRecieve();
	virtual int DevOpen(void* pName);
	virtual int DevClose();
	virtual int DevTrsmit(const uint8_t* data, int len);/**/

	uint8_t DataCheckSum(const uint8_t* buf, int len);/*У���*/
	bool DevDataToPcCov(uint8_t* buf);/*ת������-����һ��������PC����*/
private:
	SOCKET sockclient;
};