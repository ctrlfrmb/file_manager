#include"pch.h"
#include"FkVciDll.h"
#include <string.h>
//#include <tchar.h>
#include"j2534_v0404.h"
#include "CRC32.h"
#include <iostream>
#include <fstream>
#include "AcanProtocol.h"
using namespace std;

unsigned long DevIdGet;
unsigned long ActionChanlIdHandle;/*��ǰ����ʹ�õ�ID*/
unsigned long AscChanlIdHandle;
unsigned long KlinChanlIdHandle;



HANDLE UciDeviceHandle;
HANDLE ChanlHandle;
uint8_t KwpRawFlag = 0;
long K2000Start(long offset)/*���Ӱ忨*/
{
	UciDeviceHandle = FkVciOpenDev(0, offset,0);

	if (UciDeviceHandle == NULL)
		return ERR_DEVICE_NOT_CONNECTED;
	return STATUS_NOERROR;
}

long K2000Close()/*�رհ忨*/
{
	return FkVciCloseDev(UciDeviceHandle);
}

long RawIni(long BaudRate, uint8_t type, long P1Max, long P2Max, long P3Min, long P4Min)/*����һ��ASC����K����*/
{
	
	if (type == 0)/*ASC-CAN*/
	{
		if (AscChanlIdHandle == NULL)/*��û�г�ʼ��*/
		{
			ChanlHandle = FkVciInitACAN(UciDeviceHandle, 0, BaudRate);
			if (ChanlHandle == NULL)
				return ERR_DEVICE_NOT_CONNECTED;
		}
		//else/*Э���Ѿ�����  ֱ��ʹ��*/
		//{
			
			SCONFIG Config;
			int ConfigRet;

			Config.Parameter = DATA_RATE;
			Config.Value = BaudRate;
			ConfigRet = FkVciConfigACAN(ChanlHandle, SET_CONFIG, &Config);
			if (ConfigRet != 0)
				return ConfigRet;

			Config.Parameter = P1_MAX;
			Config.Value = P1Max;
			ConfigRet = FkVciConfigACAN(ChanlHandle, SET_CONFIG ,&Config);
			if (ConfigRet != 0)
				return ConfigRet;

			Config.Parameter = P2_MAX;
			Config.Value = P2Max;
			ConfigRet = FkVciConfigACAN(ChanlHandle, SET_CONFIG ,&Config);
			if (ConfigRet != 0)
				return ConfigRet;

			Config.Parameter = P3_MIN;
			Config.Value = P3Min;
			ConfigRet = FkVciConfigACAN(ChanlHandle, SET_CONFIG ,&Config);
			if (ConfigRet != 0)
				return ConfigRet;

			Config.Parameter = P4_MIN;
			Config.Value = P4Min;
			ConfigRet = FkVciConfigACAN(ChanlHandle, SET_CONFIG, &Config);
			if (ConfigRet != 0)
				return ConfigRet;
			KwpRawFlag = 0;
		//}
	}
	else if (type == 1)/*Kline*/
	{
			return ERR_NOT_SUPPORTED;
	}
	return STATUS_NOERROR;
}

uint8_t KWP2000_CheckSum(uint8_t* Datas, uint16_t Len)
{
	uint16_t idx_u16;
	uint8_t checksum;
	uint32_t sunm;
	sunm = 0;
	for (idx_u16 = 0; idx_u16 < Len; idx_u16++)
	{
		sunm += Datas[idx_u16];
	}
	checksum = (uint8_t)(sunm & 0xff);
	return (checksum);
}
/*ʹ��Э�鷢������*/
long ComBlock(uint8_t* txdata, uint16_t txlen, uint8_t* rxdata, uint16_t* rxlen, uint8_t mode, uint32_t timeout)/*ʹ��Com ��������*/
{
	uint8_t databuf[300];
	int VciTrsmitRet;
	/*����յ����еĽ�������*/
	FkVciConfigACAN(ChanlHandle, CLEAR_RX_BUFFER,NULL);
	/*�ٷ�������*/
	FkVciKwpDataType comblockData;
	memset(&comblockData,0,sizeof(FkVciKwpDataType));
	if (KwpRawFlag == 1)//ʹ��KWP ģʽ���� ���� ͷ  ֧֧��  00 DLC ģʽ
	{
		databuf[0] = 0x00;
		databuf[1] = (uint8_t)txlen;
		memcpy(databuf+2, txdata, txlen);
		databuf[txlen + 2] = KWP2000_CheckSum(databuf, (txlen+2));//KWP checkSum

		comblockData.DLC = txlen + 3;
		memcpy(comblockData.Data, databuf, comblockData.DLC);//�����ݿ�����ȥ

		VciTrsmitRet = FkVciTrsmitACAN(ChanlHandle,&comblockData,1);
	}
	else //ʹ��RAW ģʽֱ�ӷ���
	{
		comblockData.DLC = txlen;
		memcpy(comblockData.Data, txdata, comblockData.DLC);//�����ݿ�����ȥ

		VciTrsmitRet = FkVciTrsmitACAN(ChanlHandle, &comblockData, 1);
	}
	if (VciTrsmitRet != 1)//FkVciTrsmitACAN ʵ�ʴ���ı�������
		return 0x10;//Tx Faile

	/*���Ƿ���Ҫ����*/
	int VciReciveRet;
	if (mode == 0)/*��Ҫ����*/
	{
		VciReciveRet = FkVciRecieveACAN(ChanlHandle, &comblockData, 1, timeout);
		if (VciReciveRet != 1)
		{
			*rxlen = 0;
			return 0x20;//Rx Fail
		}
		else
		{
			if (rxdata != NULL)/*��������buf ��Ϊ�� �����ݿ�����ȥ*/
			{
				if (KwpRawFlag == 1)//����KWP �������� ������
				{
					memcpy(rxdata, comblockData.Data, comblockData.DLC);
					*rxlen = (uint16_t)(comblockData.DLC);
				}
				else //ֱ�ӽ�������
				{
					memcpy(rxdata, comblockData.Data, comblockData.DLC);
					*rxlen = (uint16_t)(comblockData.DLC);
				}
				
			}
			else
			{
				*rxlen = 0;
			}
			

		}
	}
	else/*����Ҫ����  */
	{

	}
	return 0;
}

long K2000Ini(uint8_t EcuAddr, uint8_t InitType, uint8_t InitLine, long P1max, long P2Max, long P3Min, long P3Max, long P4min, long TW5, long TiniL, long TWuP, long BaudRate)
{
	/*�߳�ʼ��ʱ�����*/
	SCONFIG CfgItem[9];
	//SBYTE_ARRAY InputArray;
	CfgItem[0].Parameter = DATA_RATE;
	CfgItem[0].Value = BaudRate;
	CfgItem[1].Parameter = P1_MAX;
	CfgItem[1].Value = P1max;
	CfgItem[2].Parameter = P2_MAX;
	CfgItem[2].Value = P2Max;
	CfgItem[3].Parameter = P3_MIN;
	CfgItem[3].Value = P3Min;
	CfgItem[4].Parameter = P3_MAX;
	CfgItem[4].Value = P3Max;
	CfgItem[5].Parameter = P4_MIN;
	CfgItem[5].Value = P4min;
	CfgItem[6].Parameter = W5;
	CfgItem[6].Value = TW5;
	CfgItem[7].Parameter = TINIL;
	CfgItem[7].Value = TiniL;
	CfgItem[8].Parameter = TWUP;
	CfgItem[8].Value = TWuP;
	KwpRawFlag = 1;
	/*�ٳ����ÿ��ٳ�ʼ��*/
	if (InitLine == 3)/*ASC*/
	{
		if (ChanlHandle == NULL)/*Э�黹û�д� ��Э��*/
		{
			ChanlHandle = FkVciInitACAN(UciDeviceHandle, 0, BaudRate);
			if (ChanlHandle == NULL)
			{
					return ERR_DEVICE_NOT_CONNECTED;
			}
			else
			{

			}
		}
	}
	else if (InitLine == 0)/*K ��*/
	{
		//ActionChanlIdHandle = KlinChanlIdHandle;
		return ERR_NOT_SUPPORTED;

	}
	else/*�������߲�֧��*/
	{
		return ERR_NOT_SUPPORTED;
	}
	//��ʼ������
	for (int i = 0; i < 9; i++)
	{
		int ConfigRet = FkVciConfigACAN(ChanlHandle, SET_CONFIG, &CfgItem[i]);
		if (ConfigRet != STATUS_NOERROR)
			return ConfigRet;
	}
	/*���ж�Ӧ�ĳ�ʼ��*/
	if (InitType == 0)//No initialization. (This mode is used to set/alter communication parameters for the interface board without reestablishing)
	{
		return STATUS_NOERROR;
	}
	else if (InitType == 1)//5-baud initialization (is no longer supported. )
	{
		return ERR_NOT_SUPPORTED;
	}
	else if (InitType == 3)//Quick initialization
	{
		uint8_t buf[16];
		buf[0] = 0x81; /* Format(functional addressing, 1 byte payload), first Header byte */
		buf[1] = EcuAddr; /* Initialization address used to activate all ECUs, second Header byte */
		buf[2] = 0xF1; /* Scan Tool physical source address, third Header byte */
		buf[3] = 0x81; /* Start Communication Request Service Identifier, first Data byte */
		buf[4] = KWP2000_CheckSum(buf, 4);
		int ConfigRet = FkVciConfigACAN(ChanlHandle, FAST_INIT, buf);
		return ConfigRet;

	}
	else/*����ģʽ*/
	{
		return ERR_NOT_SUPPORTED;

	}
	return ERR_NOT_SUPPORTED;
}

long CANESB(uint8_t Variant, uint8_t Mode, uint32_t PatternCount, uint32_t ResponseLength, uint8_t*rddata, uint32_t Timeout)/*ESB ����*/
{

	if (Variant != 0)/*Variant = 0  250K */
	{
		return ERR_NOT_SUPPORTED;
	}
	uint8_t buf[32];
	if (Mode == 0)/*����ESB*/
	{		
		*(uint32_t*)buf = PatternCount;
		*(uint32_t*)(buf + 4) = ResponseLength;
		*(uint32_t*)(buf + 8) = Timeout;

		int ConfigRet = FkVciConfigACAN(ChanlHandle, CAN_ESB, &buf);
		return ConfigRet;
	}
	else if (Mode == 1)/*��ȡESB���*/
	{
		FkVciKwpDataType comblockData;
		int VciReciveRet = FkVciRecieveACAN(ChanlHandle, &comblockData, 1, Timeout);
		if (VciReciveRet != 0)
		{
			memcpy(rddata, comblockData.Data, comblockData.DLC);
			return STATUS_NOERROR;
		}
		else
		{
			return ERR_TIMEOUT;
		}
		
	}
	return ERR_NOT_SUPPORTED;
}

long TswFile(const char* FilePath, const char* FileName, uint8_t DataFormat,//�����ļ�·������
			uint32_t StartAddress, uint32_t BlockLength, //�����ļ�����
			uint8_t* SegmentHeader, uint16_t SegmentHeaderLen,//�����ļ�����ͷ��Ϣ
			uint8_t* SegmentEnd, uint16_t SegmentEndlen, //�����ļ�����β����Ϣ
	        uint16_t SegmentLength,  //�����������
	        uint8_t* PositiveResponse,uint16_t PostiveResponseLen)//���δ���󷵻�ȷ����Ϣ
{

	CCRC32 Crc32Handle;
	uint32_t Crc32Val;
	string PathString = FilePath;
	PathString += "\\";
	PathString += FileName;

	if (Crc32Handle.FileCrc32Win32(PathString.c_str(), Crc32Val) != 0)
	{
		return ERR_INVALID_FLAGS;/*�ļ�·������ û���ҵ�ָ���ļ�*/
	}
	uint8_t buf[512];
	memset(buf, 0, 512);
	*(uint32_t*)buf = Crc32Val;//
	strcpy_s((char*)(buf + 4),255, FileName);
	int ConfigRet;
	//FsCheckFormat
	 ConfigRet = FkVciConfigACAN(ChanlHandle, FS_CHECK, buf);//�����ļ�CRC �Ƿ�zhengque
	if (ConfigRet != STATUS_NOERROR)//
	{
		//FsClearFormat
		strcpy_s((char*)(buf), 255,FileName);//����ļ� ��λ���½�һ���ļ�
		ConfigRet = FkVciConfigACAN(ChanlHandle, FS_CLEAR, buf);//�����ļ�CRC �Ƿ�zhengque
		if (ConfigRet != STATUS_NOERROR)//
		{
			return ConfigRet;
		}
		else//�����ļ�
		{
			//����·����ȥ FsWriteFormat
			//PathString
			strcpy_s((char*)(buf), 255,PathString.c_str());//����ļ� ��λ���½�һ���ļ�
			ConfigRet = FkVciConfigACAN(ChanlHandle, FS_WRITE, buf);
			if (ConfigRet != STATUS_NOERROR)// �����ļ�����
			{
				return ConfigRet;
			}
		}
	}

	//FsTswCfgFormat
	FsTswCfgFormat *tswcfg = (FsTswCfgFormat*)buf;
	memset(tswcfg, 0, sizeof(FsTswCfgFormat));
	tswcfg->StartAddress = StartAddress;//���俪ʼ��ַ
	tswcfg->BlockLength = BlockLength;//�����ļ���С  0 Ϊ�����ļ�
	tswcfg->SegmentLength = SegmentLength;//
	tswcfg->SegmentHeaderLen = SegmentHeaderLen;
	memcpy(tswcfg->SegmentHeader, SegmentHeader, SegmentHeaderLen);//
	tswcfg->SegmentEndlen = SegmentEndlen;
	memcpy(tswcfg->SegmentEnd, SegmentEnd, SegmentEndlen);
	tswcfg->PostiveResponseLen = PostiveResponseLen;
	memcpy(tswcfg->PositiveResponse, PositiveResponse, PostiveResponseLen);

	ConfigRet = FkVciConfigACAN(ChanlHandle, TSW_CFG, buf);//�·�TSW ����
	if (ConfigRet != STATUS_NOERROR)//���ó���
	{
		return ConfigRet;
	}
	ConfigRet = FkVciConfigACAN(ChanlHandle, START_EXPROGSEQUEUE, buf);//����ˢд
	if (ConfigRet != STATUS_NOERROR)//���ó���
	{
		return ConfigRet;
	}

	return 0;
}


