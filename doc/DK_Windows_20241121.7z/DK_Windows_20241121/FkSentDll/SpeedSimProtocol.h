#pragma once
#include"BaseProtocol.h"
#include"FkSentDataDef.h"
enum
{
	WRITE_D_CMD = 0x01,
	WRITE_A_CMD = 0x02,
	READ_CMD = 0x03,
};


class SpeedSimProtocol : public BaseProtocol
{
	public:
		SpeedSimProtocol(void* drvhandle);
		~SpeedSimProtocol();
		void ProtocolDealMsg(void* msg);
		int TrsmitWithResponse(uint8_t* data, int len, uint32_t Timeout);
		int SpeedWriteData(uint8_t Chanl, WriteDataCmdDataType Data);
		int SpeedConfigAn(uint8_t Chanl, WriteAnCmdDataType AnData);
		int SpeedReadData(SpeedSimReadDataType *pData);
	private:

	uint8_t WorkMode;
};