#include"pch.h"
#include"SpeedSimProtocol.h"
#include"VciDebugCf.h"
#include"j2534_v0404.h"
#include"BaseDevice.h"

SpeedSimProtocol::SpeedSimProtocol(void* drvhandle)
{
	debugout("SpeedSimProtocol Create ...\r\n");
	DeviceDrvHandle = drvhandle;
	WorkMode = 0;
	ProtocolID = ePROTOCOL_SPEEDSIM;
	DataEventHandle = CreateEventA(
		NULL,		// default security attributes
		TRUE,		// manual-reset event
		FALSE,		// initial state is nonsignaled
		NULL);		// object name
	CommondEventHandle = CreateEventA(
		NULL,		// default security attributes
		TRUE,		// manual-reset event
		FALSE,		// initial state is nonsignaled
		NULL);		// object name
}

SpeedSimProtocol::~SpeedSimProtocol()
{
	debugout("SpeedSimProtocol Delete ...\r\n");
}
/// <summary>
/// 
/// </summary>
/// <param name="msg"></param>
void SpeedSimProtocol::ProtocolDealMsg(void* msg)
{
	debugout("SpeedSimProtocol ProtocolDealMsg Chanl:%d...\r\n", ChanlNum);

	ProtocolDataType* ResponseDataPtr = (ProtocolDataType*)msg;//�����յ�������ת��ΪЭ������
	if (CommondCheckBuf[0] != ResponseDataPtr->protocolid)//�����Ϊ��Э��ͨ�����ݲ������� ֱ�ӷ���
	{
		return;
	}

	/*��֤�Ƿ�Ϊָ��ر���*/
	if (
		CommondCheckBuf[1] == ResponseDataPtr->protocolcmd //��ǰ�����Command
		)//��ǰ����� ͨ��
	{
		debugout("Recieve CommondCheck Msg...\r\n");
		memcpy(CommondCheckBuf, msg, (ResponseDataPtr->datalen + 6));
		SetEvent(CommondEventHandle);
	}
	else//Э������
	{
		debugout("DEV�������͵���Ϣ...\r\n");
		///*�����ݴ����PassThruMsg ����ŵ�������*/
		//if (
		//	CMDCODE_RXMSG == ResponseDataPtr->protocolcmd
		//	)/*PROTOCOL_ACAN ����*/
		//{
		//	debugout("Recevie One Can Msg...\r\n");

		//	//����Ҫ���� ������  ��ǰ������KWPģʽ�� ���� RAWģʽ��  ��λ��һֱ������RAW ģʽ��

		//	FkVciDataType msgrx;
		//	memcpy((void*)&msgrx, ResponseDataPtr->pData, ResponseDataPtr->datalen);/*���� ���ݵ� FkVciDataType ��*/
		//	PushMsg(msgrx);
		//	SetEvent(DataEventHandle);
		//}
	}
}
/// <summary>
/// 
/// </summary>
/// <param name="data"></param>
/// <param name="len"></param>
/// <param name="Timeout"></param>
/// <returns></returns>
int SpeedSimProtocol::TrsmitWithResponse(uint8_t* data, int len, uint32_t Timeout)
{
	if (DeviceDrvHandle != NULL)/*�豸��Ϊ��*/
	{
		BaseDevice* dev = (BaseDevice*)DeviceDrvHandle;//��ȡӲ�����
		ProtocolDataType* ReqDataPtr = (ProtocolDataType*)data;
		ProtocolDataType* ResponseDataPtr = (ProtocolDataType*)CommondCheckBuf; //������ת��ΪЭ������
		ResetEvent(CommondEventHandle);//����յ�֮ǰ��event����
		ResponseDataPtr->protocolid = ReqDataPtr->protocolid;//Э��ID
		ResponseDataPtr->protocolcmd = ReqDataPtr->protocolcmd;//Э�鹦��
		ResponseDataPtr->protocolchanl = ReqDataPtr->protocolchanl;//Э��ͨ��

		dev->DevTrsmit(data, len);
		/*�ȴ�DEV�������ݲ��ж�*/
		if (WaitForSingleObjectEx(CommondEventHandle, Timeout, true) == WAIT_OBJECT_0)/*�ȴ��豸�ͷ�*/
		{
			//��ȡbuf�е����ݲ��ж����
			if (ResponseDataPtr->pData[0] != 0)
			{
				debugout("TrsmitWithResponse ErrCode:%02X\r\n", ResponseDataPtr->pData[0]);
				return ERRCODE_FAILED;
			}
			ResetEvent(CommondEventHandle);
		}
		else//�ȴ���ʱ
		{
			debugout("TrsmitWithResponse WaitRspMsg TimeOut!\r\n");
			return ERRCODE_TIMEOUT;

		}
	}
	else
	{
		debugout("Device Is Null\r\n");
		return ERRCODE_INVALID_DEVICE_ID;

	}
	debugout("TrsmitWithResponse Sucess!\r\n");
	return ERRCODE_NOERR;
}




int SpeedSimProtocol::SpeedWriteData(uint8_t Chanl, WriteDataCmdDataType Data)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = Chanl;
	ReqDataPtr->protocolcmd = WRITE_D_CMD;
	ReqDataPtr->protocolid = ePROTOCOL_SPEEDSIM;
	ReqDataPtr->datalen = (uint16_t)(sizeof(WriteDataCmdDataType));
	memcpy((ReqDataPtr->pData), &Data, sizeof(WriteDataCmdDataType));
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}

int SpeedSimProtocol::SpeedConfigAn(uint8_t Chanl, WriteAnCmdDataType AnData)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = Chanl;
	ReqDataPtr->protocolcmd = WRITE_A_CMD;
	ReqDataPtr->protocolid = ePROTOCOL_SPEEDSIM;
	ReqDataPtr->datalen = (uint16_t)(sizeof(SpeedSimReadDataType));
	memcpy((ReqDataPtr->pData), &AnData, sizeof(SpeedSimReadDataType));
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}


int SpeedSimProtocol::SpeedReadData(SpeedSimReadDataType* pData)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = 0x00;
	ReqDataPtr->protocolcmd = READ_CMD;
	ReqDataPtr->protocolid = ePROTOCOL_SPEEDSIM;
	ReqDataPtr->datalen = 0;
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	if (Ret == 0)
	{			
		memcpy(pData, CommondCheckBuf+6,sizeof(SpeedSimReadDataType));	
	}
	return Ret;
}
