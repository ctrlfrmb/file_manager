#include "pch.h"
#include "ComDevice.h"
#include "FkVciDll.h"
#include "VciDebugCf.h"
#include "BaseProtocol.h"
#include <chrono>

#define READ_BUFFER_MAX_LENGTH 5120

using high_clock = std::chrono::high_resolution_clock;

ComDevice::ComDevice()
{
	debugout("ComDevice Create ...\r\n");
	DeviceType = eCOM;
}

ComDevice::~ComDevice()
{
	if(connected)
	{	
		CloseHandle(hSerial);
		connected = false; 
	}
	debugout("ComDevice Delete ...\r\n");
}

//int ComDevice::DevOpen(void* pName)
//{
//	char* str = (char*)pName;
//	debugout("ComDevice DevOpen %s ...\r\n",str);
//	/*�ȴ�Ӳ���豸�ӿ� ��LPCWSTR*/
//	hSerial = CreateFile((const char*)pName, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
//	if (hSerial == INVALID_HANDLE_VALUE) {
//		if (GetLastError() == ERROR_FILE_NOT_FOUND) {
//			//std::cout << "Serial port does not exist." << std::endl;
//			debugout("Serial port does not exist ...\r\n");
//		}
//		else {
//			/*std::cout << "Error opening serial port." << std::endl;*/
//			debugout("Error opening serial port ...\r\n");
//		}
//		connected = false;
//		return ERRCODE_OPENDEV_FAILED;
//	}
//
//	DCB dcbSerialParams = { 0 };
//	dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
//	if (!GetCommState(hSerial, &dcbSerialParams)) {
//		debugout("Error getting serial port state ...\r\n");
//		//std::cout << "Error getting serial port state." << std::endl;            
//		CloseHandle(hSerial);
//		connected = false;
//		return ERRCODE_MEMERR;
//	}
//	dcbSerialParams.BaudRate = CBR_115200;
//	dcbSerialParams.ByteSize = 8;
//	dcbSerialParams.StopBits = ONESTOPBIT;
//	dcbSerialParams.Parity = NOPARITY;
//	if (!SetCommState(hSerial, &dcbSerialParams)) {
//		//std::cout << "Error setting serial port state." << std::endl;
//		debugout("Error setting serial port state ...\r\n");
//		CloseHandle(hSerial);
//		connected = false;
//		return ERRCODE_MEMERR;
//	}
//
//
//	COMMTIMEOUTS timeouts;
//	GetCommTimeouts(hSerial, &timeouts);
//	timeouts.ReadIntervalTimeout = 5;
//	timeouts.ReadTotalTimeoutConstant = 5;
//	timeouts.ReadTotalTimeoutMultiplier = 0;
//
//	//timeouts.WriteTotalTimeoutConstant = 10;
//	//timeouts.WriteTotalTimeoutMultiplier = 0;
//
//	SetCommTimeouts(hSerial, &timeouts);
//
//	connected = true;
//	/*��������ɹ� ����һ���߳� �첽��������  ���� LanDev_RxProcess*/
//	return CreateRecieveThread();
//}


int ComDevice::DevClose()
{
	debugout("ComDevice DevClose ...\r\n");

	if (DevRecieveRunFlag)
	{
		ClearProtocol();//�ȹص����е�DEV ���ٵ�Э��
		DevRecieveRunFlag = 0;//����رս����߳�
		if (WaitForSingleObjectEx(hDevRecieveThreadExitResponseHandler, 1000, true) == WAIT_OBJECT_0)/*�ȴ��豸�ͷ�*/
		{
			CloseHandle(hSerial);
			connected = false;
		}
	}
	return ERRCODE_NOERR;
}

bool ComDevice::ConfigureSerialPort() {
	// ���ô��ڻ�����
	if (!SetupComm(hSerial, READ_BUFFER_MAX_LENGTH, READ_BUFFER_MAX_LENGTH)) {
		debugout("Error setting up comm buffer\r\n");
		return false;
	}

	// ����DCB
	DCB dcbSerialParams = { 0 };
	dcbSerialParams.DCBlength = sizeof(dcbSerialParams);
	if (!GetCommState(hSerial, &dcbSerialParams)) {
		debugout("Error getting comm state\r\n");
		return false;
	}

	dcbSerialParams.BaudRate = 512000; // CBR_115200;
	dcbSerialParams.ByteSize = 8;
	dcbSerialParams.StopBits = ONESTOPBIT;
	dcbSerialParams.Parity = NOPARITY;

	// ����������
	dcbSerialParams.fOutxCtsFlow = FALSE;
	dcbSerialParams.fRtsControl = RTS_CONTROL_DISABLE;
	dcbSerialParams.fOutX = FALSE;
	dcbSerialParams.fInX = FALSE;

	if (!SetCommState(hSerial, &dcbSerialParams)) {
		debugout("Error setting comm state\r\n");
		return false;
	}

	// ���ó�ʱ
	COMMTIMEOUTS timeouts = { 0 };
	timeouts.ReadIntervalTimeout = 1;        // �ַ��䳬ʱ
	timeouts.ReadTotalTimeoutConstant = 1;   // �ܳ�ʱ����
	timeouts.ReadTotalTimeoutMultiplier = 0; // ���û����ֽ����ĳ�ʱ
	timeouts.WriteTotalTimeoutConstant = 50;
	timeouts.WriteTotalTimeoutMultiplier = 0;

	if (!SetCommTimeouts(hSerial, &timeouts)) {
		debugout("Error setting timeouts\r\n");
		return false;
	}

	// ��ջ�����
	PurgeComm(hSerial, PURGE_RXCLEAR | PURGE_TXCLEAR);

	return true;
}

int ComDevice::DevOpen(void* pName) {
	char* str = (char*)pName;
	debugout("ComDevice DevOpen %s ...\r\n", str);

	hSerial = CreateFile((const char*)pName,
		GENERIC_READ | GENERIC_WRITE,
		0,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL);

	if (hSerial == INVALID_HANDLE_VALUE) {
		debugout("Error opening serial port\r\n");
		connected = false;
		return ERRCODE_OPENDEV_FAILED;
	}

	if (!ConfigureSerialPort()) {
		CloseHandle(hSerial);
		connected = false;
		return ERRCODE_MEMERR;
	}

	connected = true;
	return CreateRecieveThread();
}

bool ComDevice::ReadSerialPort() {
	if (!connected) return false;

	DWORD bytesRead = 0;
	uint8_t tempBuffer[READ_BUFFER_MAX_LENGTH];

	DWORD errors;
	COMSTAT status;
	ClearCommError(hSerial, &errors, &status);

	if (status.cbInQue > 0) {
		if (ReadFile(hSerial, tempBuffer, min(status.cbInQue, READ_BUFFER_MAX_LENGTH), &bytesRead, NULL)) {

			printf("read %llu\n", std::chrono::duration_cast<std::chrono::microseconds>(high_clock::now().time_since_epoch()).count());

			if (bytesRead > 0) {
				for (DWORD i = 0; i < bytesRead; ++i) {
					buffer.push_back(tempBuffer[i]);
				}
				return true;
			}
		}
	}

	return false;
}

bool ComDevice::ExtractFrame(std::vector<uint8_t>& frame) {
	while (buffer.size() >= 8) {
		// ����֡ͷ 0x55 0xAA
		if (buffer[0] == 0x55 && buffer[1] == 0xAA) {
			// ��ȡ���ݳ���
			uint16_t dataLength = buffer[6] | (buffer[7] << 8);
			size_t totalFrameSize = 8 + dataLength + 1;

			if (buffer.size() >= totalFrameSize) {
				frame.assign(buffer.begin(), buffer.begin() + totalFrameSize);
				buffer.erase(buffer.begin(), buffer.begin() + totalFrameSize);
				return true;
			}
			return false;  // ���ݲ���
		}
		buffer.pop_front();  // �Ƴ���Ч����
	}
	return false;
}

int ComDevice::DevTrsmit(const uint8_t* data, int len) {
	if (!connected) return ERRCODE_FAILED;

	uint8_t txbuf[READ_BUFFER_MAX_LENGTH];
	txbuf[0] = 0xAA;
	txbuf[1] = 0x55;
	memcpy(txbuf + 2, data, len);
	txbuf[2 + len] = DataCheckSum(txbuf, len);

	DWORD bytesWritten;
	if (!WriteFile(hSerial, txbuf, len + 3, &bytesWritten, NULL)) {
		debugout("Error writing to serial port\r\n");
		return ERRCODE_FAILED;
	}

	// �ȴ����ݷ������
	FlushFileBuffers(hSerial);

	debugout("SendReq:%d SendRet:%d\r\n", (len + 3), bytesWritten);
	return ERRCODE_NOERR;
}

int ComDevice::DevRecieve()
{
	//debugout("ComDevice DevRecieve ...\r\n");
	uint8_t buf[READ_BUFFER_MAX_LENGTH];//50K 
	if (DevDataToPcCov(buf))//����һ����ɵı���
	{
		for (int i = 0; i < MAX_PROTOCOL_NUM; i++)/*��ѯÿ��Э�鲢����*/
		{
			if (ProtocolTab[i] != NULL)/*ʹ��Э�鴦������*/
			{
				BaseProtocol* Protocol = (BaseProtocol*)ProtocolTab[i];
				Protocol->ProtocolDealMsg((buf + 2));//ȥ��ͷ��Ϣ����Э�鴦��
			}
		}
	}
	else
	{
		return ERRCODE_LANRECERR;
	}
	return ERRCODE_NOERR;
}

uint8_t ComDevice::DataCheckSum(const uint8_t* buf, int len)
{
	return 0;
}

//// �Ӵ��ڶ�ȡ���ݵ�������
//bool ComDevice::ReadSerialPort() {
//	DWORD bytesRead;
//	uint8_t buf[READ_BUFFER_MAX_LENGTH]; // ���������㹻��Ļ�����
//	if (!ReadFile(hSerial, buf, sizeof(buf), &bytesRead, NULL)) {
//		// ��ȡʧ��
//		return false;
//	}
//
//	printf("read %llu\n", std::chrono::duration_cast<std::chrono::microseconds>(high_clock::now().time_since_epoch()).count());
//
//	// ����ȡ���������ӵ�������
//	for (size_t i = 0; i < bytesRead; ++i) {
//		buffer.push_back(buf[i]);
//	}
//	return true;
//}

// ��鲢��ȡ������һ֡
//bool ComDevice::ExtractFrame(std::vector<uint8_t>& frame) {
//	// ѭ��ֱ�������������㹻������
//	while (buffer.size() >= 8) {
//		// ���֡ͷ
//		if (buffer[0] == 0x55 && buffer[1] == 0xAA) {
//			// ��ȡ���ݳ���
//			uint16_t dataLength = buffer[6] | (buffer[7] << 8);
//			size_t totalFrameSize = 8 + dataLength + 1; // ������֡����
//
//			// ��黺�������Ƿ����㹻������
//			if (buffer.size() >= totalFrameSize) {
//				// ��ȡ����֡
//				frame.assign(buffer.begin(), buffer.begin() + totalFrameSize);
//				buffer.erase(buffer.begin(), buffer.begin() + totalFrameSize); // �Ƴ��Ѵ���������
//				return true;
//			}
//			else {
//				// �������е����ݲ����Թ�������֡
//				return false;
//			}
//		}
//		else {
//			// ����֡ͷ���Ƴ�һ���ֽ�
//			buffer.pop_front();
//		}
//	}
//	return false;
//}

#if 1

bool ComDevice::DevDataToPcCov(uint8_t* buf) {
	std::vector<uint8_t> frame;  // ����֡����

	while (DevRecieveRunFlag && buffer.size() < READ_BUFFER_MAX_LENGTH) {
		if (!connected) return false;

		if (ReadSerialPort()) {
			if (ExtractFrame(frame)) {
				std::copy(frame.begin(), frame.end(), buf);
				return true;
			}
		}
		else {
			Sleep(1);  // ����CPUռ�ù���
		}
	}

	return false;
}

//bool ComDevice::DevDataToPcCov(uint8_t* buf) {
//	std::vector<uint8_t> frame; // ����֡����
//
//	while ( (0 != DevRecieveRunFlag) && (buffer.size() < READ_BUFFER_MAX_LENGTH)) {
//		if (ReadSerialPort()) {
//			if ((0 == DevRecieveRunFlag) || !connected)
//				return false;
//
//			if (ExtractFrame(frame)) {
//				// �ɹ���ȡ������֡
//				std::copy(frame.begin(), frame.end(), buf); // ��֡���ݸ��Ƶ�buf
//				return true;
//			}
//		}
//		else {
//			// ��ȡʧ�ܴ���
//			return false;
//		}
//	}
//
//	return false;
//}
#else

bool ComDevice::DevDataToPcCov(uint8_t* buf)
{
	DWORD recnum;
	
	//unsigned char* ptr;
	//int recnum = recv(sockclient, (char*)buf, 1, 0);//�Ƚ���7���ֽ�  ���յ����ȵ�λ��
	if (!ReadFile(hSerial, buf, 1, &recnum, NULL)) {
		debugout("Error reading from serial port when read buffer 0.\n");
		return false;
	}
	if (recnum == 0 || (uint8_t)buf[0] != 0x55) {
		//debugout("receive error : number %d, data 0 is %02x\n", recnum, buf[0]);
		return false;
	}

	//recnum = recv(sockclient, (char*)(buf + 1), 1, 0);//�Ƚ���7���ֽ�  ���յ����ȵ�λ��
	if (!ReadFile(hSerial, (char*)(buf + 1), 1, &recnum, NULL)) 
	{
		debugout("Error reading from serial port when read buffer 1.\n");
		return false;
	}

	if ((uint8_t)buf[1] != 0xAA) {
		debugout("receive error : data 1 is %02x\n", buf[1]);
		return false;
	}

	if ((uint8_t)buf[0] == (uint8_t)0x55 && (uint8_t)buf[1] == (uint8_t)0xAA)//
	{
		//recnum = recv(sockclient, (char*)(buf + 2), 6, 0);//�Ƚ���7���ֽ�  ���յ����ȵ�λ��
		for (int i = 2; i < 8; ) {
			if (!ReadFile(hSerial, (char*)(buf + i), 8-i, &recnum, NULL)) {
				debugout("Error reading from serial port when read buffer %d.\n", i);
				return false;
			}
			i += recnum;
		}

		uint16_t msgnum = *(uint16_t*)(buf + 6) + 1;
		for (int i = 0; i < msgnum; ) {
			if (!ReadFile(hSerial, (char*)(buf + (8 + i)), msgnum - i, &recnum, NULL)) {
				debugout("Error reading from serial port when read buffer %d.\n", i);
				return false;
			}
			i += recnum;
		}

		return true;
		/*if (!ReadFile(hSerial, (char*)(buf + 2), 6, &recnum, NULL)) {
			debugout("Error reading from serial port by buffer 2.\n");
			return false;
		}*/

		//if (recnum == 6)
		//{
		//	ptr = (unsigned char*)buf;
		//	uint16_t msgnum = *(uint16_t*)(buf + 6) + 1;
		//	//recnum = recv(sockclient, (char*)(buf + 8), msgnum, 0);//����Э��ʣ��ĳ���
		//	if (!ReadFile(hSerial, (char*)(buf + 8), msgnum, &recnum, NULL)) {
		//		debugout("Error reading from serial port by buffer 8.\n");
		//		return false;
		//	}
		//	if (recnum == msgnum)//���յ�ʣ�������
		//	{
		//		return true;
		//	}
		//	else//����ʧ��
		//	{
		//		debugout("Com Device Recieve Data Timeout , message number %d ...\r\n ", msgnum);
		//		return false;
		//	}
		//}
		//else
		//{
		//	debugout("Com Device Recieve Cmd And Len Timeout, receive number %d  ...\r\n ", recnum);
		//	return false;
		//}
	}
	else
	{
		return false;//û�н��յ�ָ��������
	}
}

#endif