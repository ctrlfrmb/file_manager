#include"pch.h"
#include"DkSent.h"
#include"VciDebugCf.h"
#include"j2534_v0404.h"
#include"BaseDevice.h"

DkSent::DkSent(void* drvhandle)
{
	debugout("DkSent Create ...\r\n");
	DeviceDrvHandle = drvhandle;
	WorkMode = 0;
	ProtocolID = ePROTOCOL_SENT;
	DataEventHandle = CreateEventA(
		NULL,		// default security attributes
		TRUE,		// manual-reset event
		FALSE,		// initial state is nonsignaled
		NULL);		// object name
	CommondEventHandle = CreateEventA(
		NULL,		// default security attributes
		TRUE,		// manual-reset event
		FALSE,		// initial state is nonsignaled
		NULL);		// object name
}

DkSent::~DkSent()
{
	debugout("DkSent Delete ...\r\n");

}
/// <summary>
/// 
/// </summary>
/// <param name="msg"></param>
void DkSent::ProtocolDealMsg(void* msg)
{
	debugout("DkSent ProtocolDealMsg Chanl:%d...\r\n", ChanlNum);

	ProtocolDataType* ResponseDataPtr = (ProtocolDataType*)msg;//�����յ�������ת��ΪЭ������
	if (CommondCheckBuf[0] != ResponseDataPtr->protocolid)//�����Ϊ��Э��ͨ�����ݲ������� ֱ�ӷ���
	{
		return;
	}

	/*��֤�Ƿ�Ϊָ��ر���*/
	if (
		CommondCheckBuf[1] == ResponseDataPtr->protocolcmd //��ǰ�����Command
		)//��ǰ����� ͨ��
	{
		debugout("Recieve CommondCheck Msg...\r\n");
		memcpy(CommondCheckBuf, msg, (ResponseDataPtr->datalen + 6));
		SetEvent(CommondEventHandle);
	}
	else//Э������
	{
		debugout("DEV�������͵���Ϣ...\r\n");
		///*�����ݴ����PassThruMsg ����ŵ�������*/
		//if (
		//	CMDCODE_RXMSG == ResponseDataPtr->protocolcmd
		//	)/*PROTOCOL_ACAN ����*/
		//{
		//	debugout("Recevie One Can Msg...\r\n");

		//	//����Ҫ���� ������  ��ǰ������KWPģʽ�� ���� RAWģʽ��  ��λ��һֱ������RAW ģʽ��

		//	FkVciDataType msgrx;
		//	memcpy((void*)&msgrx, ResponseDataPtr->pData, ResponseDataPtr->datalen);/*���� ���ݵ� FkVciDataType ��*/
		//	PushMsg(msgrx);
		//	SetEvent(DataEventHandle);
		//}
	}
}
/// <summary>
/// 
/// </summary>
/// <param name="data"></param>
/// <param name="len"></param>
/// <param name="Timeout"></param>
/// <returns></returns>
int DkSent::TrsmitWithResponse(uint8_t* data, int len, uint32_t Timeout)
{
	if (DeviceDrvHandle != NULL)/*�豸��Ϊ��*/
	{
		std::lock_guard<std::mutex> locker(rwMutex);

		BaseDevice* dev = (BaseDevice*)DeviceDrvHandle;//��ȡӲ�����
		ProtocolDataType* ReqDataPtr = (ProtocolDataType*)data;
		ProtocolDataType* ResponseDataPtr = (ProtocolDataType*)CommondCheckBuf; //������ת��ΪЭ������
		ResetEvent(CommondEventHandle);//����յ�֮ǰ��event����
		ResponseDataPtr->protocolid = ReqDataPtr->protocolid;//Э��ID
		ResponseDataPtr->protocolcmd = ReqDataPtr->protocolcmd;//Э�鹦��
		ResponseDataPtr->protocolchanl = ReqDataPtr->protocolchanl;//Э��ͨ��

		dev->DevTrsmit(data, len);
		/*�ȴ�DEV�������ݲ��ж�*/
		if (WaitForSingleObjectEx(CommondEventHandle, Timeout, true) == WAIT_OBJECT_0)/*�ȴ��豸�ͷ�*/
		{
			////��ȡbuf�е����ݲ��ж����
			//if (ResponseDataPtr->pData[0] != 0)
			//{
			//	debugout("TrsmitWithResponse ErrCode:%02X\r\n", ResponseDataPtr->pData[0]);
			//	return ERRCODE_FAILED;
			//}
			ResetEvent(CommondEventHandle);
		}
		else//�ȴ���ʱ
		{
			debugout("TrsmitWithResponse WaitRspMsg TimeOut!\r\n");
			return ERRCODE_TIMEOUT;

		}
	}
	else
	{
		debugout("Device Is Null\r\n");
		return ERRCODE_INVALID_DEVICE_ID;

	}
	debugout("TrsmitWithResponse Sucess!\r\n");
	return ERRCODE_NOERR;
}


/*
CoverMode:0 is Api Wirte      1 is ADCover To Data
DataFomat:0 is 12 + 12  1 14 +10  2 is 16 + 8   ��������CAN�����ʽ�����������
*/
//AA 55 00 10 01 00 02 00 00 00 00
int DkSent::DkSentInit(uint8_t chanl, uint8_t CoverMode, uint8_t DataFomat, uint8_t Val)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = chanl;
	ReqDataPtr->protocolcmd = DK_INIT;
	ReqDataPtr->protocolid = ePROTOCOL_SENT;
	ReqDataPtr->datalen = 3;
	ReqDataPtr->pData[0] = CoverMode;
	ReqDataPtr->pData[1] = DataFomat;
	ReqDataPtr->pData[2] = Val;
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}

/**/
int DkSent::DkSentWriteChanl(uint8_t chanl, DkMsgDataType* pData)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = chanl;
	ReqDataPtr->protocolcmd = DK_WRITECHANL;
	ReqDataPtr->protocolid = ePROTOCOL_SENT;
	ReqDataPtr->datalen = 8;
	memcpy((ReqDataPtr->pData), pData, 8);
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}

int DkSent::DkSentWriteChanlAll(DkMsgDataType* pDataCh1, DkMsgDataType* pDataCh2)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = 0;
	ReqDataPtr->protocolcmd = DK_WRITEALL;
	ReqDataPtr->protocolid = ePROTOCOL_SENT;
	ReqDataPtr->datalen = 16;
	memcpy((ReqDataPtr->pData), pDataCh1, 8);
	memcpy((ReqDataPtr->pData+8), pDataCh2, 8);
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;
}



/*
�ر����
*/
int DkSent::DkSentDeInit(uint8_t chanl)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = chanl;
	ReqDataPtr->protocolcmd = DK_DEINIT;
	ReqDataPtr->protocolid = ePROTOCOL_SENT;
	ReqDataPtr->datalen = 0;
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	return Ret;

}

/*
��ȡ������ǰͨ���Ĵ�����ֵ

*/
struct RspDkDataType
{
	uint8_t Nb0 : 4;
	uint8_t Stus :4;
	uint8_t Nb2 : 4;
	uint8_t Nb1 : 4;

	uint8_t Nb3 : 4;
	uint8_t CRC : 4;
	uint8_t Nb5 : 4;
	uint8_t Nb4 : 4;
};


int DkSent::DkSentReadData(DkMsgRdDataType*pReadBackChanl1 , DkMsgRdDataType * pReadBackChanl2)
{
	uint8_t txbuf[64];
	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
	ReqDataPtr->protocolchanl = 0x00;
	ReqDataPtr->protocolcmd = DK_READ;
	ReqDataPtr->protocolid = ePROTOCOL_SPEEDSIM;
	ReqDataPtr->datalen = 0;
	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
	if (Ret == 0)
	{
		RspDkDataType rxData[2];
		memcpy(rxData, CommondCheckBuf + 6, sizeof(RspDkDataType) * 2);
		pReadBackChanl1->Stus = rxData[0].Stus;
		pReadBackChanl1->Nb0 = rxData[0].Nb0;
		pReadBackChanl1->Nb1 = rxData[0].Nb1;
		pReadBackChanl1->Nb2 = rxData[0].Nb2;
		pReadBackChanl1->Nb3 = rxData[0].Nb3;
		pReadBackChanl1->Nb4 = rxData[0].Nb4;
		pReadBackChanl1->Nb5 = rxData[0].Nb5;
		pReadBackChanl1->CRC = rxData[0].CRC;

		pReadBackChanl2->Stus = rxData[1].Stus;
		pReadBackChanl2->Nb0 = rxData[1].Nb0;
		pReadBackChanl2->Nb1 = rxData[1].Nb1;
		pReadBackChanl2->Nb2 = rxData[1].Nb2;
		pReadBackChanl2->Nb3 = rxData[1].Nb3;
		pReadBackChanl2->Nb4 = rxData[1].Nb4;
		pReadBackChanl2->Nb5 = rxData[1].Nb5;
		pReadBackChanl2->CRC = rxData[1].CRC;
		//memcpy(pReadBackChanl1, CommondCheckBuf + 6, sizeof(DkMsgRdDataType));
		//memcpy(pReadBackChanl2, CommondCheckBuf + 6+ sizeof(DkMsgRdDataType), sizeof(DkMsgRdDataType));
	}
	return Ret;

}



//int DkSent::SpcWriteFsDataToBuf(uint8_t Chanl, uint8_t Index, FastDataType* pData)
//{
//	uint8_t txbuf[64];
//	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
//	ReqDataPtr->protocolchanl = Chanl;
//	ReqDataPtr->protocolcmd = WR_FASTDATA_BUF;
//	ReqDataPtr->protocolid = ePROTOCOL_SENT;
//	ReqDataPtr->datalen = 9;
//	ReqDataPtr->pData[0] = Index;
//	memcpy((ReqDataPtr->pData + 1), pData, 8);
//	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
//	return Ret;
//}
//
//
//int DkSent::SpcWriteSlDataToBuf(uint8_t Chanl, uint8_t Index, SlowDataType* pData)
//{
//	uint8_t txbuf[64];
//	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
//	ReqDataPtr->protocolchanl = Chanl;
//	ReqDataPtr->protocolcmd = WR_SLOWDATA_BUF;
//	ReqDataPtr->protocolid = ePROTOCOL_SENT;
//	ReqDataPtr->datalen = 5;
//	ReqDataPtr->pData[0] = Index;
//	memcpy((ReqDataPtr->pData + 1), pData, 4);
//	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
//	return Ret;
//}
//int DkSent::SpcCfgTimeMode(uint8_t Chanl, uint8_t IdleEnFlang, uint8_t RollingModeFlag, uint16_t CycleCnt)
//{
//	uint8_t txbuf[64];
//	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
//	ReqDataPtr->protocolchanl = Chanl;
//	ReqDataPtr->protocolcmd = WR_SPC_TIMEMODE;
//	ReqDataPtr->protocolid = ePROTOCOL_SENT;
//	ReqDataPtr->datalen = 4;
//
//	ReqDataPtr->pData[0] = IdleEnFlang;
//	ReqDataPtr->pData[1] = RollingModeFlag;
//	ReqDataPtr->pData[2] = (uint8_t)(CycleCnt & 0xff);
//	ReqDataPtr->pData[3] = (uint8_t)((CycleCnt >> 8) & 0xff);
//
//	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
//	return Ret;
//}
//
//int DkSent::SpcCfgTrigerMode(uint8_t Chanl, uint8_t RollingModeFlag, uint8_t DelayOutPutTick, uint8_t SlotID, uint8_t TotalSlotNum)
//{
//	uint8_t txbuf[64];
//	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
//	ReqDataPtr->protocolchanl = Chanl;
//	ReqDataPtr->protocolcmd = WR_SPC_TRIGERMODE;
//	ReqDataPtr->protocolid = ePROTOCOL_SENT;
//	ReqDataPtr->datalen = 4;
//	ReqDataPtr->pData[0] = RollingModeFlag;
//	ReqDataPtr->pData[1] = DelayOutPutTick;
//	ReqDataPtr->pData[2] = SlotID;
//	ReqDataPtr->pData[3] = TotalSlotNum;
//	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
//	return Ret;
//}
//
//int DkSent::SpcMsgCfg(uint8_t Chanl, uint8_t SyncTick, uint8_t TickVal)
//{
//	uint8_t txbuf[64];
//	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
//	ReqDataPtr->protocolchanl = Chanl;
//	ReqDataPtr->protocolcmd = WR_SPC_MSGTYPE;
//	ReqDataPtr->protocolid = ePROTOCOL_SENT;
//	ReqDataPtr->datalen = 2;
//	ReqDataPtr->pData[0] = SyncTick;
//	ReqDataPtr->pData[1] = TickVal;
//	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
//	return Ret;
//}
//
//int DkSent::SpcOutPutCfg(uint8_t Chanl, uint8_t TrsmitEnFlag, uint8_t StusValue, uint8_t TotoalFsMsgNum, uint8_t TotoalSlMsgNum)
//{
//	uint8_t txbuf[64];
//	ProtocolDataType* ReqDataPtr = (ProtocolDataType*)txbuf;
//	ReqDataPtr->protocolchanl = Chanl;
//	ReqDataPtr->protocolcmd = WR_SPC_OUTPUT;
//	ReqDataPtr->protocolid = ePROTOCOL_SENT;
//	ReqDataPtr->datalen = 4;
//	ReqDataPtr->pData[0] = TrsmitEnFlag;
//	ReqDataPtr->pData[1] = StusValue;
//	ReqDataPtr->pData[2] = TotoalFsMsgNum;
//	ReqDataPtr->pData[3] = TotoalSlMsgNum;
//	int Ret = TrsmitWithResponse(txbuf, (ReqDataPtr->datalen + 6), 100);
//	return Ret;
//}
