#include"pch.h"
#include <fstream>
#include"AcanProtocol.h"
#include"BaseDevice.h"
#include"VciDebugCf.h"
#include"j2534_v0404.h"
AcanProtocol::AcanProtocol(void* drvhandle, uint8_t Chanl)
{
	debugout("AcanProtocol Create ...\r\n");
	DeviceDrvHandle = drvhandle;
	ChanlNum = Chanl;
	WorkMode = 0;
	ProtocolID = ePROTOCOL_ASC;
	DataEventHandle = CreateEventA(
		NULL,		// default security attributes
		TRUE,		// manual-reset event
		FALSE,		// initial state is nonsignaled
		NULL);		// object name
	CommondEventHandle = CreateEventA(
		NULL,		// default security attributes
		TRUE,		// manual-reset event
		FALSE,		// initial state is nonsignaled
		NULL);		// object name
}

AcanProtocol::~AcanProtocol()
{
	debugout("AcanProtocol Delete ...\r\n");

}
/// <summary>
/// 
/// </summary>
/// <param name="msg"></param>
void AcanProtocol::ProtocolDealMsg(void* msg)
{
	debugout("AcanProtocol ProtocolDealMsg ...\r\n");

	ProtocolDataType* ResponseDataPtr = (ProtocolDataType*)msg;//�����յ�������ת��ΪЭ������
	/*��֤�Ƿ�Ϊָ��ر���*/
	if (CommondCheckBuf[0] == ResponseDataPtr->protocolid //��ǰ�����Э��
	 && CommondCheckBuf[1] == ResponseDataPtr->protocolcmd //��ǰ�����Command
	 && CommondCheckBuf[2] == ResponseDataPtr->protocolchanl)//��ǰ����� ͨ��
	{
		debugout("Recieve CommondCheck Msg...\r\n");
		memcpy(CommondCheckBuf, msg, (ResponseDataPtr->datalen+6));
		SetEvent(CommondEventHandle);
	}
	else//Э������
	{
		debugout("DEV�������͵���Ϣ...\r\n");
		/*�����ݴ����PassThruMsg ����ŵ�������*/		
		if (ePROTOCOL_ASC == ResponseDataPtr->protocolid
			&& CMDCODE_RXMSG == ResponseDataPtr->protocolcmd
			&& ChanlNum == ResponseDataPtr->protocolchanl )/*PROTOCOL_ACAN ����*/
		{
			debugout("Recevie One Can Msg...\r\n");

			//����Ҫ���� ������  ��ǰ������KWPģʽ�� ���� RAWģʽ��  ��λ��һֱ������RAW ģʽ��

			FkVciDataType msgrx;
			memcpy((void*)&msgrx, ResponseDataPtr->pData, ResponseDataPtr->datalen);/*���� ���ݵ� FkVciDataType ��*/
			PushMsg(msgrx);
			SetEvent(DataEventHandle);
		}
	}
}
/// <summary>
/// 
/// </summary>
/// <param name="data"></param>
/// <param name="len"></param>
/// <param name="Timeout"></param>
/// <returns></returns>
int AcanProtocol::TrsmitWithResponse(uint8_t* data, int len, uint32_t Timeout)
{
	if (DeviceDrvHandle != NULL)/*�豸��Ϊ��*/
	{
		BaseDevice* dev = (BaseDevice*)DeviceDrvHandle;//��ȡӲ�����
		ProtocolDataType* ResponseDataPtr = (ProtocolDataType*)CommondCheckBuf; //������ת��ΪЭ������
		ResetEvent(CommondEventHandle);//����յ�֮ǰ��event����
		ResponseDataPtr->protocolid = data[0];//Э��ID
		ResponseDataPtr->protocolcmd = data[1];//Э�鹦��
		ResponseDataPtr->protocolchanl = ChanlNum;//Э��ͨ��

		dev->DevTrsmit(data, len);
		/*�ȴ�DEV�������ݲ��ж�*/
		if (WaitForSingleObjectEx(CommondEventHandle, Timeout, true) == WAIT_OBJECT_0)/*�ȴ��豸�ͷ�*/
		{
			//��ȡbuf�е����ݲ��ж����
			if (ResponseDataPtr->pData[0] != 0)
			{
				debugout("TrsmitWithResponse ErrCode:%02X\r\n", ResponseDataPtr->pData[0]);
				return ERRCODE_FAILED;
			}
			ResetEvent(CommondEventHandle);
		}
		else//�ȴ���ʱ
		{
			debugout("TrsmitWithResponse WaitRspMsg TimeOut!\r\n");
			return ERRCODE_TIMEOUT;

		}
	}
	else
	{
		debugout("Device Is Null\r\n");
		return ERRCODE_INVALID_DEVICE_ID;

	}
	debugout("TrsmitWithResponse Sucess!\r\n");
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="channelId"></param>
/// <param name="Flags"></param>
/// <param name="Baudrate"></param>
/// <returns></returns>
int AcanProtocol::ProtocolConnect(void* channelId, uint32_t Flags, uint32_t Baudrate)
{
	debugout("AcanProtocol ProtocolConnect ...\r\n");

	uint8_t buf[256];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;

	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONNECT;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->datalen = 4;
	*(uint32_t*)ProtocolReqDptr->pData = Baudrate;

	int ConnectRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6),100);
	return ConnectRet;
}
/// <summary>
/// 
/// </summary>
/// <returns></returns>
int AcanProtocol::ProtocolDisConnect()
{
	debugout("AcanProtocol ProtocolDisConnect ...\r\n");

	uint8_t buf[256];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;

	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_DISCONNECT;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->datalen = 0;
	int DisConnectRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6),100);
	return DisConnectRet;
}
/// <summary>
/// 
/// </summary>
/// <param name="pMsgs"></param>
/// <param name="pNumMsgs"></param>
/// <param name="Timeout"></param>
/// <returns></returns>
int AcanProtocol::ProtocolReadMsgs(void* pMsgs, uint32_t* pNumMsgs, uint32_t Timeout)
{
	debugout("AcanProtocol ProtocolReadMsgs ...\r\n");
	uint32_t count = (uint32_t)GetRxMessageCount();/*�ӻ����л�ȡ������������*/
	if ((count == 0) && (Timeout == 0))/*������û�������Ҳ��ȴ� ֱ�ӷ���*/
	{
		*pNumMsgs = 0;
		return ERRCODE_BUFFER_EMPTY;
	}
	if (count >= (*pNumMsgs))/*���������㹻�����ݹ��ⲿ��ȡ*/
	{
		FkVciDataType rxmsg;
		FkVciKwpDataType* KwpRxDptr = (FkVciKwpDataType*)pMsgs;
		// we have (more than) enough of buffered messages, read just the amount requested
		debugout("Requeust Read: %d Buffer Num :%d ...\r\n", *pNumMsgs, count);
		for (unsigned long i = 0; i < (*pNumMsgs); i++)
		{
			PopMsg(&rxmsg);//��������� Test ....
			memcpy(KwpRxDptr, &rxmsg, sizeof(FkVciKwpDataType));
			KwpRxDptr++;//ת������һ�����յ�ַ
		}
		return ERRCODE_NOERR;
	}
	else if ((Timeout == 0) && (count > 0))/*������������ ������������������ �����ȴ� ֱ�������������*/
	{
		FkVciDataType rxmsg;
		FkVciKwpDataType* KwpRxDptr = (FkVciKwpDataType*)pMsgs;
		// we have (more than) enough of buffered messages, read just the amount requested
		debugout("Requeust Read: %d Buffer Num :%d ...\r\n", *pNumMsgs, count);
		for (unsigned long i = 0; i < (*pNumMsgs); i++)
		{
			PopMsg(&rxmsg);//��������� Test ....
			memcpy(KwpRxDptr, &rxmsg, sizeof(FkVciKwpDataType));
			KwpRxDptr++;//ת������һ�����յ�ַ
		}
		return ERRCODE_NOERR;
	}
	else/*�������ݲ���  �ȴ�����*/
	{
		debugout("Wait Recieve Msg......\r\n");
		ResetEvent(DataEventHandle);//ʹ������
		if (WaitForSingleObjectEx(DataEventHandle, Timeout, true) == WAIT_OBJECT_0)/*�ȴ��豸�ͷ�*/
		{
			ResetEvent(DataEventHandle);//��������
		}

		count = GetRxMessageCount();
		if (count > 0)/*�ȴ���ʱ*/
		{
			FkVciDataType rxmsg;
			FkVciKwpDataType* KwpRxDptr = (FkVciKwpDataType*)pMsgs;
			// we have (more than) enough of buffered messages, read just the amount requested
			debugout("Requeust Read: %d Buffer Num :%d ...\r\n", *pNumMsgs, count);
			for (unsigned long i = 0; i < (*pNumMsgs); i++)
			{
				PopMsg(&rxmsg);//��������� Test ....
				memcpy(KwpRxDptr, &rxmsg, sizeof(FkVciKwpDataType));
				KwpRxDptr++;//ת������һ�����յ�ַ
			}
			return ERRCODE_NOERR;
		}
		else
			debugout("Time Out And Buffer Empty...\r\n");
		return ERRCODE_BUFFER_EMPTY;
	}
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="pMsg"></param>
/// <param name="pNumMsgs"></param>
/// <param name="Timeout"></param>
/// <returns></returns>
int AcanProtocol::ProtocolWriteMsgs(void* pMsg, uint32_t* pNumMsgs, uint32_t Timeout)
{
	debugout("AcanProtocol ProtocolWriteMsgs ...\r\n");
	if (pMsg == NULL)
		return ERRCODE_INVALID_MSG;

	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	FkVciKwpDataType* KwpTxDptr = (FkVciKwpDataType*)pMsg;
	int DisConnectRet = 0;
	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_TXMSG;
	ProtocolReqDptr->protocolchanl = ChanlNum;

	for (uint32_t i = 0; i < *pNumMsgs; i++)
	{
		ProtocolReqDptr->datalen = (KwpTxDptr->DLC + 12);
		memcpy(ProtocolReqDptr->pData, KwpTxDptr, (KwpTxDptr->DLC + 12));//��Ҫ���͵����ݿ�����ȥ
		DisConnectRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), Timeout);
		if (DisConnectRet != ERRCODE_NOERR)
		{
			*pNumMsgs = i;
			return DisConnectRet;
		}
		else//���ͳɹ� ת������һ������
		{
			KwpTxDptr++;
		}
	}
	return DisConnectRet;
}


/// <summary>
/// 
/// </summary>
/// <param name="pMsg"></param>
/// <param name="pMsgID"></param>
/// <param name="TimeInterval"></param>
/// <returns></returns>
int AcanProtocol::ProtocolStartPeriodicMsg(void* pMsg, void* pMsgID, uint32_t TimeInterval)
{
	debugout("AcanProtocol ProtocolStartPeriodicMsg ...\r\n");
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="pMsgID"></param>
/// <returns></returns>
int AcanProtocol::ProtocolStopPeriodicMsg(void* pMsgID)
{
	debugout("AcanProtocol ProtocolStopPeriodicMsg ...\r\n");
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="FilterType"></param>
/// <param name="pMaskMsg"></param>
/// <param name="pPatternMsg"></param>
/// <param name="pFlowControlMsg"></param>
/// <param name="pFilterID"></param>
/// <returns></returns>
int AcanProtocol::ProtocolStartMsgFilter(unsigned long FilterType, void* pMaskMsg, void* pPatternMsg, void* pFlowControlMsg, unsigned long* pFilterID)
{
	debugout("AcanProtocol ProtocolStartMsgFilter ...\r\n");
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="FilterID"></param>
/// <returns></returns>
int AcanProtocol::ProtocolStopMsgFilter(unsigned long FilterID)
{
	debugout("AcanProtocol ProtocolStopMsgFilter ...\r\n");
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="IoctlID"></param>
/// <param name="pInput"></param>
/// <param name="pOutput"></param>
/// <returns></returns>
int AcanProtocol::ProtocolIOCTL(unsigned long IoctlID, void* pInput, void* pOutput)
{
	debugout("AcanProtocol ProtocolIOCTL IoctlID=%d ...\r\n", IoctlID);

	switch (IoctlID)
	{
	case GET_CONFIG:/*��ȡ���� ͨ��Э�����ý�����������Ϣ����*/
	{
		break;
	}
	case SET_CONFIG:/*�������� ����Э�������*/
	{
		if (pInput == NULL)
		{
			return ERR_NULL_PARAMETER;
		}
		return SetIOCTLParam(pInput);
		break;
	}
	case FAST_INIT:/*���ٳ�ʼ��*/
	{
		if (pInput == NULL)
		{
			return ERR_NULL_PARAMETER;
		}
		return FastInit(pInput,NULL);
	}
	case CAN_ESB:/*ESB PAV ����*/
		if (pInput == NULL)
		{
			return ERR_NULL_PARAMETER;
		}
		return ESB(pInput, NULL);
		break;
	case CLEAR_TX_BUFFER:
		//ClearTXBuffer();
		break;
	case CLEAR_RX_BUFFER:
		ClearRxBuffer();
		break;
	case CLEAR_PERIODIC_MSGS:
		//return StopPeriodicMessages();
		break;
	case CLEAR_MSG_FILTERS:
		//return DeleteFilters();
		break;

	case FS_CHECK:
		if (pInput == NULL)
		{
			return ERR_NULL_PARAMETER;
		}
		return FsCheck(pInput, NULL);
		break;
	case FS_CLEAR:
		if (pInput == NULL)
		{
			return ERR_NULL_PARAMETER;
		}
		return FsClear(pInput, NULL);
		break;
	case FS_WRITE:
		if (pInput == NULL)
		{
			return ERR_NULL_PARAMETER;
		}
		return FsWrite(pInput, NULL);
		break;
	case TSW_CFG:
		if (pInput == NULL)
		{
			return ERR_NULL_PARAMETER;
		}
		return TswCfg(pInput, NULL);
		break; 
	case START_EXPROGSEQUEUE:

		return TswStart(pInput, NULL);
		break;
	default:
		//LOG(MAINFUNC, "CProtocol::IOCTL----- NOT SUPPORTED -----");
		return ERROR_NOT_SUPPORTED;
		break;
	}
	return STATUS_NOERROR;
}
/// <summary>
/// 
/// </summary>
/// <param name="pConf"></param>
/// <returns></returns>
int AcanProtocol::SetIOCTLParam(void* pConf)
{
	VciConfigDataType* pConfig = (VciConfigDataType*)pConf;
	if (pConfig == NULL)
	{
		return ERR_NULL_PARAMETER;
	}
	else
	{
		switch (pConfig->Parameter)
		{
		case DATA_RATE:

			break;
		case P1_MIN:

			break;
		case P1_MAX:

			break;
		case P2_MIN:

			break;
		case P2_MAX:

			break;
		case P3_MIN:

			break;
		case P3_MAX:

			break;
		case P4_MIN:

			break;
		case P4_MAX:

			break;
		case W1:

			break;
		case W2:

			break;
		case W3:

			break;
		case W4:

			break;
		case W5:

			break;
		case TIDLE:

			break;
		case TINIL:

			break;
		case TWUP:

			break;
		default:
			return ERR_INVALID_IOCTL_VALUE;
			break;
		}
	}
	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->rev = SET_CONFIG; //

	ProtocolReqDptr->pData[0] = (uint8_t)(pConfig->Parameter&0xff);
	*(uint32_t*)((ProtocolReqDptr->pData + 1)) = pConfig->Value;
	ProtocolReqDptr->datalen = 5;

	int SetConfigRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 100);
	return SetConfigRet;
}

/// <summary>
/// 
/// </summary>
/// <param name="pInputMsg"></param>
/// <param name="pOutputMsg"></param>
/// <returns></returns>
int AcanProtocol::FastInit(void* pInputMsg, void* pOutputMsg)
{

	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->rev = FAST_INIT; //

	memcpy(ProtocolReqDptr->pData, pInputMsg, 5);//FMT TRGADDR SRADDR CMD CS
	ProtocolReqDptr->datalen = 5;
	int FastInitRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 100);
	return FastInitRet;

}

/// <summary>
/// 
/// </summary>
/// <param name="pInputMsg"></param>
/// <param name="pOutputMsg"></param>
/// <returns></returns>
int AcanProtocol::ESB(void* pInputMsg, void* pOutputMsg)
{

	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->rev = CAN_ESB; //
	//PatternCount  ResponseLength   Timeout->��������ʱ��  �յ�ֹͣ
	memcpy(ProtocolReqDptr->pData, pInputMsg, 12);//FMT TRGADDR SRADDR CMD CS
	ProtocolReqDptr->datalen = 12;
	int FastInitRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 100);//�յ�ָ��������ͺ󷵻�
	return FastInitRet;

}

/// <summary>
/// 
/// </summary>
/// <param name="pInputMsg"></param>
/// <param name="pOutputMsg"></param>
/// <returns></returns>
int AcanProtocol::FsCheck(void* pInputMsg, void* pOutputMsg)
{
	debugout("FsCheck Called...\r\n");
	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->rev = FS_CHECK; //
	//CRC32  FileName
	int strlenval = strlen(((char*)(pInputMsg)+4));//ȥ��CRC ���ַ�����
	memcpy(ProtocolReqDptr->pData, pInputMsg,strlenval + 4);
	ProtocolReqDptr->datalen = strlenval + 4;//��Ч���ݳ���
	int FsCheckRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 2000);//�յ�ָ��������ͺ󷵻�
	return FsCheckRet;
}
/// <summary>
/// 
/// </summary>
/// <param name="pInputMsg"></param>
/// <param name="pOutputMsg"></param>
/// <returns></returns>
int AcanProtocol::FsClear(void* pInputMsg, void* pOutputMsg)
{
	debugout("FsClear Called...\r\n");
	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->rev = FS_CLEAR; //
	//FileName
	int strlenval = strlen(((char*)(pInputMsg)));//ȥ��CRC ���ַ�����
	memcpy(ProtocolReqDptr->pData, pInputMsg, strlenval);
	ProtocolReqDptr->datalen = strlenval;//��Ч���ݳ���
	int FsClearRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 1000);//�յ�ָ��������ͺ󷵻�
	return FsClearRet;
}
/// <summary>
/// 
/// </summary>
/// <param name="pInputMsg"></param>
/// <param name="pOutputMsg"></param>
/// <returns></returns>
int AcanProtocol::FsWrite(void* pInputMsg, void* pOutputMsg)
{
	debugout("FsWrite Called...\r\n");
	uint8_t buf[5120];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;//dont care
	ProtocolReqDptr->rev = FS_WRITE; //

	ifstream inFile;
	char path[255];
	strcpy_s(path, (char*)pInputMsg);//���������� �ļ�·��
	inFile.open((char*)path, ios::in | ios::binary);/*���ļ�*/
	if (inFile)//�ļ��򿪳ɹ�
	{
		uint32_t addroffset = 0;
		while (inFile.peek() != EOF)
		{
			//ǰ4���ֽ�Ϊ ƫ�Ƶ�ַ  ����Ϊ���ݳ���
			*(uint32_t*)ProtocolReqDptr->pData = addroffset;
			long long readnum = inFile.read((char*)(ProtocolReqDptr->pData+4), 4096).gcount();/*�����ȡ4K ����ȡʵ�ʶ�ȡ����ֵ*/
			ProtocolReqDptr->datalen = (uint16_t)(readnum + 4);//
			int FsWriteRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 1000);//�յ�ָ��������ͺ󷵻�
			if(FsWriteRet != STATUS_NOERROR)//���δ���ʧ�� ���ش���
				return FsWriteRet;
			addroffset += (uint32_t)readnum;//����ƫ��
		}
		inFile.close();/*�ر��ļ�*/
	}
	else//�ļ���ʧ��
	{
		return ERR_INVALID_IOCTL_ID;
	}
	return STATUS_NOERROR;//�������
}
/// <summary>
/// 
/// </summary>
/// <param name="pInputMsg"></param>
/// <param name="pOutputMsg"></param>
/// <returns></returns>
int AcanProtocol::TswCfg(void* pInputMsg, void* pOutputMsg)//����Tsw �������
{
	debugout("TswCfg Called...\r\n");
	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->rev = TSW_CFG; //
	//FsTswCfgFormat 
	memcpy(ProtocolReqDptr->pData, pInputMsg, sizeof(FsTswCfgFormat));//FMT TRGADDR SRADDR CMD CS
	ProtocolReqDptr->datalen = sizeof(FsTswCfgFormat);
	int TswCfgRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 100);//�յ�ָ��������ͺ󷵻�
	return TswCfgRet;
}
/// <summary>
/// 
/// </summary>
/// <param name="pInputMsg"></param>
/// <param name="pOutputMsg"></param>
/// <returns></returns>
int AcanProtocol::TswStart(void* pInputMsg, void* pOutputMsg)
{
	debugout("TswStart Called...\r\n");
	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_ASC;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->rev = START_EXPROGSEQUEUE; //
	ProtocolReqDptr->datalen = 0;
	int FastInitRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 60000);//���ȴ�һ����
	return FastInitRet;
}




