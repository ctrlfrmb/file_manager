#pragma once
#include"BaseProtocol.h"
#include"FkSentDataDef.h"

enum
{
	INIT = 0,
	WR_FASTDATA_BUF = 0x10,
	WR_SLOWDATA_BUF = 0x20,
	WR_SPC_TIMEMODE = 0x30,
	WR_SPC_TRIGERMODE = 0x40,
	WR_SPC_MSGTYPE = 0x50,
	WR_SPC_OUTPUT = 0x60,
};

class SentProtocol : public BaseProtocol
{
public:
	SentProtocol(void* drvhandle);
	~SentProtocol();
	void ProtocolDealMsg(void* msg);
	int TrsmitWithResponse(uint8_t* data, int len, uint32_t Timeout);
	int SpcWriteFsDataToBuf(uint8_t Chanl, uint8_t Index, FastDataType* pData);
	int SpcWriteSlDataToBuf(uint8_t Chanl, uint8_t Index, SlowDataType* pData);
	int SpcCfgTimeMode(uint8_t Chanl, uint8_t IdleEnFlang, uint8_t RollingModeFlag, uint16_t CycleCnt);
	int SpcCfgTrigerMode(uint8_t Chanl, uint8_t RollingModeFlag, uint8_t DelayOutPutTick, uint8_t SlotID, uint8_t TotalSlotNum);
	int SpcMsgCfg(uint8_t Chanl, uint8_t SyncTick, uint8_t TickVal);
	int SpcOutPutCfg(uint8_t Chanl, uint8_t TrsmitEnFlag, uint8_t StusValue, uint8_t TotoalFsMsgNum, uint8_t TotoalSlMsgNum);

private:

	uint8_t WorkMode;
};