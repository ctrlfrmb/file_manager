#include"pch.h"
#include "BaseDevice.h"
#include "FkVciDll.h"
#include "VciDebugCf.h"
#include "BaseProtocol.h"
#include "BaseProtocol.h"


DWORD WINAPI DeviceThreadFunction(LPVOID lpParam)
{
	BaseDevice* me = (BaseDevice*)lpParam;

	while (me->DevRecieveRunFlag)
	{
		me->DevRecieve();
	}
	SetEvent(me->hDevRecieveThreadExitResponseHandler);
	return 0;
}


BaseDevice::BaseDevice()
{
	debugout("BaseDevice Create ...\r\n");
	DevRecieveRunFlag = 0;
	/*for (int i = 0; i < MAX_PROTOCOL_NUM; i++)
	{
		ProtocolTab[i] = NULL;
	}*/
	memset(ProtocolTab, NULL, sizeof(ProtocolTab));
	hDevRecieveThreadHandler = NULL;
	hDevRecieveThreadExitResponseHandler = NULL;
	DeviceType = 0;
	LastErrCode = 0;
}

BaseDevice::~BaseDevice()
{
	debugout("BaseDevice Delete ...\r\n");
	//for (int i = 0; i < MAX_PROTOCOL_NUM; i++)
	//{
	//	ProtocolTab[i] = NULL;
	//}
	hDevRecieveThreadHandler = NULL;
	hDevRecieveThreadExitResponseHandler = NULL;
}

int BaseDevice::CreateRecieveThread()
{
	hDevRecieveThreadExitResponseHandler = CreateEventA(
											NULL,		// default security attributes
											TRUE,		// manual-reset event
											FALSE,		// initial state is nonsignaled
											NULL);		// object name
	if (hDevRecieveThreadExitResponseHandler == NULL)
	{
		return ERRCODE_MEMERR;
	}

	DevRecieveRunFlag = 1;//����Ӳ�����ձ�־λ
	hDevRecieveThreadHandler = CreateThread(
											NULL,                   // default security attributes
											0,                      // use default stack size  
											DeviceThreadFunction,       // thread function name
											(void*)this, /*pDataArray[i],*/          // argument to thread function 
											0,                      // use default creation flags 
											NULL); //&dwThreadIdArray[i]);   // returns the thread identifier 
	if (hDevRecieveThreadHandler == NULL)
	{
		DevRecieveRunFlag = 0;
		return ERRCODE_MEMERR;
	}
	return ERRCODE_NOERR;
}

int BaseDevice::DevOpen(void* pName)
{
	debugout("BaseDevice DevOpen ...\r\n");
	//Add Some Hard Ware Api Here

	return CreateRecieveThread();
}

int BaseDevice::DevClose()
{
	debugout("BaseDevice DevClose ...\r\n");
	ClearProtocol();

	DevRecieveRunFlag = 0;
	WaitForSingleObjectEx(hDevRecieveThreadExitResponseHandler, INFINITE, true);/*�ȴ��豸�ͷ�*/
	return ERRCODE_NOERR;
}

int BaseDevice::DevTrsmit(const uint8_t* data, int len)
{
	debugout("BaseDevice DevTrsmit ...\r\n");
	return ERRCODE_NOERR;
}

int BaseDevice::DevRecieve()
{
	debugout("BaseDevice DevRecieve ...\r\n");
	Sleep(100);
	return ERRCODE_NOERR;
}
/*
* ��һ��Э��ͨ�������ɹ������
* 
* 
*/
int BaseDevice::InsetProtocol(void* protocol_handle)
{
	debugout("BaseDevice InsetProtocol ...\r\n");
	if (protocol_handle == NULL)
	{
		debugout("BaseDevice InsetProtocol -> Input==NULL...\r\n");
		return ERRCODE_PROTOCOLIDERR;
	}

	for (int i = 0; i < MAX_PROTOCOL_NUM; i++)
	{
		if (ProtocolTab[i] != NULL)
		{
			if (ProtocolTab[i] == protocol_handle)
			{
				debugout("BaseDevice InsetProtocol -> Protocol Have In\r\n");
				return ERRCODE_PROTOCOLOPENED;
			}
			if (((BaseProtocol*)ProtocolTab[i])->ProtocolID == ((BaseProtocol*)protocol_handle)->ProtocolID
				&& ((BaseProtocol*)ProtocolTab[i])->ChanlNum == ((BaseProtocol*)protocol_handle)->ChanlNum
				)
			{
				debugout("BaseDevice InsetProtocol -> Protocol Have OPENED\r\n");
				return ERRCODE_PROTOCOLOPENED;
			}

		}

	}

	for (int i = 0; i < MAX_PROTOCOL_NUM; i++)
	{
		if (ProtocolTab[i] == NULL)
		{
			ProtocolTab[i] = protocol_handle;
			return ERRCODE_NOERR;
		}
	}
	return ERRCODE_NOERR;
}
/*
* ɾ��һ��Э��ͨ�� ���Ͽ����Ӻ����
* 
* 
* 
* 
*/
int BaseDevice::DeleteProtocol(void* protocol_handle)
{
	debugout("BaseDevice DeleteProtocol ...\r\n");
	for (int i = 0; i < MAX_PROTOCOL_NUM; i++)
	{
		if (ProtocolTab[i] == protocol_handle)
		{
			//BaseProtocol* Protocol = (BaseProtocol*)protocol_handle;
			//delete Protocol;
			ProtocolTab[i] = NULL;
			return ERRCODE_NOERR;
		}
	}
	return ERRCODE_NOERR;
}


/*
*  �ر�����Э��  �ڹر�DEVʱ�����
* 
* 
* 
*/
int BaseDevice::ClearProtocol()
{
	debugout("BaseDevice ClearProtocol ...\r\n");
	for (int i = 0; i < MAX_PROTOCOL_NUM; i++)
	{
		if (ProtocolTab[i] != NULL)
		{
			BaseProtocol* Protocol = (BaseProtocol*)ProtocolTab[i];
			Protocol->ProtocolDisConnect();//�ȵ��ùر� ���ܽ�����
			ProtocolTab[i] = NULL;
		}
	}
	return ERRCODE_NOERR;
}


HANDLE BaseDevice::GetProtocolHandle(uint8_t ProtocolId, uint8_t Chanl)
{
	for (int i = 0; i < MAX_PROTOCOL_NUM; i++)
	{
		if (ProtocolTab[i] != NULL)
		{
			BaseProtocol* Protocol = (BaseProtocol*)ProtocolTab[i];
			if (Protocol->ProtocolID == ProtocolId && Protocol->ChanlNum == Chanl)
			{
				return ProtocolTab[i];
			}
		}
	}
	return NULL;
}


