
#include"pch.h"
#include"FkVciDll.h"
#include"VciDebugCf.h"
#include"BaseDevice.h"
#include"BaseProtocol.h"
#include"LanDevice.h"
#include"ComDevice.h"
#include"DkSent.h"
#include"SpeedSimProtocol.h"
#include "j2534_v0404.h"
#define MAX_DEV_NUM 16
SHANDLE DevList[MAX_DEV_NUM];/*���԰����ﻻ��vector*/
/// <summary>
/// 
/// </summary>
/// <param name="device_type"></0:LAN 1:USB 2:COM> 
/// <param name="device_index"></param>
/// <param name="reserved"></param>
/// <returns></returns>
SHANDLE FkDkSentOpenDev(UINT32_T device_type, UINT32_T device_index, UINT32_T reserved)
{
	BaseDevice* dev = NULL;
	char devipaddr[32];
	//ͨ�� pName ����򿪵�dev ����
	if (device_type == eCOM)
		dev = new ComDevice();/*�½�һ��sn*/
	sprintf_s(devipaddr, 32, "COM%d", device_index);

	if (dev->DevOpen((void*)(devipaddr)) == ERRCODE_NOERR)/*�򿪳ɹ�*/
	{
		for (int i = 0; i < MAX_DEV_NUM; i++)//���½���DEV �����������
		{
			if (DevList[i] == NULL)
			{
				DevList[i] = dev;
				/*����һ��Э��*/
				DkSent* Protocol = new DkSent(dev);//�½�һ����Ӧͨ��
				if (dev->InsetProtocol((void*)Protocol) != ERRCODE_NOERR)//�����Ȳ���  ӦΪ������ dev->deal
				{
					delete Protocol;
					dev->DevClose();//�����ɹ��� ���Ǵ��������� �ȹر� ��ɾ��
					delete (ComDevice*)dev;
					return NULL;
				}

				return DevList[i];
			}
		}
		dev->DevClose();//�����ɹ��� ���Ǵ��������� �ȹر� ��ɾ��
		delete (ComDevice*)dev;
		return NULL;
	}
	else
	{
		delete (ComDevice*)dev;;//δ�����ɹ�  ɾ��
	}
	return NULL;

}
/// <summary>
/// 
/// </summary>
/// <param name="device_handle"></ͨ��OpenDev �򿪵ľ��>
/// <returns></returns>
int FkDkSentCloseDev(SHANDLE device_handle)
{
	if (device_handle == NULL)
		return ERRCODE_INVALID_DEVICE_ID;
	for (int i = 0; i < MAX_DEV_NUM; i++)
	{
		if (device_handle == DevList[i])/**/
		{
			BaseDevice* dev = (BaseDevice*)device_handle;
			dev->DevClose();
			if (dev->DeviceType = eLAN)//�ж���ǰʹ�õ��Ǻ���Ӳ��
			{
				delete (LanDevice*)dev;/*ɾ��֮ǰnew�� class*/
			}
			else if (dev->DeviceType = eCOM)
			{
				delete (ComDevice*)dev;/*ɾ��֮ǰnew�� class*/
			}
			DevList[i] = NULL;
			return ERRCODE_NOERR;/*�رճɹ�*/
		}
	}
	return ERRCODE_INVALID_DEVICE_ID;/*DevID ����*/
}

void FkDllDetachCallBack()
{
	for (int i = 0; i < MAX_DEV_NUM; i++)
	{
		if (DevList[i] != NULL)
		{
			BaseDevice* dev = (BaseDevice*)DevList[i];
			dev->DevClose();
			if (dev->DeviceType = eLAN)//�ж���ǰʹ�õ��Ǻ���Ӳ��
			{
				delete (LanDevice*)dev;/*ɾ��֮ǰnew�� class*/
			}
			else if (dev->DeviceType = eCOM)
			{
				delete (ComDevice*)dev;/*ɾ��֮ǰnew�� class*/
			}
			DevList[i] = NULL;
		}
	}
}

int FkDkSentInit(SHANDLE device_handle, uint8_t chanl, uint8_t CoverMode, uint8_t DataFomat, uint8_t Val)
{
	if (device_handle == NULL)
		return ERRCODE_INVALID_DEVICE_ID;
	for (int i = 0; i < MAX_DEV_NUM; i++)
	{
		if (device_handle == DevList[i])/**/
		{
			BaseDevice* dev = (BaseDevice*)device_handle;
			DkSent* Protocol = (DkSent*)dev->ProtocolTab[0];
			if (Protocol->DkSentInit(chanl,CoverMode,DataFomat,Val) == ERRCODE_NOERR)//����ͨ���ɹ�
			{
				return ERRCODE_NOERR;
			}
			return ERRCODE_FAILED;
		}
	}
	return ERRCODE_INVALID_DEVICE_ID;/*DevID ����*/
}

int FkDkSentWriteChanl(SHANDLE device_handle, uint8_t chanl, DkMsgDataType* pData)
{
	if (device_handle == NULL)
		return ERRCODE_INVALID_DEVICE_ID;
	for (int i = 0; i < MAX_DEV_NUM; i++)
	{
		if (device_handle == DevList[i])/**/
		{
			BaseDevice* dev = (BaseDevice*)device_handle;
			DkSent* Protocol = (DkSent*)dev->ProtocolTab[0];
			if (Protocol->DkSentWriteChanl(chanl,pData) == ERRCODE_NOERR)//����ͨ���ɹ�
			{
				return ERRCODE_NOERR;
			}
			return ERRCODE_FAILED;
		}
	}
	return ERRCODE_INVALID_DEVICE_ID;/*DevID ����*/
}

int FkDkSentWriteChanlAll(SHANDLE device_handle,DkMsgDataType* pDataCh1, DkMsgDataType* pDataCh2)
{
	if (device_handle == NULL)
		return ERRCODE_INVALID_DEVICE_ID;
	for (int i = 0; i < MAX_DEV_NUM; i++)
	{
		if (device_handle == DevList[i])/**/
		{
			BaseDevice* dev = (BaseDevice*)device_handle;
			DkSent* Protocol = (DkSent*)dev->ProtocolTab[0];
			if (Protocol->DkSentWriteChanlAll(pDataCh1, pDataCh2) == ERRCODE_NOERR)//����ͨ���ɹ�
			{
				return ERRCODE_NOERR;
			}
			return ERRCODE_FAILED;
		}
	}
	return ERRCODE_INVALID_DEVICE_ID;/*DevID ����*/
}

int FkDkSentDeInit(SHANDLE device_handle, uint8_t chanl)
{
	if (device_handle == NULL)
		return ERRCODE_INVALID_DEVICE_ID;
	for (int i = 0; i < MAX_DEV_NUM; i++)
	{
		if (device_handle == DevList[i])/**/
		{
			BaseDevice* dev = (BaseDevice*)device_handle;
			DkSent* Protocol = (DkSent*)dev->ProtocolTab[0];
			if (Protocol->DkSentDeInit(chanl) == ERRCODE_NOERR)//����ͨ���ɹ�
			{
				return ERRCODE_NOERR;
			}
			return ERRCODE_FAILED;
		}
	}
	return ERRCODE_INVALID_DEVICE_ID;/*DevID ����*/
}

int FkDkSentRead(SHANDLE device_handle, DkMsgRdDataType* pReadBackChanl1, DkMsgRdDataType* pReadBackChanl2)
{
	if (device_handle == NULL)
		return ERRCODE_INVALID_DEVICE_ID;
	for (int i = 0; i < MAX_DEV_NUM; i++)
	{
		if (device_handle == DevList[i])/**/
		{
			BaseDevice* dev = (BaseDevice*)device_handle;
			DkSent* Protocol = (DkSent*)dev->ProtocolTab[0];
			if (Protocol->DkSentReadData(pReadBackChanl1, pReadBackChanl2) == ERRCODE_NOERR)//����ͨ���ɹ�
			{
				return ERRCODE_NOERR;
			}
			return ERRCODE_FAILED;
		}
	}
	return ERRCODE_INVALID_DEVICE_ID;/*DevID ����*/
}