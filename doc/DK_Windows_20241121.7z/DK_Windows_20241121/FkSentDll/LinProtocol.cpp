#include"pch.h"
#include <fstream>
#include"LinProtocol.h"
#include"BaseDevice.h"
#include"VciDebugCf.h"
#include"j2534_v0404.h"
LinProtocol::LinProtocol(void* drvhandle, uint8_t Chanl)
{
	debugout("LinProtocol Create ...\r\n");
	DeviceDrvHandle = drvhandle;
	ChanlNum = Chanl;
	LinSchRunFlag = 0;
	ProtocolID = ePROTOCOL_LIN;
	DataEventHandle = CreateEventA(
		NULL,		// default security attributes
		TRUE,		// manual-reset event
		FALSE,		// initial state is nonsignaled
		NULL);		// object name
	CommondEventHandle = CreateEventA(
		NULL,		// default security attributes
		TRUE,		// manual-reset event
		FALSE,		// initial state is nonsignaled
		NULL);		// object name
}

LinProtocol::~LinProtocol()
{
	debugout("LinProtocol Delete ...\r\n");

}
/// <summary>
/// 
/// </summary>
/// <param name="msg"></param>
void LinProtocol::ProtocolDealMsg(void* msg)
{
	debugout("LinProtocol ProtocolDealMsg ...\r\n");

	ProtocolDataType* ResponseDataPtr = (ProtocolDataType*)msg;//�����յ�������ת��ΪЭ������
	/*��֤�Ƿ�Ϊָ��ر���*/
	if (CommondCheckBuf[0] == ResponseDataPtr->protocolid //��ǰ�����Э��
		&& CommondCheckBuf[1] == ResponseDataPtr->protocolcmd //��ǰ�����Command
		&& CommondCheckBuf[2] == ResponseDataPtr->protocolchanl)//��ǰ����� ͨ��
	{
		debugout("Recieve CommondCheck Msg...\r\n");
		memcpy(CommondCheckBuf, msg, (ResponseDataPtr->datalen + 6));
		SetEvent(CommondEventHandle);
	}
	else//Э������
	{
		debugout("DEV�������͵���Ϣ...\r\n");
		/*�����ݴ����PassThruMsg ����ŵ�������*/
		if (ePROTOCOL_LIN == ResponseDataPtr->protocolid
			&& CMDCODE_RXMSG == ResponseDataPtr->protocolcmd
			&& ChanlNum == ResponseDataPtr->protocolchanl)/*PROTOCOL_ACAN ����*/
		{
			debugout("Recevie One Can Msg...\r\n");

			//����Ҫ���� ������  ��ǰ������KWPģʽ�� ���� RAWģʽ��  ��λ��һֱ������RAW ģʽ��

			FkVciDataType msgrx;
			memcpy((void*)&msgrx, ResponseDataPtr->pData, ResponseDataPtr->datalen);/*���� ���ݵ� FkVciDataType ��*/
			PushMsg(msgrx);
			SetEvent(DataEventHandle);
		}
	}
}
/// <summary>
/// 
/// </summary>
/// <param name="data"></param>
/// <param name="len"></param>
/// <param name="Timeout"></param>
/// <returns></returns>
int LinProtocol::TrsmitWithResponse(uint8_t* data, int len, uint32_t Timeout)
{
	if (DeviceDrvHandle != NULL)/*�豸��Ϊ��*/
	{
		BaseDevice* dev = (BaseDevice*)DeviceDrvHandle;//��ȡӲ�����
		ProtocolDataType* ResponseDataPtr = (ProtocolDataType*)CommondCheckBuf; //������ת��ΪЭ������
		ResetEvent(CommondEventHandle);//����յ�֮ǰ��event����
		ResponseDataPtr->protocolid = data[0];//Э��ID
		ResponseDataPtr->protocolcmd = data[1];//Э�鹦��
		ResponseDataPtr->protocolchanl = ChanlNum;//Э��ͨ��

		dev->DevTrsmit(data, len);
		/*�ȴ�DEV�������ݲ��ж�*/
		if (WaitForSingleObjectEx(CommondEventHandle, Timeout, true) == WAIT_OBJECT_0)/*�ȴ��豸�ͷ�*/
		{
			//��ȡbuf�е����ݲ��ж����
			if (ResponseDataPtr->pData[0] != 0)
			{
				debugout("TrsmitWithResponse ErrCode:%02X\r\n", ResponseDataPtr->pData[0]);
				return ERRCODE_FAILED;
			}
			ResetEvent(CommondEventHandle);
		}
		else//�ȴ���ʱ
		{
			debugout("TrsmitWithResponse WaitRspMsg TimeOut!\r\n");
			return ERRCODE_TIMEOUT;

		}
	}
	else
	{
		debugout("Device Is Null\r\n");
		return ERRCODE_INVALID_DEVICE_ID;

	}
	debugout("TrsmitWithResponse Sucess!\r\n");
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="channelId"></param>
/// <param name="Flags"></param>
/// <param name="Baudrate"></param>
/// <returns></returns>
int LinProtocol::ProtocolConnect(void* channelId, uint32_t Flags, uint32_t Baudrate)
{
	debugout("LinProtocol ProtocolConnect ...\r\n");

	uint8_t buf[256];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;

	ProtocolReqDptr->protocolid = ePROTOCOL_LIN;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONNECT;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->datalen = 5;
	ProtocolReqDptr->pData[0] = (uint8_t)Flags;
	*(uint32_t*)(ProtocolReqDptr->pData+1) = Baudrate;

	int ConnectRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 500);
	return ConnectRet;
}
/// <summary>
/// 
/// </summary>
/// <returns></returns>
int LinProtocol::ProtocolDisConnect()
{
	debugout("LinProtocol ProtocolDisConnect ...\r\n");

	uint8_t buf[256];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;

	ProtocolReqDptr->protocolid = ePROTOCOL_LIN;
	ProtocolReqDptr->protocolcmd = CMDCODE_DISCONNECT;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->datalen = 0;
	int DisConnectRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 100);
	return DisConnectRet;
}
/// <summary>
/// LIN �Ƚ�����  ����ģʽ�� ����ȴ���ȫ����
/// </summary>
/// <param name="pMsgs"></param>
/// <param name="pNumMsgs"></param>
/// <param name="Timeout"></param>
/// <returns></returns>
int LinProtocol::ProtocolReadMsgs(void* pMsgs, uint32_t* pNumMsgs, uint32_t Timeout)
{
	debugout("LinProtocol ProtocolReadMsgs ...\r\n");
	uint32_t count = (uint32_t)GetRxMessageCount();/*�ӻ����л�ȡ������������*/
	if ((count == 0) && (Timeout == 0))/*������û�������Ҳ��ȴ� ֱ�ӷ���*/
	{
		*pNumMsgs = 0;
		return ERRCODE_BUFFER_EMPTY;
	}
	if (count >= (*pNumMsgs))/*���������㹻�����ݹ��ⲿ��ȡ*/
	{
		FkVciDataType rxmsg;
		FkVciLinDataType* LinRxDptr = (FkVciLinDataType*)pMsgs;
		// we have (more than) enough of buffered messages, read just the amount requested
		debugout("Requeust Read: %d Buffer Num :%d ...\r\n", *pNumMsgs, count);
		for (unsigned long i = 0; i < (*pNumMsgs); i++)
		{
			PopMsg(&rxmsg);//��������� Test ....
			memcpy(LinRxDptr, &rxmsg, sizeof(FkVciLinDataType));
			LinRxDptr++;//ת������һ�����յ�ַ
		}
		return ERRCODE_NOERR;
	}
	else if ((Timeout == 0) && (count > 0))/*������������ ������������������ �����ȴ� ֱ�������������*/
	{
		FkVciDataType rxmsg;
		FkVciLinDataType* LinRxDptr = (FkVciLinDataType*)pMsgs;
		// we have (more than) enough of buffered messages, read just the amount requested
		debugout("Requeust Read: %d Buffer Num :%d ...\r\n", *pNumMsgs, count);
		for (unsigned long i = 0; i < (*pNumMsgs); i++)
		{
			PopMsg(&rxmsg);//��������� Test ....
			memcpy(LinRxDptr, &rxmsg, sizeof(FkVciLinDataType));
			LinRxDptr++;//ת������һ�����յ�ַ
		}
		return ERRCODE_NOERR;
	}
	else/*�������ݲ���  �ȴ�����*/
	{
		debugout("Wait Recieve Msg......\r\n");
		while(1)
		{ 
			ResetEvent(DataEventHandle);//ʹ������
			if (WaitForSingleObjectEx(DataEventHandle, Timeout, true) == WAIT_OBJECT_0)/*�ȴ��豸�ͷ�*/
			{
				ResetEvent(DataEventHandle);//��������
			}
			else//�ȴ���ʱ
			{
				break;
			}
			count = GetRxMessageCount();
			if (count >= *pNumMsgs)//���յ��㹻������  ��������
			{
				break;
			}
		}
		if (count > 0)/*�ȴ���ʱ*/
		{
			FkVciDataType rxmsg;
			FkVciLinDataType* LinRxDptr = (FkVciLinDataType*)pMsgs;
			// we have (more than) enough of buffered messages, read just the amount requested
			debugout("Requeust Read: %d Buffer Num :%d ...\r\n", *pNumMsgs, count);
			for (unsigned long i = 0; i < (*pNumMsgs); i++)
			{
				PopMsg(&rxmsg);//��������� Test ....
				memcpy(LinRxDptr, &rxmsg, sizeof(FkVciLinDataType));
				LinRxDptr++;//ת������һ�����յ�ַ
			}
			return ERRCODE_NOERR;
		}
		else
		{
			debugout("Time Out And Buffer Empty...\r\n");
		}			
		return ERRCODE_BUFFER_EMPTY;
	}
	return ERRCODE_NOERR;
}
/// <summary>
/// LIN �Ƚ�����  ʹ�ø÷��������е����ݷ�����ȥȻ��ʼһ�η��͵��� 
/// ��ʼ���Ⱥ��������ؽ��  ʵ�ʷ��ͽ��ͨ��ReadMsg ��ȡ
/// </summary>
/// <param name="pMsg"></param>
/// <param name="pNumMsgs"></param>
/// <param name="Timeout"></param>
/// <returns></returns>
int LinProtocol::ProtocolWriteMsgs(void* pMsg, uint32_t* pNumMsgs, uint32_t Timeout)
{
	debugout("LinProtocol ProtocolWriteMsgs ...\r\n");
	if (pMsg == NULL)
		return ERRCODE_INVALID_MSG;

	uint8_t buf[5120];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	FkVciLinDataType* LinTxDptr = (FkVciLinDataType*)pMsg;
	
	int WriteMsgRet = 0;
	ProtocolReqDptr->protocolid = ePROTOCOL_LIN;
	ProtocolReqDptr->protocolcmd = CMDCODE_TXMSG;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->datalen = 0;
	FkVciLinDataType* LinDstDptr = (FkVciLinDataType*)ProtocolReqDptr->pData;
	for (uint32_t i = 0; i < *pNumMsgs; i++)//������copy�����ͻ�����
	{
		//((sizeof(FkVciLinDataType))* i)
		memcpy(LinDstDptr, LinTxDptr,sizeof(FkVciLinDataType));
		LinTxDptr++;
		LinDstDptr++;
		ProtocolReqDptr->datalen += sizeof(FkVciLinDataType);
	}
	WriteMsgRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), Timeout);

	return WriteMsgRet;
}


/// <summary>
/// 
/// </summary>
/// <param name="pMsg"></param>
/// <param name="pMsgID"></param>
/// <param name="TimeInterval"></param>
/// <returns></returns>
int LinProtocol::ProtocolStartPeriodicMsg(void* pMsg, void* pMsgID, uint32_t TimeInterval)
{
	debugout("LinProtocol ProtocolStartPeriodicMsg ...\r\n");
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="pMsgID"></param>
/// <returns></returns>
int LinProtocol::ProtocolStopPeriodicMsg(void* pMsgID)
{
	debugout("LinProtocol ProtocolStopPeriodicMsg ...\r\n");
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="FilterType"></param>
/// <param name="pMaskMsg"></param>
/// <param name="pPatternMsg"></param>
/// <param name="pFlowControlMsg"></param>
/// <param name="pFilterID"></param>
/// <returns></returns>
int LinProtocol::ProtocolStartMsgFilter(unsigned long FilterType, void* pMaskMsg, void* pPatternMsg, void* pFlowControlMsg, unsigned long* pFilterID)
{
	debugout("LinProtocol ProtocolStartMsgFilter ...\r\n");
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="FilterID"></param>
/// <returns></returns>
int LinProtocol::ProtocolStopMsgFilter(unsigned long FilterID)
{
	debugout("LinProtocol ProtocolStopMsgFilter ...\r\n");
	return ERRCODE_NOERR;
}
/// <summary>
/// 
/// </summary>
/// <param name="IoctlID"></param>
/// <param name="pInput"></param>
/// <param name="pOutput"></param>
/// <returns></returns>
int LinProtocol::ProtocolIOCTL(unsigned long IoctlID, void* pInput, void* pOutput)
{
	debugout("LinProtocol ProtocolIOCTL IoctlID=%d ...\r\n", IoctlID);

	switch (IoctlID)
	{
	case GET_CONFIG:/*��ȡ���� ͨ��Э�����ý�����������Ϣ����*/
	{
		break;
	}
	case SET_CONFIG:/*�������� ����Э�������*/
	{
		if (pInput == NULL)
		{
			return ERR_NULL_PARAMETER;
		}
		return SetIOCTLParam(pInput);
		break;
	}
	case CLEAR_TX_BUFFER:
		//ClearTXBuffer();
		break;
	case CLEAR_RX_BUFFER:
		ClearRxBuffer();
		break;
	case CLEAR_PERIODIC_MSGS:
		//return StopPeriodicMessages();
		break;
	case CLEAR_MSG_FILTERS:
		//return DeleteFilters();
		break;
	case FS_CLEAR://ֹͣSCH ����ӻ���Ϣ
		return SchStop();
		break;
	case FS_WRITE://���ӻ����޸�һ��SCH ��Ϣ
		if (pInput == NULL)
		{
			return ERR_NULL_PARAMETER;
		}
			return SchWriteMsg(pInput);
		break;
	case START_EXPROGSEQUEUE://��ʼSCH ����
		return SchStart();
		break;
	default:
		//LOG(MAINFUNC, "CProtocol::IOCTL----- NOT SUPPORTED -----");
		return ERROR_NOT_SUPPORTED;
		break;
	}
	return STATUS_NOERROR;
}
/// <summary>
/// 
/// </summary>
/// <param name="pConf"></param>
/// <returns></returns>
int LinProtocol::SetIOCTLParam(void* pConf)
{
	VciConfigDataType* pConfig = (VciConfigDataType*)pConf;
	if (pConfig == NULL)
	{
		return ERR_NULL_PARAMETER;
	}
	else
	{
		switch (pConfig->Parameter)
		{
		case DATA_RATE:

			break;
			//case P1_MIN: //

			//	break;

		default:
			return ERR_INVALID_IOCTL_VALUE;
			break;
		}
	}
	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_LIN;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->rev = SET_CONFIG; //

	ProtocolReqDptr->pData[0] = (uint8_t)(pConfig->Parameter & 0xff);
	*(uint32_t*)((ProtocolReqDptr->pData + 1)) = pConfig->Value;
	ProtocolReqDptr->datalen = 5;

	int SetConfigRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 100);
	return SetConfigRet;
}



int LinProtocol::SchWriteMsg(void* pMsg)
{
	debugout("FsWrite Called...\r\n");
	uint8_t buf[5120];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_LIN;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;//dont care
	ProtocolReqDptr->rev = FS_WRITE; //
	memcpy(ProtocolReqDptr->pData, pMsg,sizeof(FkVciLinDataType));
	ProtocolReqDptr->datalen = sizeof(FkVciLinDataType);
	int SchWriteRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 100);//���ȴ�һ����
	return SchWriteRet;

	return STATUS_NOERROR;//�������
}

int LinProtocol::SchStart()
{
	debugout("SchStart Called...\r\n");
	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_LIN;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->rev = START_EXPROGSEQUEUE; //
	ProtocolReqDptr->datalen = 0;
	int FastInitRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 100);//���ȴ�һ����
	return FastInitRet;
}

int LinProtocol::SchStop()
{
	debugout("SchStop Called...\r\n");
	uint8_t buf[512];
	ProtocolDataType* ProtocolReqDptr = (ProtocolDataType*)buf;
	ProtocolReqDptr->protocolid = ePROTOCOL_LIN;
	ProtocolReqDptr->protocolcmd = CMDCODE_CONF;
	ProtocolReqDptr->protocolchanl = ChanlNum;
	ProtocolReqDptr->rev = FS_CLEAR; //
	ProtocolReqDptr->datalen = 0;//��Ч���ݳ���
	int FsClearRet = TrsmitWithResponse(buf, (ProtocolReqDptr->datalen + 6), 100);//�յ�ָ��������ͺ󷵻�
	return FsClearRet;
}






