﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Management;
using System.IO.Ports;
using System.Runtime.InteropServices;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {

		//[DllImport("FkSpeedDll.dll")]
		//public HANDLE FkSpeedOpenDev(UINT32_T device_type, UINT32_T device_index, UINT32_T reserved);

		public Form1()
        {
            InitializeComponent();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
		/*通道1 模式选择*/
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
			int selectedIndex = comboBox1.SelectedIndex;
			Chanl1Part1Text.Text = "0";
			Chanl1Part2Text.Text = "0";
			if (selectedIndex == 0)
			{
				Chanl1Part1.Text = "参数1";
				Chanl1Part2.Text = "参数2";

			}
			else if (selectedIndex == 1)
			{
				Chanl1Part1.Text = "正常齿数";
				Chanl1Part2.Text = "缺齿数";
			}
			else if (selectedIndex == 2)
			{
				Chanl1Part1.Text = "AK长度Bit";
				Chanl1Part2.Text = "AK值";
			}
			else if (selectedIndex == 3)
			{
				Chanl1Part1.Text = "频率";
				Chanl1Part2.Text = "AK值";
			}

		}

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
			int selectedIndex = comboBox3.SelectedIndex;
			if (selectedIndex == 0)
			{
				Chanl2Part1.Text = "参数1";
				Chanl2Part2.Text = "参数2";

				Chanl2Part1Text.Text = "0";
				Chanl2Part2Text.Text = "0";

			}
			else if (selectedIndex == 1)
			{
				Chanl2Part1.Text = "正常齿数";
				Chanl2Part2.Text = "缺齿数";

				Chanl2Part1Text.Text = "0";
				Chanl2Part2Text.Text = "0";
			}
			else if (selectedIndex == 2)
			{
				Chanl2Part1.Text = "AK长度Bit";
				Chanl2Part2.Text = "AK值";

				Chanl2Part1Text.Text = "0";
				Chanl2Part2Text.Text = "0";
			}
			else if (selectedIndex == 3)
			{
				Chanl2Part1.Text = "频率";
				Chanl2Part2.Text = "AK值";

				Chanl2Part1Text.Text = "0";
				Chanl2Part2Text.Text = "0";
			}
		}

        private void comboBox2_MouseClick(object sender, MouseEventArgs e)
        {
			comboBox2.Items.Clear();
			try
			{
				using (ManagementObjectSearcher searcher = new ManagementObjectSearcher("select * from Win32_PnPEntity"))
				{
					var hardInfos = searcher.Get();
					foreach (var hardInfo in hardInfos)
					{
						object com = hardInfo.Properties["Name"].Value;

						if (com != null && com.ToString().Contains("(COM"))
						{
							string strComName = com.ToString();
							string[] sArray = strComName.Split(new string[] { "(" }, 2, StringSplitOptions.RemoveEmptyEntries);
							String subString = sArray[1].Substring(0, sArray[1].Length - 1);

							//int index = strComName.IndexOf("COM", 0);
							//if (index != -1)
							//	strComName = subString + " " + strComName.Substring(0, index - 1);
							//else
							//	strComName = subString + " " + strComName;
							strComName = subString;
							comboBox2.Items.Add(strComName);
							comboBox2.Text = strComName;
						}
					}
					if (comboBox1.Items.Count == 0)
						MessageBox.Show("未扫描到COM口，请检查USB连接");
				}
			}
			catch
			{
				MessageBox.Show("异常:扫描失败");
			}
		}

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
