﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.Chanl1Part1Text = new System.Windows.Forms.TextBox();
            this.Chanl1Part2Text = new System.Windows.Forms.TextBox();
            this.Chanl1Part1 = new System.Windows.Forms.Label();
            this.Chanl1Part2 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.Chanl2Part2 = new System.Windows.Forms.Label();
            this.Chanl2Part1 = new System.Windows.Forms.Label();
            this.Chanl2Part2Text = new System.Windows.Forms.TextBox();
            this.Chanl2Part1Text = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "正常模式",
            "缺齿模式",
            "更改AK值",
            "自定义发送"});
            this.comboBox1.Location = new System.Drawing.Point(79, 94);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 20);
            this.comboBox1.TabIndex = 0;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 97);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 1;
            this.label1.Text = "控制模式";
            // 
            // Chanl1Part1Text
            // 
            this.Chanl1Part1Text.Location = new System.Drawing.Point(79, 158);
            this.Chanl1Part1Text.Name = "Chanl1Part1Text";
            this.Chanl1Part1Text.Size = new System.Drawing.Size(121, 21);
            this.Chanl1Part1Text.TabIndex = 2;
            this.Chanl1Part1Text.Text = "0";
            // 
            // Chanl1Part2Text
            // 
            this.Chanl1Part2Text.Location = new System.Drawing.Point(79, 227);
            this.Chanl1Part2Text.Name = "Chanl1Part2Text";
            this.Chanl1Part2Text.Size = new System.Drawing.Size(121, 21);
            this.Chanl1Part2Text.TabIndex = 3;
            this.Chanl1Part2Text.Text = "0";
            // 
            // Chanl1Part1
            // 
            this.Chanl1Part1.AutoSize = true;
            this.Chanl1Part1.Location = new System.Drawing.Point(20, 161);
            this.Chanl1Part1.Name = "Chanl1Part1";
            this.Chanl1Part1.Size = new System.Drawing.Size(35, 12);
            this.Chanl1Part1.TabIndex = 4;
            this.Chanl1Part1.Text = "参数1";
            // 
            // Chanl1Part2
            // 
            this.Chanl1Part2.AutoSize = true;
            this.Chanl1Part2.Location = new System.Drawing.Point(20, 230);
            this.Chanl1Part2.Name = "Chanl1Part2";
            this.Chanl1Part2.Size = new System.Drawing.Size(35, 12);
            this.Chanl1Part2.TabIndex = 5;
            this.Chanl1Part2.Text = "参数2";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2,
            this.Column3});
            this.dataGridView1.Location = new System.Drawing.Point(416, 94);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(346, 154);
            this.dataGridView1.TabIndex = 7;
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Column1";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Column2";
            this.Column2.Name = "Column2";
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Column3";
            this.Column3.Name = "Column3";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(416, 55);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(72, 16);
            this.checkBox1.TabIndex = 8;
            this.checkBox1.Text = "周期读取";
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(270, 270);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(121, 34);
            this.button1.TabIndex = 9;
            this.button1.Text = "配置";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(22, 353);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(766, 85);
            this.textBox3.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(24, 338);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(23, 12);
            this.label4.TabIndex = 11;
            this.label4.Text = "Log";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(79, 16);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(185, 20);
            this.comboBox2.TabIndex = 12;
            this.comboBox2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.comboBox2_MouseClick);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(294, 12);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(97, 32);
            this.button2.TabIndex = 13;
            this.button2.Text = "打开";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(24, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 14;
            this.label5.Text = "串口";
            // 
            // Chanl2Part2
            // 
            this.Chanl2Part2.AutoSize = true;
            this.Chanl2Part2.Location = new System.Drawing.Point(211, 230);
            this.Chanl2Part2.Name = "Chanl2Part2";
            this.Chanl2Part2.Size = new System.Drawing.Size(35, 12);
            this.Chanl2Part2.TabIndex = 20;
            this.Chanl2Part2.Text = "参数2";
            // 
            // Chanl2Part1
            // 
            this.Chanl2Part1.AutoSize = true;
            this.Chanl2Part1.Location = new System.Drawing.Point(211, 161);
            this.Chanl2Part1.Name = "Chanl2Part1";
            this.Chanl2Part1.Size = new System.Drawing.Size(35, 12);
            this.Chanl2Part1.TabIndex = 19;
            this.Chanl2Part1.Text = "参数1";
            // 
            // Chanl2Part2Text
            // 
            this.Chanl2Part2Text.Location = new System.Drawing.Point(270, 227);
            this.Chanl2Part2Text.Name = "Chanl2Part2Text";
            this.Chanl2Part2Text.Size = new System.Drawing.Size(121, 21);
            this.Chanl2Part2Text.TabIndex = 18;
            // 
            // Chanl2Part1Text
            // 
            this.Chanl2Part1Text.Location = new System.Drawing.Point(270, 158);
            this.Chanl2Part1Text.Name = "Chanl2Part1Text";
            this.Chanl2Part1Text.Size = new System.Drawing.Size(121, 21);
            this.Chanl2Part1Text.TabIndex = 17;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(211, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(53, 12);
            this.label8.TabIndex = 16;
            this.label8.Text = "控制模式";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "正常模式",
            "缺齿模式",
            "更改AK值",
            "自定义发送"});
            this.comboBox3.Location = new System.Drawing.Point(270, 94);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 20);
            this.comboBox3.TabIndex = 15;
            this.comboBox3.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(20, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 12);
            this.label2.TabIndex = 21;
            this.label2.Text = "通道1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(211, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 12);
            this.label3.TabIndex = 22;
            this.label3.Text = "通道2";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(641, 270);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(121, 34);
            this.button3.TabIndex = 23;
            this.button3.Text = "读取";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Chanl2Part2);
            this.Controls.Add(this.Chanl2Part1);
            this.Controls.Add(this.Chanl2Part2Text);
            this.Controls.Add(this.Chanl2Part1Text);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboBox3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.comboBox2);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.Chanl1Part2);
            this.Controls.Add(this.Chanl1Part1);
            this.Controls.Add(this.Chanl1Part2Text);
            this.Controls.Add(this.Chanl1Part1Text);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.comboBox1);
            this.Name = "Form1";
            this.Text = "SpeedControl";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Chanl1Part1Text;
        private System.Windows.Forms.TextBox Chanl1Part2Text;
        private System.Windows.Forms.Label Chanl1Part1;
        private System.Windows.Forms.Label Chanl1Part2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label Chanl2Part2;
        private System.Windows.Forms.Label Chanl2Part1;
        private System.Windows.Forms.TextBox Chanl2Part2Text;
        private System.Windows.Forms.TextBox Chanl2Part1Text;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.IO.Ports.SerialPort serialPort1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button3;
    }
}

