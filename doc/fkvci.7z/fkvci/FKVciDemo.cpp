﻿/*
 * CAN卡收发报文测试用例程序
 *
 * 该程序演示了如何使用FKVCI库进行CAN报文的发送和接收。程序包含以下功能：
 * 1. 初始化CAN设备和通道。
 * 2. 发送标准CAN报文。
 * 3. 发送带过滤器的CAN报文。
 * 4. 发送周期性CAN报文。
 * 5. 接收并处理CAN报文。
 *
 * 使用说明：
 * 1. 包含必要的头文件：fkvci.h
 * 2. 实现消息处理函数：ProcessReceiveCanMessage
 * 3. 运行时需包含：FKVci.dll、Qt6Core.dll
 *
 * 注意事项：
 * - 在实际使用中，建议将接收到的数据放入缓存队列中，并使用单独的数据处理线程从缓存队列中取数据，以免阻塞新的CAN消息到来。
 * - 请根据实际需求调整CAN报文的ID、类型、格式和数据长度。
 *
 * FkVci库头文件说明：
 * - 头文件包含了FkVci库的所有必要定义和函数声明。
 * - 定义了不同类型的CAN、LIN、KWP和ISO数据结构。
 * - 提供了日志管理、设备管理、CAN通道管理、消息发送和接收等功能的接口。
 *
 * 作者：figkey-leiwei
 * 日期：204.08.20
 */
#include "../fkvci/include/fkvci.h"
#include <iostream>
#include <string>
#include <sstream>
#include <thread>
#include <chrono>
#include <cstring>
#include <vector>

 // 辅助函数：创建默认的 CAN 消息
static FkVciCanDataType GetDefaultCanMessage(uint32_t id, uint8_t dlc) {
    FkVciCanDataType can;
    memset(&can, 0, sizeof(FkVciCanDataType));
    can.CanID = id;
    can.DLC = dlc;
    can.FLAG = ((1 << 3) | (1 << 6));

    for (int i = 0; i < can.DLC; ++i) {
        can.Data[i] = i;
    }

    return can;
}

// 打印 CAN 消息
void printCanMessage(const FkVciCanDataType& msg) {
    std::cout << "ID: 0x" << std::hex << msg.CanID << " DLC: " << std::dec << (int)msg.DLC << " Data: ";
    for (int i = 0; i < msg.DLC; ++i) {
        std::cout << std::hex << (int)msg.Data[i] << " ";
    }
    std::cout << std::endl;
}

// 使用说明
void printUsage() {
    std::cout << "Available commands:" << std::endl;
    std::cout << "  open <device_index>" << std::endl;
    std::cout << "  close <device_index>" << std::endl;
    std::cout << "  init <device_index> <can_index>" << std::endl;
    std::cout << "  reset <device_index> <can_index>" << std::endl;
    std::cout << "  send <device_index> <can_index> <message_id> <dlc>" << std::endl;
    std::cout << "  receive <device_index> <can_index> <timeout_ms>" << std::endl;
    std::cout << "  clear <device_index> <can_index>" << std::endl;
    std::cout << "  period <device_index> <can_index> <message_id> <dlc> <interval_ms>" << std::endl;
    std::cout << "  stop_period <device_index> <can_index> <period_id>" << std::endl;
    std::cout << "  filter <device_index> <can_index> <id1> [id2] [id3] ..." << std::endl;
    std::cout << "  stop_filter <device_index> <can_index>" << std::endl;
    std::cout << "  quit" << std::endl;
}

int main() {
    std::string line;
    std::string command;

    std::cout << "Welcome to FKVCI Test Program. Type 'help' for usage information." << std::endl;

    FkVciOpenLog("fkvci_api.log", 0, -1, -1);
    while (true) {
        std::cout << "> ";
        std::getline(std::cin, line);
        std::istringstream iss(line);
        iss >> command;

        if (command == "help") {
            printUsage();
        }
        else if (command == "open") {
            int deviceIndex, subNet;
            if (iss >> deviceIndex >> subNet) {
                std::cout << "Command: open " << deviceIndex << " " << subNet << std::endl;
                int result = FkVciOpenDev(0, deviceIndex, subNet);
                if (result == 0) {
                    std::cout << "Device opened successfully" << std::endl;
                }
                else {
                    std::cerr << "Failed to open device, error code: " << result << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: open <device_index>" << std::endl;
            }
        }
        else if (command == "close") {
            int deviceIndex;
            if (iss >> deviceIndex) {
                std::cout << "Command: close " << deviceIndex << std::endl;
                int result = FkVciCloseDev(deviceIndex);
                if (result == 0) {
                    std::cout << "Device closed successfully" << std::endl;
                }
                else {
                    std::cerr << "Failed to close device, error code: " << result << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: close <device_index>" << std::endl;
            }
        }
        else if (command == "init") {
            int deviceIndex, canIndex;
            if (iss >> deviceIndex >> canIndex) {
                std::cout << "Command: init " << deviceIndex << " " << canIndex << std::endl;
                int result = FkVciInitCANFD(deviceIndex, canIndex, 500000, 2000000);
                if (result == 0) {
                    std::cout << "CANFD initialized successfully" << std::endl;
                }
                else {
                    std::cerr << "Failed to initialize CAN, error code: " << result << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: init <device_index> <can_index>" << std::endl;
            }
        }
        else if (command == "reset") {
            int deviceIndex, canIndex;
            if (iss >> deviceIndex >> canIndex) {
                std::cout << "Command: reset " << deviceIndex << " " << canIndex << std::endl;
                int result = FkVciResetCAN(deviceIndex, canIndex);
                if (result == 0) {
                    std::cout << "CAN reset successfully" << std::endl;
                }
                else {
                    std::cerr << "Failed to reset CAN, error code: " << result << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: reset <device_index> <can_index>" << std::endl;
            }
        }
        else if (command == "send") {
            int deviceIndex, canIndex;
            std::string messageIdStr;
            int dlc;
            if (iss >> deviceIndex >> canIndex >> messageIdStr >> dlc) {
                try {
                    uint32_t messageId = (messageIdStr.substr(0, 2) == "0x" || messageIdStr.substr(0, 2) == "0X") ?
                        std::stoul(messageIdStr, nullptr, 16) : std::stoul(messageIdStr);

                    if (dlc < 0 || dlc > 64) {
                        throw std::out_of_range("DLC must be between 0 and 64");
                    }

                    std::cout << "Command: send " << deviceIndex << " " << canIndex << " "
                        << messageIdStr << " " << dlc << std::endl;

                    FkVciCanDataType message = GetDefaultCanMessage(messageId, static_cast<uint8_t>(dlc));
                    uint32_t len = 2;
                    int result = FkVciTransmitCAN(deviceIndex, canIndex, &message, 1);

                    if (result == 0) {
                        std::cout << "Message sent successfully" << std::endl;
                    }
                    else {
                        std::cerr << "Failed to send message, error code: " << result << std::endl;
                    }
                }
                catch (const std::exception& e) {
                    std::cerr << "Error processing input: " << e.what() << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: send <device_index> <can_index> <message_id> <dlc>" << std::endl;
            }
        }
        else if (command == "receive") {
            int deviceIndex, canIndex;
            uint32_t timeout;
            if (iss >> deviceIndex >> canIndex >> timeout) {
                std::cout << "Command: receive " << deviceIndex << " " << canIndex << " " << timeout << std::endl;
                FkVciCanDataType messages[10];
                uint32_t len = 10;
                int result = FkVciReceiveCAN(deviceIndex, canIndex, messages, len, timeout);
                if (result == 0) {
                    std::cout << "Received " << len << " messages:" << std::endl;
                    for (uint32_t i = 0; i < len; ++i) {
                        printCanMessage(messages[i]);
                    }
                }
                else {
                    std::cerr << "Failed to receive messages, error code: " << result << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: receive <device_index> <can_index> <timeout_ms>" << std::endl;
            }
        }
        else if (command == "clear") {
            int deviceIndex, canIndex;
            if (iss >> deviceIndex >> canIndex) {
                std::cout << "Command: clear " << deviceIndex << " " << canIndex << std::endl;
                int result = FkVciClearCAN(deviceIndex, canIndex);
                if (result == 0) {
                    std::cout << "CAN clear successfully" << std::endl;
                }
                else {
                    std::cerr << "Failed to reset clear, error code: " << result << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: clear <device_index> <can_index>" << std::endl;
            }
        }
        else if (command == "period") {
            int deviceIndex, canIndex;
            std::string messageIdStr;
            int dlc;
            uint32_t interval;
            if (iss >> deviceIndex >> canIndex >> messageIdStr >> dlc >> interval) {
                try {
                    uint32_t messageId = (messageIdStr.substr(0, 2) == "0x" || messageIdStr.substr(0, 2) == "0X") ?
                        std::stoul(messageIdStr, nullptr, 16) : std::stoul(messageIdStr);

                    if (dlc < 0 || dlc > 64) {
                        throw std::out_of_range("DLC must be between 0 and 64");
                    }

                    std::cout << "Command: period " << deviceIndex << " " << canIndex << " "
                        << messageIdStr << " " << dlc << " " << interval << std::endl;

                    FkVciCanDataType message = GetDefaultCanMessage(messageId, static_cast<uint8_t>(dlc));
                    int result = FkVciStartPeriodCAN(deviceIndex, canIndex, &message, interval);
                    if (result > 0) {
                        std::cout << "Period transmission started for ID 0x" << std::hex << messageId
                            << " and assigned id is " << std::dec << result << std::endl;
                    }
                    else {
                        std::cerr << "Failed to start period transmission for ID 0x" << std::hex << messageId
                            << ", error code: " << std::dec << result << std::endl;
                    }
                }
                catch (const std::exception& e) {
                    std::cerr << "Error processing input: " << e.what() << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: period <device_index> <can_index> <base_message_id> <dlc> <interval_ms>" << std::endl;
            }
        }
        else if (command == "stop_period") {
            int deviceIndex, canIndex;
            std::string periodIdStr;
            if (iss >> deviceIndex >> canIndex >> periodIdStr) {
                try {
                    uint32_t messageId = (periodIdStr.substr(0, 2) == "0x" || periodIdStr.substr(0, 2) == "0X") ?
                        std::stoul(periodIdStr, nullptr, 16) : std::stoul(periodIdStr);

                    std::cout << "Command: stop_period " << deviceIndex << " " << canIndex << " " << periodIdStr << std::endl;

                    int result = FkVciStopPeriodCAN(deviceIndex, canIndex, messageId);
                    if (result == 0) {
                        std::cout << "Periodic transmission stopped" << std::endl;
                    }
                    else {
                        std::cerr << "Failed to stop period transmission, error code: " << result << std::endl;
                    }
                }
                catch (const std::exception& e) {
                    std::cerr << "Error processing input: " << e.what() << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: stop_period <device_index> <can_index> <period_id>" << std::endl;
            }
        }
        else if (command == "filter") {
            int deviceIndex, canIndex;
            if (iss >> deviceIndex >> canIndex) {
                std::vector<uint32_t> filterIds;
                std::string idStr;

                // 读取所有剩余的ID
                while (iss >> idStr) {
                    try {
                        uint32_t id = (idStr.substr(0, 2) == "0x" || idStr.substr(0, 2) == "0X") ?
                            std::stoul(idStr, nullptr, 16) : std::stoul(idStr);
                        filterIds.push_back(id);
                    }
                    catch (const std::exception& e) {
                        std::cerr << "Error parsing ID " << idStr << ": " << e.what() << std::endl;
                        continue;
                    }
                }

                if (filterIds.empty()) {
                    std::cerr << "No filter IDs provided." << std::endl;
                    std::cerr << "Usage: filter <device_index> <can_index> <id1> [id2] [id3] ..." << std::endl;
                    continue;
                }

                std::cout << "Command: filter " << deviceIndex << " " << canIndex
                    << " with " << filterIds.size() << " IDs" << std::endl;

                int result = FkVciStartFilterCAN(deviceIndex, canIndex, filterIds.data(),
                    static_cast<uint32_t>(filterIds.size()));

                if (result == 0) {
                    std::cout << "Filter set successfully for IDs: ";
                    for (const auto& id : filterIds) {
                        std::cout << "0x" << std::hex << id << " ";
                    }
                    std::cout << std::dec << std::endl;
                }
                else {
                    std::cerr << "Failed to set filter, error code: " << result << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: filter <device_index> <can_index> <id1> [id2] [id3] ..." << std::endl;
            }
        }
        else if (command == "stop_filter") {
            int deviceIndex, canIndex;
            if (iss >> deviceIndex >> canIndex) {
                std::cout << "Command: stop_filter " << deviceIndex << " " << canIndex << std::endl;

                int result = FkVciStopFilterCAN(deviceIndex, canIndex);
                if (result == 0) {
                    std::cout << "Filter stopped successfully" << std::endl;
                }
                else {
                    std::cerr << "Failed to stop filter, error code: " << result << std::endl;
                }
            }
            else {
                std::cerr << "Invalid arguments. Usage: stop_filter <device_index> <can_index>" << std::endl;
            }
        }
        else if (command == "quit" || command == "exit") {
            std::cout << "Command: " << command << std::endl;

            FkVciCloseDev(-1);
            break;
        }
        else {
            std::cerr << "Unknown command. Type 'help' for usage information." << std::endl;
        }
    }

    FkVciCloseLog();
    std::cout << "Exiting FKVCI Test Program." << std::endl;
    return 0;
}