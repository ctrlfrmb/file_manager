﻿/*----------------------------------------------------------------------------
| FigKey CAN/LIN Device API Header File
|
| This header file defines the API for interacting with CAN and LIN devices.
| It includes data structures and function declarations for initializing,
| configuring, and communicating with CAN and LIN channels. Note that the
| LIN API is currently under development and not yet available.
|
|-----------------------------------------------------------------------------
|               C O P Y R I G H T
|-----------------------------------------------------------------------------
| Copyright (c) figkey. All rights reserved.
| Group: figkey-develep
| Author: figkey-leiwei
| Date: 2024-2048
 ----------------------------------------------------------------------------*/

#ifndef FKVCI_H
#define FKVCI_H

typedef unsigned char      fk_uint8_t;
typedef unsigned short     fk_uint16_t;
typedef unsigned int       fk_uint32_t;
typedef unsigned long long fk_uint64_t;

//#include <stdint.h>

#define FKCAN_VIEW_COLUMN_NUMBER                      0
#define FKCAN_VIEW_COLUMN_TIME                        1
#define FKCAN_VIEW_COLUMN_INDEX                       2
#define FKCAN_VIEW_COLUMN_CHANNEL                     3
#define FKCAN_VIEW_COLUMN_CAN_ID                      4
#define FKCAN_VIEW_COLUMN_MESSAGE_NAME                5
#define FKCAN_VIEW_COLUMN_DIR                         6
#define FKCAN_VIEW_COLUMN_CAN_TYPE                    7
#define FKCAN_VIEW_COLUMN_FRAME_TYPE                  8
#define FKCAN_VIEW_COLUMN_FRAME_FORMAT                9
#define FKCAN_VIEW_COLUMN_DLC                         10
#define FKCAN_VIEW_COLUMN_DATA                        11
#define FKCAN_VIEW_COLUMN_COUNT                       12
#define FKCAN_VIEW_STRING_LENGTH                      128
#define FKCAN_VIEW_ROW_DATA_SIZE                      1536

#ifdef _WIN32
    #ifdef FKVCI_BUILDING_DLL
        #define FKVCI_DLL_EXPORT extern "C" __declspec(dllexport)
    #else
        #define FKVCI_DLL_EXPORT extern "C" __declspec(dllimport)
    #endif
#else
    #define FKVCI_DLL_EXPORT extern "C"
#endif

#pragma pack(push, 8)

typedef struct _FkVciCanDataType
{
    fk_uint32_t CanID;         // CAN ID
    fk_uint8_t  DLC;           // data length
    fk_uint8_t  FLAG;          // bit0:Standard Frame=0/Extend Frame=1   bit1:Data Frame=0/Remote Frame=1   bit3:CANFD BRSEN=1  Bit6:CAN=0/CANFD=1
    fk_uint8_t  REV1;
    fk_uint8_t  REV2;          // 0x01:send 0x02:receive 0x04:error
    fk_uint32_t TimesampL;
    fk_uint32_t TimesampH;
    fk_uint8_t  Data[64];      // when REV2 = error, data code 4 byte
}FkVciCanDataType;

typedef struct _FkVciLinDataType
{
    fk_uint8_t  LinID;         // LIN ID
    fk_uint8_t  DLC;           // data length
    fk_uint8_t  CheckType;     // check mode 0: Standard 1: Enhanced
    fk_uint8_t  MsgType;       // 0:unknown type 1:master write 2:master read 3:slave write 4:slave read
    fk_uint32_t TimesampL;     // When sending, it is the time interval in ms. When it is received, it is the timestamp in 0.1us.
    fk_uint32_t TimesampH;
    fk_uint8_t  Data[8];
    fk_uint8_t  CheckSum;      //Checksum
    fk_uint8_t  PID;
    fk_uint8_t  REV1;          // 0x00:master read 0x01:slave read 0x10:master write 0x11:slave write
    fk_uint8_t  REV2;
}FkVciLinDataType;

typedef union _FkVciDataType
{
    FkVciCanDataType Can;
    FkVciLinDataType Lin;
}FkVciDataType;

typedef struct _FkVciMessage
{
    FkVciDataType frame;
    fk_uint64_t timestamp;
    fk_uint8_t index;
    fk_uint8_t channel;
}FkVciMessage;

#pragma pack(pop)

/// <summary>
/// 打开日志 建议调试时使用，通常不调用此接口，会占用CPU资源和硬盘资源
/// </summary>
/// <param name="logFile">日志文件，形如:logs/fkvci.log</param>
/// <param name="level">日志等级，-1:默认输出（默认1）0:DEBUG 1:INFO 2:WARN 3:ERROR</param>
/// <param name="maxSize">文件大小, 范围(1~20), 单位M. -1:默认5M</param>
/// <param name="maxFiles">文件个数, 范围(1~20), -1:默认保留10个文件</param>
/// <returns>0:打开成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciOpenLog(const char *logFile, int level, int maxSize, int maxFiles);
/// <summary>
/// 关闭日志
/// </summary>
/// <returns>0:关闭成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciCloseLog();
/// <summary>
/// 打开设备
/// </summary>
/// <param name="deviceType">设置类型（暂未启用）0:LAN 1:USB 2:COM</param>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="reserved">子网地址:1~254，默认0表示不绑定（建议绑定，以免网络断开）</param>
/// <returns>0:打开成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciOpenDev(int deviceType, int deviceIndex, int reserved);
/// <summary>
/// 关闭设备
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F 特殊值-1:停止所有打开的设备</param>
/// <returns>0:关闭成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciCloseDev(int deviceIndex);
/// <summary>
/// 查询版本
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <returns>0:查询失败 其它:版本信息 B0:version B1:year B2:month B3:day</returns>
FKVCI_DLL_EXPORT fk_uint32_t FkVciGetVersion(int deviceIndex);
/// <summary>
/// 获取设备基准时间
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <returns>正数:获取成功 0:获取失败 </returns>
FKVCI_DLL_EXPORT fk_uint64_t FkVciGetBaseTime(int deviceIndex);
/// <summary>
/// 初始化CAN通道（打开通道）
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="canIndex">CAN通道号 特殊值-1:打开所有通道 0xFF:打开设备以及所有CAN通道(已包含FkVciOpenDev调用)</param>
/// <param name="baudRate">同步波特率</param>
/// <returns>0:初始化成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciInitCAN(int deviceIndex, int canIndex, fk_uint32_t baudRate);
/// <summary>
/// 初始化CANFD通道（打开通道）
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="canIndex">CAN通道号 特殊值-1:打开所有通道 0xFF:打开设备以及所有CAN通道(已包含FkVciOpenDev调用)</param>
/// <param name="baudRate">同步波特率</param>
/// <param name="dataBaudRate">数据波特率</param>
/// <returns>0:初始化成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciInitCANFD(int deviceIndex, int canIndex, fk_uint32_t baudRate, fk_uint32_t dataBaudRate);
/// <summary>
/// 复位CAN通道（关闭通道）
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="canIndex">CAN通道号 特殊值-1:复位所有通道 0xFF:复位所有CAN通道并关闭设备(已包含FkVciCloseDev调用)</param>
/// <returns>0:复位成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciResetCAN(int deviceIndex, int canIndex);
/// <summary>
/// 清空CAN通道接收缓存
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="canIndex">CAN通道号 特殊值-1:清空所有通道缓存</param>
/// <returns>0:清空成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciClearCAN(int deviceIndex, int canIndex);
/// <summary>
/// 接收CAN消息
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="canIndex">CAN通道号</param>
/// <param name="messages">CAN消息数组</param>
/// <param name="len">[in|out] 输入时表示想要接收消息条数，输出时表示实际接收消息条数</param>
/// <param name="timeout">等待时间，单位ms</param>
/// <returns>0:接收成功 其它:失败错误码</returns>
FKVCI_DLL_EXPORT int FkVciReceiveCAN(int deviceIndex, int canIndex, FkVciCanDataType *messages, fk_uint32_t &len, fk_uint32_t timeout);
/// <summary>
/// 发送CAN消息
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="canIndex">CAN通道号</param>
/// <param name="messages">CAN消息数组</param>
/// <param name="len">发送消息条数，最大值：0x7F</param>
/// <returns>0:发送成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciTransmitCAN(int deviceIndex, int canIndex, const FkVciCanDataType *messages, fk_uint32_t len);
/// <summary>
/// 周期发送CAN消息
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="canIndex">CAN通道号</param>
/// <param name="message">CAN消息</param>
/// <param name="interval">发送间隔时间(毫秒)</param>
/// <returns>正数: 周期消息id 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciStartPeriodCAN(int deviceIndex, int canIndex, const FkVciCanDataType *message, fk_uint32_t interval);
/// <summary>
/// 停止周期发送CAN消息
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="canIndex">CAN通道号 特殊值-1:停止所有周期消息(周期线程停止)</param>
/// <param name="id">周期消息id  特殊值-1:停止当前通道所有周期消息</param>
/// <returns>0:停止成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciStopPeriodCAN(int deviceIndex, int canIndex, int id);
/// <summary>
/// 过滤CAN消息
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="canIndex">CAN通道号</param>
/// <param name="ids">过滤的消息ID数组</param>
/// <param name="len">过滤数组长度</param>
/// <returns>0:过滤设置成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciStartFilterCAN(int deviceIndex, int canIndex, fk_uint32_t *ids, fk_uint32_t len);
/// <summary>
/// 停止过滤CAN消息
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="canIndex">CAN通道号 特殊值-1:停止所有过滤消息</param>
/// <returns>0:停止过滤成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciStopFilterCAN(int deviceIndex, int canIndex);

///*******************************************************************************/
/// <summary>
/// 初始化LIN通道（打开通道）
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="linIndex">LIN通道号 特殊值-1:打开所有通道 0xFF:打开设备以及所有LIN通道(已包含FkVciOpenDev调用) </param>
/// <param name="mode">0:主模式 1:从模式</param>
/// <param name="baudRate">波特率</param>
/// <returns>0:初始化成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciInitLIN(int deviceIndex, int linIndex, fk_uint32_t mode, fk_uint32_t baudRate);
/// <summary>
/// 复位LIN通道（关闭通道）
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="linIndex">LIN通道号 特殊值-1:复位所有通道 0xFF:复位所有LIN通道并关闭设备(已包含FkVciCloseDev调用)</param>
/// <returns>0:复位成功 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciResetLIN(int deviceIndex, int linIndex);
/// <summary>
/// 接收LIN消息
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="linIndex">LIN通道号</param>
/// <param name="messages">LIN消息数组</param>
/// <param name="len">[in|out] 输入时表示想要接收消息条数，输出时表示实际接收消息条数</param>
/// <param name="timeout">等待时间，单位ms</param>
/// <returns>0:接收成功 其它:失败错误码</returns>
FKVCI_DLL_EXPORT int FkVciReceiveLIN(int deviceIndex, int linIndex, FkVciLinDataType *messages, fk_uint32_t &len, fk_uint32_t timeout);
/// <summary>
/// 发送LIN消息
/// </summary>
/// <param name="deviceIndex">设备索引:0x00~0x0F</param>
/// <param name="linIndex">LIN通道号</param>
/// <param name="messages">LIN消息数组</param>
/// <param name="len">发送消息条数，最大值：0x7F</param>
/// <returns>0:发送成功(加入待发送队列) 其它:失败错误码 </returns>
FKVCI_DLL_EXPORT int FkVciTransmitLIN(int deviceIndex, int linIndex, const FkVciLinDataType *messages, fk_uint32_t len);
///// <summary>
///// 主模式下 设置内部周期调度 并启动LIN
///// 从模式下 配置一个调度表
///// </summary>
///// <param name="channel_handle"></通道句柄>
///// <param name="pTransmit"></请求数据开始地址>
///// <param name="len"></请求数据条数>
///// <returns></错误码>
//int FkVciLinSchStart(SHANDLE channel_handle, FkVciLinDataType* pTransmit, fk_uint32_t len);
///// <summary>
///// 主模式下 关闭内部周期调度
///// 从模式下 清空从机数据
///// </summary>
///// <param name="channel_handle"></通道句柄>
///// <returns></错误码>
//int FkVciLinSchStop(SHANDLE channel_handle);
///// <summary>
///// 从机模式下 修改/添加一条数据信息
///// </summary>
///// <param name="channel_handle"></param>
///// <param name="pTransmit"></param>
///// <returns></returns>
//int FkVciLinSlaveWriteMsg(SHANDLE channel_handle, FkVciLinDataType* pTransmit);
///// <summary>
///// 后期扩展功能使用
///// </summary>
///// <param name="channel_handle"></param>
///// <param name="ConfigId"></param>
///// <param name="pInitConfig"></param>
///// <returns></returns>
//int FkVciConfigLIN(SHANDLE channel_handle, fk_uint32_t ConfigId, void* pInitConfig);

#endif
