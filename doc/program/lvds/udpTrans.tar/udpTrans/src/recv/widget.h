#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QStringList>
#include <QTimer>
#include <QHostAddress>
#include <QtEndian>
#include <QMessageBox>
#include <QCheckBox>
#include <QSpinBox>
#include <QFile>
#include <QTextStream>
#include <QMessageBox>
#include <QTextBrowser>
#include <QTableWidgetItem>
#include <QRegularExpression>
#include <QFileDialog>
#include "udp_recvthread.h"
#include "handlethread.h"
#include "proto.h"
#include "data_process.h"
#include "DynamicTestPattern.h"
#include "tcp_cmd_recvthread.h"
#include "tcp_video_recvthread.h"


namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    void initUI();
    ~Widget();
    void closeEvent(QCloseEvent *event);
    static void customMessageHandler(QtMsgType type, const QMessageLogContext &context, const QString &msg);
    void init_i2c_list_table(void);
    QString generateBuildVersion(void);
    QByteArray makeCommand(CommandType type);
    void updateSettingsUI(const config_Settings_t* cfg);
    void startDeviceTimeoutCheck(int timeoutMs);

signals:

private slots:
    //udp recv thread slot
    void serverStartedSlot(bool bok);

    void board_cmd_handle(QByteArray data);

    void soft_cmd_handle(QByteArray data);

    //handle thread slot
    void showPixmapSlot(QPixmap pix);

    void appendLog(QString msg);

    void slotSpeedOut();

    void on_btn_connect_clicked();

    void on_btn_disconnect_clicked();

    void on_btn_video_on_clicked();

    void on_btn_video_off_clicked();

    void on_btn_pic_clicked();


    void on_btn_rd_S_clicked();

    void on_btn_SV_S_clicked();

    void on_btn_rd_D_clicked();

    void on_lineEdit_MM_ADDR_editingFinished();

    void on_lineEdit_MM_DATA_editingFinished();

    void on_btn_MM_rd_clicked();

    void on_btn_MM_wr_clicked();

    void on_btn_iic_write_clicked();

    void on_btn_iic_read_clicked();

    void on_comboBox_reg_num_activated(const QString &arg1);

    void on_btn_cp_on_clicked();

    void on_btn_cp_off_clicked();

    void on_btn_set_pixel_clicked();

    void on_btn_set_threshold_clicked();

    void on_btn_list_add_clicked();

    void on_btn_list_delete_clicked();

    void on_btn_list_run_clicked();

    void on_btn_iic_show_clear_clicked();

    void on_btn_list_open_clicked();

    void on_btn_list_save_clicked();

    void on_btn_get_clicked();

    void on_btn_cp_status_clicked();

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void show_test_tpg(QPixmap pix);

    void on_btn_screenshot_clicked();

private:
    Ui::Widget *ui;
    Udp_RecvThread* udp_recvthread;
    Tcp_Video_RecvThread *tcp_video_recvthread;
    Tcp_Cmd_RecvThread *tcp_cmd_recvthread;
    HandleThread* handlethread;
    QStringList loglist;
    int nPicCount;
    QTimer timerSpeed;

    QTimer* deviceTimeoutTimer = nullptr;
    bool isDeviceConnected = false;
    DynamicTestPattern *testPattern = nullptr;
    static QTextBrowser *g_textBrowser; // 静态变量
};

#endif // WIDGET_H
