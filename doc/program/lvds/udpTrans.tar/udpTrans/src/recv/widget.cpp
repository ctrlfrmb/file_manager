#include "widget.h"
#include "ui_widget.h"
#include <QDebug>
#include <QMessageBox>
#include <QDateTime>
#include <QThread>
#include <QScrollBar>
#include <QCoreApplication>
#include <QDir>

//#define PRINT_GUI

#if defined (PRINT_GUI)
QTextBrowser* Widget::g_textBrowser = nullptr; // 静态变量定义
#endif

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    initUI();
    udp_recvthread = new Udp_RecvThread;
    connect(udp_recvthread,SIGNAL(serverStarted(bool)),this, SLOT(serverStartedSlot(bool)));
    connect(udp_recvthread,SIGNAL(board_cmd_data(QByteArray)),this, SLOT(board_cmd_handle(QByteArray)));
    connect(udp_recvthread,SIGNAL(soft_cmd_data(QByteArray)),this, SLOT(soft_cmd_handle(QByteArray)));

    handlethread = new HandleThread;
    connect(handlethread,SIGNAL(showPixmapSig(QPixmap)), this, SLOT(showPixmapSlot(QPixmap)));
    connect(handlethread, SIGNAL(showMsgSig(QString)), this, SLOT(appendLog(QString)));
    handlethread->start();
    connect(&timerSpeed, SIGNAL(timeout()),this, SLOT(slotSpeedOut()));



    // 在构造函数里添加：
//    testPattern = new DynamicTestPattern(1920, 1080, 100, 60, this);
//    connect(testPattern, &DynamicTestPattern::frameReady, this, &Widget::show_test_tpg);
//    testPattern->start();

#if defined (PRINT_GUI)
    g_textBrowser = ui->textBrowser_test; // 绑定全局指针
    qInstallMessageHandler(customMessageHandler);
#endif


//    on_btn_connect_clicked();


//    // 控制线程
//    tcp_cmd_recvthread = new Tcp_Cmd_RecvThread(this);
//    tcp_cmd_recvthread->setServer("192.168.1.11", 5555);
//    connect(tcp_cmd_recvthread,SIGNAL(serverStarted(bool)),this, SLOT(serverStartedSlot(bool)));
//    connect(tcp_cmd_recvthread,SIGNAL(board_cmd_data(QByteArray)),this, SLOT(board_cmd_handle(QByteArray)));
//    connect(tcp_cmd_recvthread,SIGNAL(soft_cmd_data(QByteArray)),this, SLOT(soft_cmd_handle(QByteArray)));


//    // ✅ 关键：只在 TCP 连接成功后发送命令
//    connect(tcp_cmd_recvthread, &Tcp_Cmd_RecvThread::serverStarted,
//            this, [=](bool ok)
//    {
//        if (ok)
//        {
//            QByteArray cmd = makeCommand(CMD_SOFTWARE_VER);
//            tcp_cmd_recvthread->sendCommandToHost(cmd);
//        }
//    });

//    tcp_cmd_recvthread->start();



//    // 控制线程
//    tcp_video_recvthread = new Tcp_Video_RecvThread(this);
//    tcp_video_recvthread->setServer("192.168.1.11", 7777);
//    connect(tcp_video_recvthread,SIGNAL(serverStarted(bool)),this, SLOT(serverStartedSlot(bool)));
//    connect(tcp_video_recvthread,SIGNAL(board_cmd_data(QByteArray)),this, SLOT(board_cmd_handle(QByteArray)));
//    connect(tcp_video_recvthread,SIGNAL(soft_cmd_data(QByteArray)),this, SLOT(soft_cmd_handle(QByteArray)));

//    connect(tcp_video_recvthread, &Tcp_Video_RecvThread::serverStarted,
//            this, [=](bool ok)
//    {
//        if (ok)
//        {
//            QByteArray cmd = makeCommand(CMD_PIC_ON);
//            tcp_video_recvthread->sendCommandToHost(cmd);
//        }
//    });

//    tcp_video_recvthread->start();


}

void Widget::initUI()
{
    this->setWindowTitle(tr("figkey udp camera"));
    ui->lineEdit_IP->setText("192.168.1.10");
    ui->btn_disconnect->setEnabled(false);
    ui->labelSpeed->setText("0"); // 重置速度显示
    ui->btn_video_on->setEnabled(false);
    ui->btn_video_off->setEnabled(false);
    ui->btn_SV_S->setEnabled(false);
    ui->btn_rd_D->setEnabled(false);
    ui->btn_rd_S->setEnabled(false);
    ui->btn_MM_rd->setEnabled(false);
    ui->btn_MM_wr->setEnabled(false);

    ui->label_gui_e->setText(generateBuildVersion());
    ui->label_had_e->setStyleSheet("color: blue;");
    ui->label_sof_e->setStyleSheet("color: blue;");
    ui->label_f_wd_e->setStyleSheet("color: blue;");
    ui->label_f_mk_e->setStyleSheet("color: blue;");
    ui->label_f_sz_e->setStyleSheet("color: blue;");

    init_i2c_list_table();

}


Widget::~Widget()
{
    delete ui;
    udp_recvthread->stopReceiver();
    if (udp_recvthread->isRunning())
    {
        udp_recvthread->quit();
        udp_recvthread->wait();
    }
    delete udp_recvthread;

    handlethread->stopHandle();
    if (handlethread->isRunning())
    {
        handlethread->quit();
        handlethread->wait();
    }
    delete handlethread;
}

void Widget::closeEvent(QCloseEvent *event)
{
    QMessageBox::StandardButton reply;
    reply = QMessageBox::question(this, "退出确认", "确定要退出软件吗？",
                                  QMessageBox::Yes | QMessageBox::No);

    if (reply == QMessageBox::Yes)
    {
        event->accept();  // 允许关闭
    }
    else
    {
        event->ignore();  // 忽略关闭
    }
}
#if defined (PRINT_GUI)
// 自定义消息处理函数
void Widget::customMessageHandler(QtMsgType type, const QMessageLogContext &context, const QString &msg)
{
    QString prefix;
    switch (type)
    {
    case QtDebugMsg:
        prefix = "[Debug] ";
        break;
    case QtWarningMsg:
        prefix = "[Warning] ";
        break;
    case QtCriticalMsg:
        prefix = "[Critical] ";
        break;
    case QtFatalMsg:
        prefix = "[Fatal] ";
        break;
    }

    QString time = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    QString fullMsg = QString("%1 %2%3").arg(time).arg(prefix).arg(msg);

    // 如果 textBrowser 已经绑定，就输出到界面
    if (g_textBrowser)
    {
        g_textBrowser->append(fullMsg);
    }
}
#endif

QString Widget::generateBuildVersion()
{
    QString rawDate = QString(__DATE__); // e.g. "Jul  9 2025"

    // 解析月份英文缩写成数字
    QString monthStr = rawDate.mid(0,3);
    QMap<QString,int> monthMap = {
        {"Jan",1}, {"Feb",2}, {"Mar",3}, {"Apr",4}, {"May",5}, {"Jun",6},
        {"Jul",7}, {"Aug",8}, {"Sep",9}, {"Oct",10}, {"Nov",11}, {"Dec",12}
    };
    int month = monthMap.value(monthStr, 0);

    // 解析日期（去掉前后空格）
    int day = rawDate.mid(4,2).trimmed().toInt();

    // 解析年份
    int year = rawDate.mid(7,4).toInt();

    if (month == 0 || day == 0 || year == 0) {
        qWarning() << "Failed to parse __DATE__:" << rawDate;
        return "0x00000000";
    }

    QDate date(year, month, day);
    if (!date.isValid()) {
        qWarning() << "Invalid date constructed from __DATE__:" << rawDate;
        return "0x00000000";
    }

    QString datePart = date.toString("yyyyMMdd");

    QString buildTime = QString(__TIME__);
    QString hourPart = buildTime.left(2);
    if (hourPart.length() < 2)
        hourPart = "0" + hourPart;

    QString versionStr = QString("0x%1%2").arg(datePart).arg(hourPart);

    qDebug() << "Parsed date:" << date << ", versionStr:" << versionStr;

    return versionStr;
}


void Widget::init_i2c_list_table()
{
    ui->tableWidget->setColumnCount(7); // 增加一列
    ui->tableWidget->setHorizontalHeaderLabels(QStringList()
        << "选择"
        << "操作类型"
        << "从机地址(Hex)"
        << "寄存器地址(Hex)"     // 新增列
        << "数据(Hex)"
        << "读数据字节数"
        << "延时(ms)");

    ui->tableWidget->verticalHeader()->setVisible(false); // 隐藏行号
//    ui->tableWidget->horizontalHeader()->setStretchLastSection(true); // 最后一列填满
//    ui->tableWidget->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents); // 自适应列宽
    ui->tableWidget->setColumnWidth(0, 60);  // checkbox
    ui->tableWidget->setColumnWidth(1, 70);  // 操作类型
    ui->tableWidget->setColumnWidth(2, 120);  // 从机地址
    ui->tableWidget->setColumnWidth(3, 120);  // 寄存器地址
    ui->tableWidget->setColumnWidth(4, 120);  // 写入数据
    ui->tableWidget->setColumnWidth(5, 120);  // 字节数
    ui->tableWidget->setColumnWidth(6, 80);  // 延时

}



void Widget::on_btn_connect_clicked()
{
    udp_recvthread->strIP = ui->lineEdit_IP->text();
    if(udp_recvthread->strIP.isEmpty())
    {
        udp_recvthread->strIP = "192.168.1.10";
    }
    udp_recvthread->port = 5555;
    if (udp_recvthread->isRunning())
    {
        QMessageBox::warning(this, "Error", "接收线程已在运行中");
        return;
    }
    udp_recvthread->startReceiver();

    nPicCount = 0;
    timerSpeed.start(1000);

    QThread::msleep(100);  // 延时200毫秒

    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_HARDWARE_VER));
//    startDeviceTimeoutCheck(1000);
    QThread::msleep(50);
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_SOFTWARE_VER));
//    startDeviceTimeoutCheck(1000);
    QThread::msleep(50);
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_RD_SETTINGS));
//    startDeviceTimeoutCheck(1000);
    QThread::msleep(50);

    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_FS_ADDR));
//    startDeviceTimeoutCheck(1000);
    QThread::msleep(50);
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_FS_MASK));
//    startDeviceTimeoutCheck(1000);
    QThread::msleep(50);
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_FS_SIZE));

}

void Widget::on_btn_disconnect_clicked()
{
    udp_recvthread->stopReceiver();

    timerSpeed.stop();

    ui->labelPic->clear(); // 停止时清空图像
    ui->labelSpeed->setText("0"); // 重置速度显示

    ui->lineEdit_ip->clear();
    ui->lineEdit_mask->clear();
    ui->lineEdit_gw->clear();
    ui->lineEdit_mac->clear();

    ui->label_had_e->setText("?");
    ui->label_sof_e->setText("?");
    ui->label_f_wd_e->setText("?");
    ui->label_f_mk_e->setText("?");
    ui->label_f_sz_e->setText("?");
}


void Widget::serverStartedSlot(bool sta)
{
    ui->btn_disconnect->setEnabled(sta);
    ui->btn_connect->setEnabled(!sta);
    ui->lineEdit_IP->setEnabled(!sta);
    ui->btn_video_on->setEnabled(sta);
    ui->btn_video_off->setEnabled(sta);
    ui->btn_SV_S->setEnabled(sta);
    ui->btn_rd_D->setEnabled(sta);
    ui->btn_rd_S->setEnabled(sta);
    ui->btn_MM_rd->setEnabled(sta);
    ui->btn_MM_wr->setEnabled(sta);
    QString msg;
    if(sta){
        msg = ("开始接收...");
    }else{
        msg = ("停止接收...");
    }
    appendLog(msg);
}

bool savePixmapToPicFolder(const QPixmap& pixmap)
{
    QDir dir(QCoreApplication::applicationDirPath());
    if (!dir.exists("pic") && !dir.mkdir("pic"))
        return false;

    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss_zzz");
    QString path = dir.filePath(QString("pic/image_%1.png").arg(timestamp));

    return pixmap.save(path);
}


void Widget::showPixmapSlot(QPixmap pix)
{
    nPicCount++;
    QPixmap scalpix = pix.scaled(ui->labelPic->width()- 5,ui->labelPic->height()- 5) ;
    ui->labelPic->setPixmap(scalpix);
    ui->labelPic->setScaledContents(true);
//    savePixmapToPicFolder(pix);


}

void Widget::show_test_tpg(QPixmap pix)
{
    QPixmap scalpix = pix.scaled(ui->label_tpg->width() - 5,
                                 ui->label_tpg->height() - 5,
                                 Qt::KeepAspectRatio,
                                 Qt::SmoothTransformation);
    ui->label_tpg->setPixmap(scalpix);
    ui->label_tpg->setScaledContents(true);

    QString resolution = QString("分辨率: %1x%2").arg(pix.width()).arg(pix.height());
    ui->label_info->setText(QString("%1  |  帧率: %2 FPS")
                          .arg(resolution)
                          .arg(testPattern->currentFps));

    // 转换 QPixmap → QImage，并保证格式
    QImage img = pix.toImage().convertToFormat(QImage::Format_RGB888);

    // 写入共享内存
    if (!handlethread->writeImageToSharedMemory(img, 1))
    {
       qWarning() << QString("CH%1 failed to write image to shared memory!").arg(1);
    }

}


void Widget::appendLog(QString msg)
{
    QString strmsg = QString("[%1] %2")
                     .arg(QTime::currentTime().toString("hh:mm:ss"))
                     .arg(msg);

    loglist.push_back(strmsg);  // 保留所有历史日志

    // 只取最近 100 条（或任意你想展示的数量）
    int maxDisplay = 100;
    int startIdx = qMax(0, loglist.count() - maxDisplay);
    QStringList displayList = loglist.mid(startIdx);

    QString tips = loglist.join("\n");
    ui->textBrowser->setText(tips);

    // 可选：自动滚动到底部
    ui->textBrowser->verticalScrollBar()->setValue(
    ui->textBrowser->verticalScrollBar()->maximum());
}



void Widget::slotSpeedOut()
{

    ui->resolution->setText(QString("%1 x %2").arg(handlethread->channelStates[1].width).arg(handlethread->channelStates[1].height));
    ui->labelSpeed->setText(QString::number(nPicCount));
    nPicCount = 0;
}


void Widget::startDeviceTimeoutCheck(int timeoutMs)
{
    if (!deviceTimeoutTimer)
    {
        deviceTimeoutTimer = new QTimer(this);
        deviceTimeoutTimer->setSingleShot(true);
        connect(deviceTimeoutTimer, &QTimer::timeout, this, [this]() {
            if (!isDeviceConnected)
            {
                QMessageBox::warning(this, "提示", "设备无响应，请检查网络或设备状态！");
                on_btn_disconnect_clicked();
            }
        });
    }

    isDeviceConnected = false;  // 每次检测前先重置
    deviceTimeoutTimer->start(timeoutMs);
}


QByteArray Widget::makeCommand(CommandType type)
{
    switch(type) {
    case CMD_HARDWARE_VER:
        return QByteArray::fromHex("08000000400000bf");
    case CMD_SOFTWARE_VER:
        return QByteArray::fromHex("08000000400100be");
    case CMD_FS_ADDR:
        return QByteArray::fromHex("08000000400200bd");
    case CMD_FS_MASK:
        return QByteArray::fromHex("08000000400300bc");
    case CMD_FS_SIZE:
        return QByteArray::fromHex("08000000400400bb");
    case CMD_RD_SETTINGS:
        return QByteArray::fromHex("08000000400a00b5");
    case CMD_DF_SETTINGS:
        return QByteArray::fromHex("08000000400c00b3");
    case CMD_VIDEO_START:
        return QByteArray::fromHex("0800000080ff0276");
    case CMD_VIDEO_STOP:
        return QByteArray::fromHex("0800000080000077");
    case CMD_PIC_ON:
        return QByteArray::fromHex("0800000080ff0177");
    case CMD_PIC_ERR_ON:
        return QByteArray::fromHex("0800000080ff0377");
    default:
        return QByteArray();
    }
}



quint32 getUint32FromData(const QByteArray &data, int offset)
{
    return static_cast<quint32>(static_cast<unsigned char>(data[offset])) |
           (static_cast<quint32>(static_cast<unsigned char>(data[offset + 1])) << 8) |
           (static_cast<quint32>(static_cast<unsigned char>(data[offset + 2])) << 16) |
           (static_cast<quint32>(static_cast<unsigned char>(data[offset + 3])) << 24);
}
uint8_t calcChecksum(const QByteArray& data, int len)
{
    if (len > data.size())
        len = data.size();

    uint8_t sum = 0;
    for (int i = 0; i < len; ++i)
    {
        sum += static_cast<uint8_t>(data[i]);
    }
    return static_cast<uint8_t>(~sum & 0xFF);
}

void Widget::updateSettingsUI(const config_Settings_t* cfg)
{
    QHostAddress ip(qToBigEndian(cfg->ipaddr_u32));
    ui->lineEdit_ip->setText(ip.toString());
    qDebug() << "IP:" << ip.toString();

    QHostAddress mask(qToBigEndian(cfg->mask_u32));
    ui->lineEdit_mask->setText(mask.toString());
    qDebug() << "Mask:" << mask.toString();

    QHostAddress gw(qToBigEndian(cfg->gw_u32));
    ui->lineEdit_gw->setText(gw.toString());
    qDebug() << "Gateway:" << gw.toString();

    QByteArray macArr(reinterpret_cast<const char*>(cfg->mac_address), 6);
    QString macStr;
    for (int i = 0; i < macArr.size(); i++) {
        macStr += QString("%1").arg(static_cast<quint8>(macArr[i]), 2, 16, QLatin1Char('0')).toUpper();
        if (i < macArr.size() - 1) macStr += ":";
    }
    ui->lineEdit_mac->setText(macStr);
    qDebug() << "MAC:" << macStr;
}

void Widget::board_cmd_handle(QByteArray data)
{
    // 1. 打印原始数据
    QString hexStr;
    for (int i = 0; i < data.size(); i++)
    {
        hexStr += QString("%1 ").arg(static_cast<unsigned char>(data[i]), 2, 16, QLatin1Char('0')).toUpper();
    }
    qDebug() << "Received board_cmd_data:" << hexStr;

    // 2. 最小长度检查
    if (data.size() < 8)  //
    {
        qWarning() << "数据包太短，丢弃";
        return;
    }

    // 3. 提取并校验长度
    quint16 pktLen = static_cast<quint8>(data[0]) | (static_cast<quint8>(data[1]) << 8);
    if (pktLen != data.size())
    {
        qWarning() << "长度不一致: pktLen=" << pktLen << " actual=" << data.size();
        return;
    }

    // 4. 校验和验证
    uint8_t calcSum = calcChecksum(data, data.size() - 1);
    uint8_t recvSum = static_cast<uint8_t>(data[data.size() - 1]);

    if (calcSum != recvSum)
    {
        qWarning() << QString("校验失败: 计算=0x%1 接收=0x%2")
                      .arg(calcSum, 2, 16, QLatin1Char('0'))
                      .arg(recvSum, 2, 16, QLatin1Char('0'));
        return;
    }
//    qDebug() << QString("校验通过: 校验值=0x%1").arg(calcSum, 2, 16, QLatin1Char('0'));

    // 5. 指令判断
    if (static_cast<unsigned char>(data[4]) == 0x40)
    {
        isDeviceConnected = true;
        if (deviceTimeoutTimer && deviceTimeoutTimer->isActive())
            deviceTimeoutTimer->stop();

        switch (static_cast<unsigned char>(data[5]))
        {
            case CMD_HARDWARE_VER:
            {
                quint32 val = getUint32FromData(data, 7);
                ui->label_had_e->setText(QString("0x%1").arg(val, 8, 16, QLatin1Char('0')));
                break;
            }
            case CMD_SOFTWARE_VER:
            {
                quint32 val = getUint32FromData(data, 7);
                ui->label_sof_e->setText(QString("0x%1").arg(val, 8, 16, QLatin1Char('0')));
                break;
            }

            case CMD_FS_ADDR:
            {
                quint32 val = getUint32FromData(data, 7);
                ui->label_f_wd_e->setText(QString("0x%1").arg(val, 8, 16, QLatin1Char('0')));
                break;
            }
            case CMD_FS_MASK:
            {

                int strLen = data.size() - 8;  // 扣掉前面7字节+1字节校验
                QByteArray strData = data.mid(7, strLen);
                QString resultStr = QString::fromLatin1(strData);
                ui->label_f_mk_e->setText(resultStr);
                break;
            }
            case CMD_FS_SIZE:
            {
                quint32 val = getUint32FromData(data, 7);
                QString sizeStr = QString::number(val) + " KB";
                ui->label_f_sz_e->setText(sizeStr);
                break;
            }



            case CMD_RD_SETTINGS:
            case CMD_DF_SETTINGS:
            {
                const config_Settings_t* cfg = reinterpret_cast<const config_Settings_t*>(data.constData() + 7);
                updateSettingsUI(cfg);
                break;
            }
            case CMD_SV_SETTINGS:
            {
                if (static_cast<unsigned char>(data[6]) == 0x00)
                {
                    QMessageBox::information(this, "提示", "操作成功！");
                }
                else
                {
                    QMessageBox::critical(this, "错误", "操作失败！");
                }
                break;
            }
            default:
                qWarning() << "未知命令:" << QString::number(data[5], 16);
                break;
        }
    }
    else if (static_cast<unsigned char>(data[4]) == 0x10)
    {
        if (data.size() < 14) {
              qWarning() << "Invalid read mem response size";
              return;
          }
          // 解析地址和值（小端）
          quint32 addr = qFromLittleEndian<quint32>(reinterpret_cast<const uchar*>(data.constData() + 5));
          quint32 val = qFromLittleEndian<quint32>(reinterpret_cast<const uchar*>(data.constData() + 9));

          qDebug() << "Memory Read Response: Addr =" << QString::number(addr,16)
                   << ", Value =" << QString::number(val,16);
          ui->lineEdit_MM_DATA->setText(QString("0x%1").arg(val, 8, 16, QLatin1Char('0')));

    }
    else if (static_cast<unsigned char>(data[4]) == 0x11)
    {
        if (data.size() < 14) {
            qWarning() << "Invalid write mem response size";
            return;
        }

        // 解析地址和值（小端）
        quint32 addr = qFromLittleEndian<quint32>(reinterpret_cast<const uchar*>(data.constData() + 5));
        quint32 val = qFromLittleEndian<quint32>(reinterpret_cast<const uchar*>(data.constData() + 9));

        // 获取用户在 lineEdit_MM_DATA 中输入的期望值
        QString dataStr = ui->lineEdit_MM_DATA->text().trimmed();
        bool ok = false;
        quint32 expectedVal = dataStr.startsWith("0x", Qt::CaseInsensitive) ? dataStr.toUInt(&ok, 16) : dataStr.toUInt(&ok, 16);

        if (!ok) {
            QMessageBox::warning(this, "Warning", "Invalid data value in memory write.");
            return;
        }

        // 比对写入值和返回值
        if (expectedVal == val) {
            QMessageBox::information(this, "Write Memory",
                                     QString("Write successful!\nAddress: 0x%1\nValue: 0x%2")
                                     .arg(addr, 8, 16, QLatin1Char('0'))
                                     .arg(val, 8, 16, QLatin1Char('0')));
        } else {
            QMessageBox::critical(this, "Warning",
                                  QString("Write verification failed!\nAddress: 0x%1\nExpected: 0x%2\nReturned: 0x%3")
                                  .arg(addr, 8, 16, QLatin1Char('0'))
                                  .arg(expectedVal, 8, 16, QLatin1Char('0'))
                                  .arg(val, 8, 16, QLatin1Char('0')));
        }

        qDebug() << "Memory Write Response: Addr =" << QString::number(addr,16)
                 << ", Value =" << QString::number(val,16);

    }
    else if (static_cast<unsigned char>(data[4]) == 0x20)
    {
        if (data.size() < 12)  // 至少要包含: 头(5) + 通道(1) + addr(1) + len(1) + reg_addr(2) + flag(1) + status(1)
        {
            qWarning() << "[IIC Read] 响应长度不足";
            return;
        }

        quint8 ch      = static_cast<quint8>(data[5]);
        quint8 devAddr = static_cast<quint8>(data[6]);
        quint8 len     = static_cast<quint8>(data[7]);
        quint16 regAddr = (static_cast<quint8>(data[8]) << 8) | static_cast<quint8>(data[9]);
        quint8 flag    = static_cast<quint8>(data[10]);
        quint8 status  = static_cast<quint8>(data[11]);

        if (data.size() < 12 + len)
        {
            qWarning() << "[IIC Read] 数据长度不足";
            return;
        }

        QByteArray readData = data.mid(12, len);  // 提取读取内容
        QStringList dataHexList;

        for (int i = 0; i < readData.size(); ++i)
        {
            dataHexList << QString("0x%1").arg(static_cast<quint8>(readData[i]), 2, 16, QLatin1Char('0'));
        }


        QString text;
        if (status == 0)
        {
            text = QString("<span style='color:green;'>[IIC Read] ch: %1, dev_addr: 0x%2, reg: 0x%3, len: %4 → data: [%5]</span>")
                       .arg(ch)
                       .arg(QString::number(devAddr, 16).rightJustified(2, '0').toUpper())
                       .arg(QString::number(regAddr, 16).rightJustified((flag == 1 ? 2 : 4), '0').toUpper())
                       .arg(len)
                       .arg(dataHexList.join(", "));
        }
        else
        {
            text = QString("<span style='color:red;'>[IIC Read] ch: %1, dev_addr: 0x%2, reg: 0x%3, len: %4 → read failed!</span>")
                       .arg(ch)
                       .arg(QString::number(devAddr, 16).rightJustified(2, '0').toUpper())
                       .arg(QString::number(regAddr, 16).rightJustified((flag == 1 ? 2 : 4), '0').toUpper())
                       .arg(len);
        }

        ui->textBrowser_iic_show->append(text);
    }
    else if (static_cast<unsigned char>(data[4]) == 0x21)
    {
        if (data.size() < 12)
        {
            qWarning() << "Invalid IIC write response size";
            return;
        }

        quint8 ch     = static_cast<quint8>(data[5]);
        quint8 addr   = static_cast<quint8>(data[6]);
        quint16 reg   = (static_cast<quint16>(data[7]) << 8) | static_cast<quint8>(data[8]);
        quint8 flag   = static_cast<quint8>(data[9]);
        quint8 status = static_cast<quint8>(data[10]);
        quint8 value  = static_cast<quint8>(data[11]);

        QString statusStr = (status == 0) ? "success" : "fail";
        QString color      = (status == 0) ? "#00C853" : "#FF4040";  // 绿色成功 / 红色失败

        QString html = QString("<span style='color:%1;'>[IIC Write] ch: %2, dev_addr: 0x%3, reg: 0x%4, data: 0x%5, status: %6</span>")
                       .arg(color)
                       .arg(ch)
                       .arg(addr, 2, 16, QLatin1Char('0'))
                       .arg(reg, (flag == 1 ? 2 : 4), 16, QLatin1Char('0'))
                       .arg(value, 2, 16, QLatin1Char('0'))
                       .arg(statusStr);

        ui->textBrowser_iic_show->append(html);
    }
    else if (static_cast<unsigned char>(data[4]) == 0x30)
    {

        if (static_cast<unsigned char>(data[5]) == 0x00)  // 假设你期望的是 0x00
        {
            qDebug() << "操作成功：已关闭设备。";
            QMessageBox::information(this, "设置", QString("操作成功：已关闭设备"));
        }
        else if (static_cast<unsigned char>(data[5]) == 0x01)  // 期望值是 0x01
        {
            qDebug() << "操作成功：已打开设备。";
            QMessageBox::information(this, "设置", QString("操作成功：已打开设备"));
        }
        else if (static_cast<unsigned char>(data[5]) == 0x02)  //
        {
            qDebug() << "0x02";
        }
        else if (static_cast<unsigned char>(data[5]) == 0x03)  //
        {
            qDebug() << "0x03";
        }
        else if (static_cast<unsigned char>(data[5]) == 0x04)  //
        {
            quint32 col = getUint32FromData(data, 7);
            quint32 line = getUint32FromData(data, 11);
            quint32 fps = getUint32FromData(data, 15);
//            qDebug() << col<< line<< fps;
            ui->label_cp_resolution->setText(QString("%1 x %2").arg(col).arg(line));
            ui->label_cp_fps->setText(QString::number(fps));

        }
        else if (static_cast<unsigned char>(data[5]) == 0x05)  //
        {
            quint32 col = getUint32FromData(data, 7);
            quint32 line = getUint32FromData(data, 11);
            quint32 fps = getUint32FromData(data, 15);
            quint32 status = getUint32FromData(data, 19);
            quint32 fps_total_cnt = getUint32FromData(data, 23);
            quint32 pixel_point = getUint32FromData(data, 27);
            quint32 stream_in_data = getUint32FromData(data, 31);
            quint32 error_data_hold = getUint32FromData(data, 35);
            quint32 stream_in_data_hold = getUint32FromData(data, 39);
            quint32 pixel_threshold = getUint32FromData(data, 43);

            QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
            QString info;
            info += QString("==== %1 ====\n").arg(timestamp);
            info += QString("分辨率: %1 x %2\n").arg(col).arg(line);
            info += QString("帧率: %1 fps\n").arg(fps);
            info += QString("状态码: %1\n").arg(QString::number(status, 16).toUpper());
            info += QString("帧总数: %1\n").arg(fps_total_cnt);
            info += QString("对比像素点: %1\n").arg(QString::number(pixel_point, 16).toUpper());
            info += QString("当前帧输入像素点: %1\n").arg(QString::number(stream_in_data, 16).toUpper());
            info += QString("错误帧像素点: %1\n").arg(QString::number(error_data_hold, 16).toUpper());
            info += QString("输入帧像素点: %1\n").arg(QString::number(stream_in_data_hold, 16).toUpper());
            info += QString("像素阈值: %1\n").arg(QString::number(pixel_threshold, 16).toUpper());
            info += "\n";

            ui->textBrowser_cp->append(info);  // 使用 append 可以持续追加

        }
        else
        {
            // 数据不一致，提示操作失败
            qDebug() << "未知命令码。";
        }
    }
    else
    {
        qWarning() << "未识别的标志字节:" << QString("0x%1").arg(static_cast<unsigned char>(data[4]), 2, 16, QLatin1Char('0'));
    }
}

void Widget::soft_cmd_handle(QByteArray data)
{
//    QString hexStr;
//    for (int i = 0; i < data.size(); i++)
//    {
//        hexStr += QString("%1 ").arg(static_cast<unsigned char>(data[i]), 2, 16, QLatin1Char('0')).toUpper();
//    }
//    qDebug() << "Received soft_cmd_data:" << hexStr;


   quint16 cmd_len     = static_cast<quint8>(data[4]) | (static_cast<quint8>(data[5]) << 8);
   quint8 message_cmd = static_cast<quint8>(data[8]);
   quint8 channel_cmd = static_cast<quint8>(data[9]);
   quint8 control_cmd = static_cast<quint8>(data[10]);

//   qDebug() << "cmd_len" << cmd_len
//                << "message_cmd" << message_cmd
//                << "channel_cmd" << channel_cmd
//                << "control_cmd" << control_cmd;

   if (cmd_len != data.size()-4)
   {
       qWarning() << "Length mismatch, ignore packet";
       return;
   }

   //
   if (message_cmd == 0x10)
   {
       if (channel_cmd == 0x01)
       {
           if (control_cmd == 0x01)
           {
               qDebug() << "xxxxx";
               on_btn_pic_clicked();
           }
       }
   }
   //
   else if (message_cmd == 0x20)
   {
       if (channel_cmd == 0x00)
       {
           if (control_cmd == 0x00)
           {
               qDebug() << "hide";
               this->hide();
           }
           else if (control_cmd == 0x01)
           {
               qDebug() << "show";
               this->show();
           }
           else if (control_cmd == 0x02)
           {
               qDebug() << "quit";
               QApplication::quit();
           }
       }
   }
   // ===== message_cmd == "30" =====
   else if (message_cmd == 0x30)
   {
       // 从第7字节开始解析 UTF-8 文件名
       QByteArray filenameBytes = data.mid(11);
       QString filename = QString::fromUtf8(filenameBytes).trimmed();
       qDebug() << "Saving image to:" << filename;

       if (filename.isEmpty())
       {
           qWarning() << "Empty filename";
           return;
       }

       QFileInfo fileInfo(filename);
       QString folder = fileInfo.absolutePath();
       if (!folder.isEmpty() && !QDir(folder).exists())
       {
           QDir().mkpath(folder);
       }


       // 从共享内存获取图像并保存
//            假设 handlethread 有方法读取图像
       QImage img;
       if (!handlethread->readImageFromSharedMemory(img,1))
       {
           qWarning() << "Failed to read image from shared memory";
           return;
       }
       if (img.isNull())
       {
           qWarning() << "Image is null";
           return;
       }
       if (img.save(filename))
       {
           qDebug() << "Image successfully saved to" << filename;
       }
       else
       {
           qWarning() << "Failed to save image";
       }
   }
   else if (message_cmd == 0x40)
   {
       if (data.size() < 17)
       {
           qWarning() << "Invalid 0x40 packet: too short";
           return;
       }

       quint8 ip1 = static_cast<quint8>(data[11]);
       quint8 ip2 = static_cast<quint8>(data[12]);
       quint8 ip3 = static_cast<quint8>(data[13]);
       quint8 ip4 = static_cast<quint8>(data[14]);
       QString board_ip = QString("%1.%2.%3.%4").arg(ip1).arg(ip2).arg(ip3).arg(ip4);

       quint16 board_port = (static_cast<quint8>(data[15]) << 8) |
                            static_cast<quint8>(data[16]);

       qDebug() << "Received board info -> IP:" << board_ip << "Port:" << board_port;

       udp_recvthread->sendCommandToHost(board_ip, board_port, makeCommand(CMD_PIC_ON));
   }

}


void Widget::on_btn_video_on_clicked()
{
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_VIDEO_START));
}

void Widget::on_btn_video_off_clicked()
{
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_VIDEO_STOP));

}

void Widget::on_btn_pic_clicked()
{
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_PIC_ON));
}


void Widget::on_btn_rd_S_clicked()
{
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_RD_SETTINGS));
}

void Widget::on_btn_SV_S_clicked()
{

    QByteArray sendBuf;

    // 1. 头部7字节
    QByteArray header;
    header.append(char(0x00));  // 长度低字节占位
    header.append(char(0x00));  // 长度高字节占位
    header.append(char(0x00));  // 固定
    header.append(char(0x00));  // 固定
    header.append(char(0x40));  // 固定
    header.append(char(0x0b));  // 命令字
    header.append(char(0x00));  // 保留

    // 2. 填充config结构体
    config_Settings_t cfg;
    QString ipStr = ui->lineEdit_ip->text();
    QHostAddress ipAddr(ipStr);
    cfg.ipaddr_u32 = qToBigEndian(ipAddr.toIPv4Address());

    QString maskStr = ui->lineEdit_mask->text();
    QHostAddress maskAddr(maskStr);
    cfg.mask_u32 = qToBigEndian(maskAddr.toIPv4Address());

    QString gwStr = ui->lineEdit_gw->text();
    QHostAddress gwAddr(gwStr);
    cfg.gw_u32 = qToBigEndian(gwAddr.toIPv4Address());

    QString macStr = ui->lineEdit_mac->text();
    QStringList macParts = macStr.split(":");
    memset(cfg.mac_address, 0, sizeof(cfg.mac_address));
    for (int i = 0; i < macParts.size() && i < 6; ++i)
    {
        bool ok = false;
        quint8 val = static_cast<quint8>(macParts[i].toUInt(&ok, 16));
        if (ok)
            cfg.mac_address[i] = val;
    }

    QByteArray configData(reinterpret_cast<const char*>(&cfg), sizeof(config_Settings_t));

    // 3. 拼接包体
    sendBuf.append(header);
    sendBuf.append(configData);

    // 4. 计算总长度 = 2字节长度 + 剩余内容 + 1字节校验
    quint16 totalLen = sendBuf.size() + 1;

    // 长度字段
    sendBuf[0] = static_cast<char>(totalLen & 0xFF);
    sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

    // 5. 计算校验，校验范围包括长度字段开始到最后一字节数据
    uint8_t checksum = calcChecksum(sendBuf, sendBuf.size());
    sendBuf.append(static_cast<char>(checksum));

    // 6. 发送
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);

    qDebug() << "Send cmd" << 0x0b
             << "len:" << totalLen
             << "data:" << sendBuf.toHex(' ').toUpper();

}

void Widget::on_btn_rd_D_clicked()
{
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, makeCommand(CMD_DF_SETTINGS));
}

void Widget::on_lineEdit_MM_ADDR_editingFinished()
{
    QString text = ui->lineEdit_MM_ADDR->text().trimmed();

    if (text == "0x")
    {
        // 如果是空输入，直接退出，不提示
        return;
    }

    bool ok = false;
    quint32 val = text.startsWith("0x", Qt::CaseInsensitive) ? text.toUInt(&ok, 16) : text.toUInt(&ok, 16);

    if (ok)
    {
        // 格式化为 0x 前缀、8位十六进制显示
        QString formatted = QString("0x%1").arg(val, 8, 16, QLatin1Char('0'));
        ui->lineEdit_MM_ADDR->setText(formatted);
    }
    else
    {
        QMessageBox::warning(this, "提示", "请输入有效的十六进制数！");
        ui->lineEdit_MM_ADDR->setText("0x");
    }
}


void Widget::on_lineEdit_MM_DATA_editingFinished()
{
    QString text = ui->lineEdit_MM_DATA->text().trimmed();

    if (text == "0x")
    {
        // 如果是空输入，直接退出，不提示
        return;
    }

    bool ok = false;
    quint32 val = text.startsWith("0x", Qt::CaseInsensitive) ? text.toUInt(&ok, 16) : text.toUInt(&ok, 16);

    if (ok)
    {
        // 格式化为 0x 前缀、8位十六进制显示
        QString formatted = QString("0x%1").arg(val, 8, 16, QLatin1Char('0'));
        ui->lineEdit_MM_DATA->setText(formatted);
    }
    else
    {
        QMessageBox::warning(this, "提示", "请输入有效的十六进制数！");
        ui->lineEdit_MM_DATA->setText("0x");
    }
}

void Widget::on_btn_MM_rd_clicked()
{
    QByteArray sendBuf;

    // 1. Header: 长度占位 + 固定4字节 + CMD + 保留
    QByteArray header;
    header.append(static_cast<char>(0x00));  // Length low
    header.append(static_cast<char>(0x00));  // Length high
    header.append(static_cast<char>(0x00));  // Reserved
    header.append(static_cast<char>(0x00));  // Reserved
    header.append(static_cast<char>(0x10));  // CMD: Read Memory 0x10

    // 2. Get address from lineEdit_MM_ADDR
    QString addrStr = ui->lineEdit_MM_ADDR->text().trimmed();
    if (addrStr.isEmpty() || addrStr == "0x")
    {
        QMessageBox::warning(this, "Warning", "Please enter memory address.");
        return;
    }

    bool ok = false;
    quint32 addrVal = addrStr.startsWith("0x", Qt::CaseInsensitive) ? addrStr.toUInt(&ok, 16)
                                                                    : addrStr.toUInt(&ok, 16);
    if (!ok)
    {
        QMessageBox::warning(this, "Warning", "Invalid memory address.");
        return;
    }

    quint32 addrLE = qToLittleEndian(addrVal);
    QByteArray addrBytes(reinterpret_cast<const char*>(&addrLE), sizeof(addrLE));

    // 3. 拼接
    sendBuf.append(header);
    sendBuf.append(addrBytes);

    // 4. 长度
    quint16 totalLen = sendBuf.size() + 1;
    sendBuf[0] = static_cast<char>(totalLen & 0xFF);
    sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

    // 5. 校验
    uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
    sendBuf.append(static_cast<char>(sum));

    // 6. 发送
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);

    qDebug() << "Send CMD 0x10, len:" << totalLen << "data:" << sendBuf.toHex(' ').toUpper();
}


void Widget::on_btn_MM_wr_clicked()
{
    QByteArray sendBuf;

    // 1. Header: Length placeholder + Reserved + CMD + Reserved
    QByteArray header;
    header.append(static_cast<char>(0x00));  // Length low
    header.append(static_cast<char>(0x00));  // Length high
    header.append(static_cast<char>(0x00));  // Reserved
    header.append(static_cast<char>(0x00));  // Reserved
    header.append(static_cast<char>(0x11));  // CMD: Write Memory 0x11

    // 2. Get memory address
    QString addrStr = ui->lineEdit_MM_ADDR->text().trimmed();
    if (addrStr.isEmpty() || addrStr == "0x")
    {
        QMessageBox::warning(this, "Warning", "Please enter memory address.");
        return;
    }

    bool okAddr = false;
    quint32 addrVal = addrStr.startsWith("0x", Qt::CaseInsensitive) ? addrStr.toUInt(&okAddr, 16)
                                                                    : addrStr.toUInt(&okAddr, 16);
    if (!okAddr)
    {
        QMessageBox::warning(this, "Warning", "Invalid memory address.");
        return;
    }

    quint32 addrLE = qToLittleEndian(addrVal);
    QByteArray addrBytes(reinterpret_cast<const char*>(&addrLE), sizeof(addrLE));

    // 3. Get memory value to write
    QString valueStr = ui->lineEdit_MM_DATA->text().trimmed();
    if (valueStr.isEmpty() || valueStr == "0x")
    {
        QMessageBox::warning(this, "Warning", "Please enter memory value.");
        return;
    }

    bool okVal = false;
    quint32 value = valueStr.startsWith("0x", Qt::CaseInsensitive) ? valueStr.toUInt(&okVal, 16)
                                                                   : valueStr.toUInt(&okVal, 16);
    if (!okVal)
    {
        QMessageBox::warning(this, "Warning", "Invalid memory value.");
        return;
    }

    quint32 valueLE = qToLittleEndian(value);
    QByteArray valueBytes(reinterpret_cast<const char*>(&valueLE), sizeof(valueLE));

    // 4. 拼接
    sendBuf.append(header);
    sendBuf.append(addrBytes);
    sendBuf.append(valueBytes);

    // 5. Length (data + checksum, no fixed value)
    quint16 totalLen = sendBuf.size() + 1;
    sendBuf[0] = static_cast<char>(totalLen & 0xFF);
    sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

    // 6. Checksum
    uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
    sendBuf.append(static_cast<char>(sum));

    // 7. Send
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);

    qDebug() << "Send CMD 0x11, len:" << totalLen << "data:" << sendBuf.toHex(' ').toUpper();
}

void Widget::on_comboBox_reg_num_activated(const QString &arg1)
{
    QString text = ui->lineEdit_reg_addr->text().trimmed();

    if (text.isEmpty() || text == "0x") {
        return;
    }

    // 去除前缀处理
    if (text.startsWith("0x", Qt::CaseInsensitive)) {
        text = text.mid(2);
    }

    bool ok = false;
    quint16 val = text.toUInt(&ok, 16);
    if (!ok) {
        QMessageBox::warning(this, "提示", "无效的寄存器地址！");
        return;
    }

    int regWidth = arg1.toInt();  // 从当前 comboBox 文本中获取寄存器宽度（应为 1 或 2）

    QString formatted = QString("0x%1")
                            .arg(val, regWidth == 1 ? 2 : 4, 16, QLatin1Char('0'));

    ui->lineEdit_reg_addr->setText(formatted);
}


void Widget::on_btn_iic_write_clicked()
{
    // 1. 获取 UI 参数
    int channel = ui->comboBox_iic_channel->currentText().toInt();
    QString devAddrStr = ui->lineEdit_slave_addr->text().trimmed();
    bool ok = false;
    quint8 devAddr = devAddrStr.toUInt(&ok, 16);
    if (!ok) {
        QMessageBox::warning(this, "提示", "无效的从机地址！");
        return;
    }

    QString regAddrStr = ui->lineEdit_reg_addr->text().trimmed();
    quint16 regAddr = regAddrStr.toUInt(&ok, 16);
    if (!ok) {
        QMessageBox::warning(this, "提示", "无效的寄存器地址！");
        return;
    }

    int regWidth = ui->comboBox_reg_num->currentText().toInt();
    quint8 addrFlag = (regWidth == 1) ? 1 : 0;

    QString dataStr = ui->lineEdit_iic_write_data->text().trimmed();
    QStringList dataList = dataStr.split(QRegularExpression("[,\\s]+"));
    dataList.removeAll("");  // 等效于 SkipEmptyParts

    if (dataList.isEmpty()) {
        QMessageBox::warning(this, "提示", "请输入至少一个写入数据！");
        return;
    }

    for (int i = 0; i < dataList.size(); ++i)
    {
        QByteArray sendBuf;
        quint8 dataVal = dataList[i].toUInt(&ok, 16);
        if (!ok) {
            QMessageBox::warning(this, "提示", QString("第%1个数据无效！").arg(i + 1));
            return;
        }

        // Header: 长度 + 保留 + CMD(0x21) + 保留
        sendBuf.append(static_cast<char>(0x00));  // 长度低字节
        sendBuf.append(static_cast<char>(0x00));  // 长度高字节
        sendBuf.append(static_cast<char>(0x00));  // 保留
        sendBuf.append(static_cast<char>(0x00));  // 保留
        sendBuf.append(static_cast<char>(0x21));  // CMD

        // 参数
        sendBuf.append(static_cast<char>(channel & 0xFF));
        sendBuf.append(static_cast<char>(devAddr));

        // 地址：根据字节宽度添加
        if (addrFlag == 1)
        {
            sendBuf.append(static_cast<char>(regAddr & 0xFF));
        }
        else
        {
            sendBuf.append(static_cast<char>((regAddr >> 8) & 0xFF));
            sendBuf.append(static_cast<char>(regAddr & 0xFF));
        }

        sendBuf.append(static_cast<char>(addrFlag));  // 地址宽度标志
        sendBuf.append(static_cast<char>(0x00));      // 保留位
        sendBuf.append(static_cast<char>(dataVal));   // 数据

        // 填写长度
        quint16 totalLen = sendBuf.size() + 1;
        sendBuf[0] = static_cast<char>(totalLen & 0xFF);
        sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

        // 校验
        uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
        sendBuf.append(static_cast<char>(sum));

        // 发送
        udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);

        // 显示
        qDebug() << QString("[IIC Write] ch:%1, dev_addr:0x%2, reg:0x%3, data:0x%4")
                    .arg(channel)
                    .arg(devAddr, 2, 16, QLatin1Char('0'))
                    .arg(regAddr, (addrFlag == 1 ? 2 : 4), 16, QLatin1Char('0'))
                    .arg(dataVal, 2, 16, QLatin1Char('0'))
                 << "len:" << totalLen << " data:" << sendBuf.toHex(' ').toUpper();

        regAddr += 1;  // 自动递增地址
    }
}


void Widget::on_btn_iic_read_clicked()
{
    QByteArray sendBuf;

    // 1. Header: 2 字节长度 + 4 字节保留 + CMD (0x20)
    sendBuf.append(static_cast<char>(0x00));  // Length low
    sendBuf.append(static_cast<char>(0x00));  // Length high
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x20));  // CMD: Read I2C Reg

    // 2. 通道号
    int channel = ui->comboBox_iic_channel->currentText().toInt();
    sendBuf.append(static_cast<char>(channel & 0xFF));

    // 3. 从机地址
    QString devAddrStr = ui->lineEdit_slave_addr->text().trimmed();
    bool ok = false;
    quint8 devAddr = devAddrStr.toUInt(&ok, 16);
    if (!ok) {
        QMessageBox::warning(this, "提示", "无效的从机地址！");
        return;
    }
    sendBuf.append(static_cast<char>(devAddr));

    // 4. 读取长度
    QString readLenStr = ui->lineEdit_read_byte_num->text().trimmed();
    quint8 readLen = readLenStr.toUInt(&ok, 10);
    if (!ok || readLen == 0 || readLen > 64) {
        QMessageBox::warning(this, "提示", "无效的读取长度（1~64）！");
        return;
    }
    sendBuf.append(static_cast<char>(readLen));

    // 5. 寄存器地址
    QString regAddrStr = ui->lineEdit_reg_addr->text().trimmed();
    quint16 regAddr = regAddrStr.toUInt(&ok, 16);
    if (!ok) {
        QMessageBox::warning(this, "提示", "无效的寄存器地址！");
        return;
    }

    // 6. 地址宽度标志
    int regWidth = ui->comboBox_reg_num->currentText().toInt(); // 1 or 2
    quint8 addrFlag = (regWidth == 1) ? 1 : 0;

    if (addrFlag == 1) {
        sendBuf.append(static_cast<char>(0x00));                // High byte padding
        sendBuf.append(static_cast<char>(regAddr & 0xFF));      // Low byte
    } else {
        sendBuf.append(static_cast<char>((regAddr >> 8) & 0xFF));
        sendBuf.append(static_cast<char>(regAddr & 0xFF));
    }

    sendBuf.append(static_cast<char>(addrFlag));  // 8位 or 16位标志

    // 7. 填写长度
    quint16 totalLen = sendBuf.size() + 1;  // 包含校验位
    sendBuf[0] = static_cast<char>(totalLen & 0xFF);
    sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

    // 8. 校验
    uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
    sendBuf.append(static_cast<char>(sum));

    // 9. 打印日志
    qDebug() << "[IIC Read] ch:" << channel
             << ", dev_addr: 0x" << QString::number(devAddr, 16).rightJustified(2, '0').toUpper()
             << ", reg: 0x" << QString::number(regAddr, 16).rightJustified(4, '0').toUpper()
             << ", len:" << readLen
             << ", addr_width:" << (addrFlag == 1 ? "8-bit" : "16-bit");

    // 10. 发送
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);

    qDebug() << "[IIC Read] Send CMD 0x20, len:" << totalLen
             << "data:" << sendBuf.toHex(' ').toUpper();
}

void Widget::on_btn_cp_off_clicked()
{
    QByteArray sendBuf;

    // 1. Header: 2 字节长度 + 4 字节保留 + CMD (0x20)
    sendBuf.append(static_cast<char>(0x00));  // Length low
    sendBuf.append(static_cast<char>(0x00));  // Length high
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x30));  //
    sendBuf.append(static_cast<char>(0x00));  //
    sendBuf.append(static_cast<char>(0x00));  //

    // 7. 填写长度
    quint16 totalLen = sendBuf.size() + 1;  // 包含校验位
    sendBuf[0] = static_cast<char>(totalLen & 0xFF);
    sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

    uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
    sendBuf.append(static_cast<char>(sum));
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);
}

void Widget::on_btn_cp_on_clicked()
{
    QByteArray sendBuf;

    // 1. Header: 2 字节长度 + 4 字节保留 + CMD (0x20)
    sendBuf.append(static_cast<char>(0x00));  // Length low
    sendBuf.append(static_cast<char>(0x00));  // Length high
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x30));  //
    sendBuf.append(static_cast<char>(0x01));  //
    sendBuf.append(static_cast<char>(0x00));  //

    // 7. 填写长度
    quint16 totalLen = sendBuf.size() + 1;  // 包含校验位
    sendBuf[0] = static_cast<char>(totalLen & 0xFF);
    sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

    uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
    sendBuf.append(static_cast<char>(sum));
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);
}



void Widget::on_btn_set_pixel_clicked()
{
    QByteArray sendBuf;

    // 1. Header: 2 字节长度 + 4 字节保留 + CMD (0x20)
    sendBuf.append(static_cast<char>(0x00));  // Length low
    sendBuf.append(static_cast<char>(0x00));  // Length high
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x30));  //
    sendBuf.append(static_cast<char>(0x02));  //
    sendBuf.append(static_cast<char>(0x00));  //


    // 2. Get address from lineEdit_MM_ADDR
    QString pixel = ui->lineEdit_set_pixel->text().trimmed();
    if (pixel.isEmpty() || pixel == "0x")
    {
        QMessageBox::warning(this, "Warning", "Please enter a valid 3-byte(RGB).");
        return;
    }

    // 3. 检查输入的地址是否为 6 字节（12 个十六进制字符）
    if (!pixel.startsWith("0x", Qt::CaseInsensitive) || pixel.length() != 8)  // "0x" + 12 hex digits
    {
       QMessageBox::warning(this, "Warning", "Please enter a valid 3-byte(RGB).");
       return;
    }

    bool ok = false;
    quint32 pixelVal = pixel.startsWith("0x", Qt::CaseInsensitive) ? pixel.toUInt(&ok, 16)
                                                                    : pixel.toUInt(&ok, 16);
    if (!ok)
    {
        QMessageBox::warning(this, "Warning", "Invalid data.");
        return;
    }

    quint32 pixelLE = qToLittleEndian(pixelVal);
    QByteArray pixelBytes(reinterpret_cast<const char*>(&pixelLE), sizeof(pixelLE));

    // 3. 拼接
    sendBuf.append(pixelBytes);



    // 7. 填写长度
    quint16 totalLen = sendBuf.size() + 1;  // 包含校验位
    sendBuf[0] = static_cast<char>(totalLen & 0xFF);
    sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

    uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
    sendBuf.append(static_cast<char>(sum));
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);
}

void Widget::on_btn_set_threshold_clicked()
{
    QByteArray sendBuf;

    // 1. Header: 2 字节长度 + 4 字节保留 + CMD (0x20)
    sendBuf.append(static_cast<char>(0x00));  // Length low
    sendBuf.append(static_cast<char>(0x00));  // Length high
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x30));  //
    sendBuf.append(static_cast<char>(0x03));  //
    sendBuf.append(static_cast<char>(0x00));  //

    QString threshold = ui->lineEdit_set_threshold->text().trimmed();
    if (threshold.isEmpty() || threshold == "0x")
    {
        QMessageBox::warning(this, "Warning", "Please enter a valid 1 byte(threshold).");
        return;
    }


    if (!threshold.startsWith("0x", Qt::CaseInsensitive) || threshold.length() < 3 || threshold.length() > 4)
    {
        QMessageBox::warning(this, "Warning", "Please enter a valid 1 byte hex value like 0x2F.");
        return;
    }

    bool ok = false;
    quint32 thresholdVal = threshold.toUInt(&ok, 16);
    if (!ok || thresholdVal > 0xFF)
    {
        QMessageBox::warning(this, "Warning", "Invalid threshold value. Must be 1 byte (0x00 - 0xFF).");
        return;
    }

    // 3. 只拼接1字节
    sendBuf.append(static_cast<char>(thresholdVal & 0xFF));

    // 7. 填写长度
    quint16 totalLen = sendBuf.size() + 1;  // 包含校验位
    sendBuf[0] = static_cast<char>(totalLen & 0xFF);
    sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

    uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
    sendBuf.append(static_cast<char>(sum));
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);
}


void Widget::on_btn_list_add_clicked()
{
    int row = ui->tableWidget->rowCount();
    ui->tableWidget->insertRow(row);

    // 选择复选框（第 0 列）
    QCheckBox *checkBox = new QCheckBox();
    checkBox->setChecked(true);
    QWidget *checkBoxWidget = new QWidget();
    QHBoxLayout *checkBoxLayout = new QHBoxLayout(checkBoxWidget);
    checkBoxLayout->addWidget(checkBox);
    checkBoxLayout->setAlignment(Qt::AlignCenter);
    checkBoxLayout->setContentsMargins(0, 0, 0, 0);
    ui->tableWidget->setCellWidget(row, 0, checkBoxWidget);

    // 操作类型下拉框（第 1 列）
    QComboBox *combo = new QComboBox();
    combo->addItems(QStringList() << "读" << "写");
    combo->setCurrentText("写");
    combo->setToolTip("选择操作类型");
    QWidget *comboWidget = new QWidget();
    QHBoxLayout *comboLayout = new QHBoxLayout(comboWidget);
    comboLayout->addWidget(combo);
    comboLayout->setContentsMargins(0, 0, 0, 0);
    comboLayout->setAlignment(Qt::AlignCenter);
    ui->tableWidget->setCellWidget(row, 1, comboWidget);

    // 从机地址输入（第 2 列）
    QString defaultAddr = ui->lineEdit_slave_addr->text().trimmed().toUpper();
    if (defaultAddr.startsWith("0X"))
    {
        defaultAddr = defaultAddr.mid(2); // 去掉 "0X"
    }
    if (defaultAddr.isEmpty())
    {
        defaultAddr = "50";
    }
    else if (defaultAddr.length() > 2)
    {
        defaultAddr = defaultAddr.right(2);
    }
    QLineEdit *addrEdit = new QLineEdit(defaultAddr);
    addrEdit->setInputMask("HH");
    addrEdit->setAlignment(Qt::AlignRight);
    QWidget *addrWidget = new QWidget();
    QHBoxLayout *addrLayout = new QHBoxLayout(addrWidget);
    addrLayout->addWidget(addrEdit);
    addrLayout->setContentsMargins(0, 0, 0, 0);
    addrLayout->setAlignment(Qt::AlignCenter);
    ui->tableWidget->setCellWidget(row, 2, addrWidget);

    // 寄存器地址输入（第 3 列）
    QLineEdit *regEdit = new QLineEdit("0000");
    regEdit->setInputMask("HHHH");
    regEdit->setAlignment(Qt::AlignRight);
    QWidget *regWidget = new QWidget();
    QHBoxLayout *regLayout = new QHBoxLayout(regWidget);
    regLayout->addWidget(regEdit);
    regLayout->setContentsMargins(0, 0, 0, 0);
    regLayout->setAlignment(Qt::AlignCenter);
    ui->tableWidget->setCellWidget(row, 3, regWidget);

    // 写入数据输入（第 4 列）
    QLineEdit *dataEdit = new QLineEdit("00");
    dataEdit->setInputMask("HH");
    dataEdit->setAlignment(Qt::AlignRight);
    QWidget *dataWidget = new QWidget();
    QHBoxLayout *dataLayout = new QHBoxLayout(dataWidget);
    dataLayout->addWidget(dataEdit);
    dataLayout->setContentsMargins(0, 0, 0, 0);
    dataLayout->setAlignment(Qt::AlignCenter);
    ui->tableWidget->setCellWidget(row, 4, dataWidget);

    // 读数据字节数（第 5 列）
    QSpinBox *byteSpin = new QSpinBox();
    byteSpin->setRange(1, 256);
    byteSpin->setValue(1);
    byteSpin->setAlignment(Qt::AlignRight);
    QWidget *byteWidget = new QWidget();
    QHBoxLayout *byteLayout = new QHBoxLayout(byteWidget);
    byteLayout->addWidget(byteSpin);
    byteLayout->setContentsMargins(0, 0, 0, 0);
    byteLayout->setAlignment(Qt::AlignCenter);
    ui->tableWidget->setCellWidget(row, 5, byteWidget);

    // 延时设置（第 6 列）
    QSpinBox *delaySpin = new QSpinBox();
    delaySpin->setRange(0, 10000);
    delaySpin->setValue(10);
    delaySpin->setAlignment(Qt::AlignRight);
    QWidget *delayWidget = new QWidget();
    QHBoxLayout *delayLayout = new QHBoxLayout(delayWidget);
    delayLayout->addWidget(delaySpin);
    delayLayout->setContentsMargins(0, 0, 0, 0);
    delayLayout->setAlignment(Qt::AlignCenter);
    ui->tableWidget->setCellWidget(row, 6, delayWidget);
}


void Widget::on_btn_list_delete_clicked()
{

    for (int row = ui->tableWidget->rowCount() - 1; row >= 0; --row)
    {
        QWidget *checkBoxWidget = ui->tableWidget->cellWidget(row, 0);
        if (!checkBoxWidget)
            continue;

        QCheckBox *checkBox = checkBoxWidget->findChild<QCheckBox *>();
        if (checkBox && checkBox->isChecked())
        {
            ui->tableWidget->removeRow(row);
        }
    }

}


void Widget::on_btn_list_run_clicked()
{
    int channel = ui->comboBox_iic_channel->currentText().toInt();
    qDebug() << QString("开始执行列表操作，共 %1 行").arg(ui->tableWidget->rowCount());

    for (int row = 0; row < ui->tableWidget->rowCount(); ++row)
    {
        // 获取 checkbox，判断是否勾选
        QCheckBox *checkBox = ui->tableWidget->cellWidget(row, 0) ?
                              ui->tableWidget->cellWidget(row, 0)->findChild<QCheckBox*>() : nullptr;
        if (!checkBox) {
            QMessageBox::warning(this, "错误", QString("第 %1 行复选框控件不存在").arg(row + 1));
            continue;
        }
        if (!checkBox->isChecked()) continue;

        // 获取操作类型（读/写）
        QComboBox *opCombo = ui->tableWidget->cellWidget(row, 1) ?
                             ui->tableWidget->cellWidget(row, 1)->findChild<QComboBox*>() : nullptr;
        if (!opCombo) {
            QMessageBox::warning(this, "错误", QString("第 %1 行操作类型控件不存在").arg(row + 1));
            continue;
        }
        QString op = opCombo->currentText();

        // 获取从机地址
        QLineEdit *addrEdit = ui->tableWidget->cellWidget(row, 2) ?
                              ui->tableWidget->cellWidget(row, 2)->findChild<QLineEdit*>() : nullptr;
        if (!addrEdit) {
            QMessageBox::warning(this, "错误", QString("第 %1 行从机地址控件不存在").arg(row + 1));
            continue;
        }
        bool ok = false;
        quint8 devAddr = addrEdit->text().trimmed().toUInt(&ok, 16);
        if (!ok) {
            QMessageBox::warning(this, "错误", QString("第 %1 行从机地址无效：%2").arg(row + 1).arg(addrEdit->text()));
            continue;
        }

        // 获取寄存器地址
        QLineEdit *regEdit = ui->tableWidget->cellWidget(row, 3) ?
                             ui->tableWidget->cellWidget(row, 3)->findChild<QLineEdit*>() : nullptr;
        if (!regEdit) {
            QMessageBox::warning(this, "错误", QString("第 %1 行寄存器地址控件不存在").arg(row + 1));
            continue;
        }
        quint16 regAddr = regEdit->text().trimmed().toUShort(&ok, 16);
        if (!ok) {
            QMessageBox::warning(this, "错误", QString("第 %1 行寄存器地址无效：%2").arg(row + 1).arg(regEdit->text()));
            continue;
        }

        // 获取写数据或读取字节数
        quint8 writeValue = 0;
        int byteCount = 1;

        if (op == "写") {
            QLineEdit *dataEdit = ui->tableWidget->cellWidget(row, 4) ?
                                  ui->tableWidget->cellWidget(row, 4)->findChild<QLineEdit*>() : nullptr;
            if (!dataEdit) {
                QMessageBox::warning(this, "错误", QString("第 %1 行写数据控件不存在").arg(row + 1));
                continue;
            }
            writeValue = dataEdit->text().trimmed().toUInt(&ok, 16);
            if (!ok) {
                QMessageBox::warning(this, "错误", QString("第 %1 行写数据格式无效：%2").arg(row + 1).arg(dataEdit->text()));
                continue;
            }
        } else if (op == "读") {
            // 尝试获取 SpinBox，如果是 QLineEdit 格式就修改此段
            QSpinBox *byteSpin = ui->tableWidget->cellWidget(row, 5) ?
                                 ui->tableWidget->cellWidget(row, 5)->findChild<QSpinBox*>() : nullptr;
            if (!byteSpin) {
                QMessageBox::warning(this, "错误", QString("第 %1 行读数据字节数控件不存在").arg(row + 1));
                continue;
            }
            byteCount = byteSpin->value();
        }

        // 获取延时
        QSpinBox *delaySpin = ui->tableWidget->cellWidget(row, 6) ?
                              ui->tableWidget->cellWidget(row, 6)->findChild<QSpinBox*>() : nullptr;
        int delayMs = 0;
        if (!delaySpin) {
            QMessageBox::warning(this, "错误", QString("第 %1 行延时控件不存在").arg(row + 1));
            continue;
        }
        delayMs = delaySpin->value();

        // 打印调试信息
        qDebug() << QString("第 %1 行: channel=%2, op=%3, addr=0x%4, reg=0x%5, value=0x%6, bytes=%7, delay=%8ms")
                    .arg(row + 1).arg(channel).arg(op)
                    .arg(devAddr, 2, 16, QChar('0'))
                    .arg(regAddr, 4, 16, QChar('0'))
                    .arg(writeValue, 2, 16, QChar('0'))
                    .arg(byteCount).arg(delayMs);

        // 组装数据包
        QByteArray sendBuf;
        if (op == "写") {
            sendBuf.append(static_cast<char>(0x00));  // Length low
            sendBuf.append(static_cast<char>(0x00));  // Length high
            sendBuf.append(static_cast<char>(0x00));  // Reserved
            sendBuf.append(static_cast<char>(0x00));  // Reserved
            sendBuf.append(static_cast<char>(0x21));  // CMD 写

            sendBuf.append(static_cast<char>(channel & 0xFF));
            sendBuf.append(static_cast<char>(devAddr));
            sendBuf.append(static_cast<char>((regAddr >> 8) & 0xFF));
            sendBuf.append(static_cast<char>(regAddr & 0xFF));
            sendBuf.append(static_cast<char>(0x00));  // addrFlag
            sendBuf.append(static_cast<char>(0x00));  // Reserved
            sendBuf.append(static_cast<char>(writeValue));
        } else {
            sendBuf.append(static_cast<char>(0x00));  // Length low
            sendBuf.append(static_cast<char>(0x00));  // Length high
            sendBuf.append(static_cast<char>(0x00));  // Reserved
            sendBuf.append(static_cast<char>(0x00));  // Reserved
            sendBuf.append(static_cast<char>(0x20));  // CMD 读

            sendBuf.append(static_cast<char>(channel & 0xFF));
            sendBuf.append(static_cast<char>(devAddr));
            sendBuf.append(static_cast<char>(byteCount));
            sendBuf.append(static_cast<char>((regAddr >> 8) & 0xFF));
            sendBuf.append(static_cast<char>(regAddr & 0xFF));
            sendBuf.append(static_cast<char>(0x00));  // addrFlag
        }

        // 填长度和校验
        quint16 totalLen = sendBuf.size() + 1;
        sendBuf[0] = static_cast<char>(totalLen & 0xFF);
        sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);
        uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
        sendBuf.append(static_cast<char>(sum));

        // 发送
        udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);

        // 延时
        if (delayMs > 0) {
            QThread::msleep(delayMs);
        }
    }
}


void Widget::on_btn_iic_show_clear_clicked()
{
    ui->textBrowser_iic_show->clear();
}

void Widget::on_btn_list_open_clicked()
{
    QString fileName = QFileDialog::getOpenFileName(this, "打开配置文件", "", "配置文件 (*.list *.txt)");
    if (fileName.isEmpty())
        return;

    QFile file(fileName);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
    {
        QMessageBox::warning(this, "错误", "无法打开文件");
        return;
    }

    int row = ui->tableWidget->rowCount();


    while (!file.atEnd())
    {
        QByteArray lineData = file.readLine().trimmed();
        if (lineData.isEmpty() || lineData.startsWith('#') || lineData.startsWith(';'))
            continue;

        QString line = QString::fromUtf8(lineData);
        QStringList fields = line.split(',', QString::SkipEmptyParts);

        if (fields.size() != 7)
            continue;

        ui->tableWidget->insertRow(row);

        // 0: 复选框
        QWidget *checkWidget = new QWidget();
        QCheckBox *checkBox = new QCheckBox();
        checkBox->setChecked(fields[0].trimmed() == "1");
        QHBoxLayout *checkLayout = new QHBoxLayout(checkWidget);
        checkLayout->addWidget(checkBox);
        checkLayout->setAlignment(Qt::AlignCenter);
        checkLayout->setContentsMargins(0, 0, 0, 0);
        ui->tableWidget->setCellWidget(row, 0, checkWidget);

        // 1: 操作类型
        QString opType = fields[1].trimmed();
        QComboBox *combo = new QComboBox();
        combo->addItems(QStringList() << "读" << "写");
        combo->setCurrentText(opType == "写数据" ? "写" : "读");
        QWidget *comboWidget = new QWidget();
        QHBoxLayout *comboLayout = new QHBoxLayout(comboWidget);
        comboLayout->addWidget(combo);
        comboLayout->setContentsMargins(0, 0, 0, 0);
        comboLayout->setAlignment(Qt::AlignCenter);
        ui->tableWidget->setCellWidget(row, 1, comboWidget);

        // 2: 从机地址（包一层 QWidget + QHBoxLayout）
        QString slaveAddr = fields[2].trimmed().toUpper();
        if (slaveAddr.startsWith("0X"))
            slaveAddr = slaveAddr.mid(2);
        bool ok = false;
        int slaveVal = slaveAddr.toInt(&ok, 16);
        slaveAddr = QString("%1").arg(slaveVal, 2, 16, QChar('0')).toUpper();
        QLineEdit *addrEdit = new QLineEdit(slaveAddr);
        addrEdit->setInputMask("HH");
        addrEdit->setAlignment(Qt::AlignRight);
        QWidget *addrWidget = new QWidget();
        QHBoxLayout *addrLayout = new QHBoxLayout(addrWidget);
        addrLayout->addWidget(addrEdit);
        addrLayout->setContentsMargins(0, 0, 0, 0);
        addrLayout->setAlignment(Qt::AlignCenter);
        ui->tableWidget->setCellWidget(row, 2, addrWidget);

        // 3: 寄存器地址（包一层 QWidget + QHBoxLayout）
        QString regAddr = fields[3].trimmed().toUpper();
        if (regAddr.startsWith("0X"))
            regAddr = regAddr.mid(2);
        int regVal = regAddr.toInt(&ok, 16);
        regAddr = QString("%1").arg(regVal, 4, 16, QChar('0')).toUpper();
        QLineEdit *regEdit = new QLineEdit(regAddr);
        regEdit->setInputMask("HHHH");
        regEdit->setAlignment(Qt::AlignRight);
        QWidget *regWidget = new QWidget();
        QHBoxLayout *regLayout = new QHBoxLayout(regWidget);
        regLayout->addWidget(regEdit);
        regLayout->setContentsMargins(0, 0, 0, 0);
        regLayout->setAlignment(Qt::AlignCenter);
        ui->tableWidget->setCellWidget(row, 3, regWidget);

        // 4: 写入数据（包一层 QWidget + QHBoxLayout）
        QString dataField = fields[4].trimmed().toUpper();
        if (dataField.startsWith("0X"))
            dataField = dataField.mid(2);
        int dataVal = dataField.toInt(&ok, 16);
        dataField = QString("%1").arg(dataVal, 2, 16, QChar('0')).toUpper();
        QLineEdit *dataEdit = new QLineEdit(dataField);
        dataEdit->setInputMask("HH");
        dataEdit->setAlignment(Qt::AlignRight);
        QWidget *dataWidget = new QWidget();
        QHBoxLayout *dataLayout = new QHBoxLayout(dataWidget);
        dataLayout->addWidget(dataEdit);
        dataLayout->setContentsMargins(0, 0, 0, 0);
        dataLayout->setAlignment(Qt::AlignCenter);
        ui->tableWidget->setCellWidget(row, 4, dataWidget);

        // 5: 读数据字节数（包一层 QWidget + QHBoxLayout）
        QSpinBox *byteSpin = new QSpinBox();
        byteSpin->setRange(1, 256);
        byteSpin->setValue(fields[5].trimmed().toInt());
        byteSpin->setAlignment(Qt::AlignRight);
        QWidget *byteWidget = new QWidget();
        QHBoxLayout *byteLayout = new QHBoxLayout(byteWidget);
        byteLayout->addWidget(byteSpin);
        byteLayout->setContentsMargins(0, 0, 0, 0);
        byteLayout->setAlignment(Qt::AlignCenter);
        ui->tableWidget->setCellWidget(row, 5, byteWidget);

        // 6: 延时（包一层 QWidget + QHBoxLayout）
        QSpinBox *delaySpin = new QSpinBox();
        delaySpin->setRange(0, 10000);
        delaySpin->setValue(fields[6].trimmed().toInt());
        delaySpin->setAlignment(Qt::AlignRight);
        QWidget *delayWidget = new QWidget();
        QHBoxLayout *delayLayout = new QHBoxLayout(delayWidget);
        delayLayout->addWidget(delaySpin);
        delayLayout->setContentsMargins(0, 0, 0, 0);
        delayLayout->setAlignment(Qt::AlignCenter);
        ui->tableWidget->setCellWidget(row, 6, delayWidget);

        row++;
    }

    file.close();
}

void Widget::on_btn_list_save_clicked()
{
    QString fileName = QFileDialog::getSaveFileName(this, "保存配置文件", "", "配置文件 (*.list *.txt)");
    if (fileName.isEmpty())
        return;

    QFile file(fileName);
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QMessageBox::warning(this, "错误", "无法打开文件写入");
        return;
    }

    QTextStream out(&file);
    out.setCodec("UTF-8");         //先设置编码

    // 写注释头（无需转码）
    out << QString(";该文件为列表操作文件，每行为一个操作，若当前行为\";\"开头，则当前行为注释行\n");
    out << QString(";选择(0-该行不执行、1-该行会被执行),操作类型(写数据、读数据),从机地址(十六进制),寄存器地址(十六进制),写数据(要写的数据，十六进制),读数据字节数,延时(毫秒)\n");


    int rowCount = ui->tableWidget->rowCount();

    for (int row = 0; row < rowCount; ++row)
    {
        // 读取“选择”复选框 (第0列)
        QWidget *checkWidget = ui->tableWidget->cellWidget(row, 0);
        QCheckBox *checkBox = checkWidget ? checkWidget->findChild<QCheckBox*>() : nullptr;
        int select = (checkBox && checkBox->isChecked()) ? 1 : 0;

        // 读取操作类型（第1列）
        QWidget *comboWidget = ui->tableWidget->cellWidget(row, 1);
        QComboBox *combo = comboWidget ? comboWidget->findChild<QComboBox*>() : nullptr;
        QString opType = "读数据";
        if (combo)
        {
            if (combo->currentText() == "写")
                opType = "写数据";
        }

        // 读取从机地址（第2列）
        QWidget *addrWidget = ui->tableWidget->cellWidget(row, 2);
        QLineEdit *addrEdit = addrWidget ? addrWidget->findChild<QLineEdit*>() : nullptr;
        QString slaveAddr = addrEdit ? addrEdit->text().toUpper().trimmed() : "00";
        if (!slaveAddr.startsWith("0x") && !slaveAddr.startsWith("0X"))
            slaveAddr = "0x" + slaveAddr;

        // 读取寄存器地址（第3列）
        QWidget *regWidget = ui->tableWidget->cellWidget(row, 3);
        QLineEdit *regEdit = regWidget ? regWidget->findChild<QLineEdit*>() : nullptr;
        QString regAddr = regEdit ? regEdit->text().toUpper().trimmed() : "0000";
        if (!regAddr.startsWith("0x") && !regAddr.startsWith("0X"))
            regAddr = "0x" + regAddr;

        // 读取写入数据（第4列）
        QWidget *dataWidget = ui->tableWidget->cellWidget(row, 4);
        QLineEdit *dataEdit = dataWidget ? dataWidget->findChild<QLineEdit*>() : nullptr;
        QString writeData = dataEdit ? dataEdit->text().toUpper().trimmed() : "00";
        if (!writeData.startsWith("0x") && !writeData.startsWith("0X"))
            writeData = "0x" + writeData;

        // 读取读数据字节数（第5列）
        QWidget *byteWidget = ui->tableWidget->cellWidget(row, 5);
        QSpinBox *byteSpin = byteWidget ? byteWidget->findChild<QSpinBox*>() : nullptr;
        int byteCount = byteSpin ? byteSpin->value() : 1;

        // 读取延时（第6列）
        QWidget *delayWidget = ui->tableWidget->cellWidget(row, 6);
        QSpinBox *delaySpin = delayWidget ? delayWidget->findChild<QSpinBox*>() : nullptr;
        int delayMs = delaySpin ? delaySpin->value() : 10;

        // 写入文件，字段以逗号分隔
        out << QString("%1,%2,%3,%4,%5,%6,%7\n")
               .arg(select)
               .arg(opType)
               .arg(slaveAddr)
               .arg(regAddr)
               .arg(writeData)
               .arg(byteCount)
               .arg(delayMs);
    }

    file.close();
    QMessageBox::information(this, "保存成功", QString("已保存 %1 行操作到文件").arg(rowCount));
}

void Widget::on_btn_get_clicked()
{
    QByteArray sendBuf;

    // 1. Header: 2 字节长度 + 4 字节保留 + CMD (0x20)
    sendBuf.append(static_cast<char>(0x00));  // Length low
    sendBuf.append(static_cast<char>(0x00));  // Length high
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x30));  //
    sendBuf.append(static_cast<char>(0x04));  //
    sendBuf.append(static_cast<char>(0x00));  //

    // 7. 填写长度
    quint16 totalLen = sendBuf.size() + 1;  // 包含校验位
    sendBuf[0] = static_cast<char>(totalLen & 0xFF);
    sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

    uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
    sendBuf.append(static_cast<char>(sum));
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);
    qDebug() << "len:" << totalLen
             << "data:" << sendBuf.toHex(' ').toUpper();
}



void Widget::on_btn_cp_status_clicked()
{
    QByteArray sendBuf;

    // 1. Header: 2 字节长度 + 4 字节保留 + CMD (0x20)
    sendBuf.append(static_cast<char>(0x00));  // Length low
    sendBuf.append(static_cast<char>(0x00));  // Length high
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x00));  // Reserved
    sendBuf.append(static_cast<char>(0x30));  //
    sendBuf.append(static_cast<char>(0x05));  //
    sendBuf.append(static_cast<char>(0x00));  //

    // 7. 填写长度
    quint16 totalLen = sendBuf.size() + 1;  // 包含校验位
    sendBuf[0] = static_cast<char>(totalLen & 0xFF);
    sendBuf[1] = static_cast<char>((totalLen >> 8) & 0xFF);

    uint8_t sum = calcChecksum(sendBuf, sendBuf.size());
    sendBuf.append(static_cast<char>(sum));
    udp_recvthread->sendCommandToHost(udp_recvthread->strIP, udp_recvthread->port, sendBuf);
    qDebug() << "len:" << totalLen
             << "data:" << sendBuf.toHex(' ').toUpper();
}

void Widget::on_pushButton_clicked()
{
    udp_recvthread->sendCommandToHost("192.168.1.10", udp_recvthread->port, makeCommand(CMD_PIC_ON));
}

void Widget::on_pushButton_2_clicked()
{
    udp_recvthread->sendCommandToHost("192.168.1.11", udp_recvthread->port, makeCommand(CMD_PIC_ERR_ON));
}

void Widget::on_btn_screenshot_clicked()
{
    QDir dir(QCoreApplication::applicationDirPath());
    if (!dir.exists("pic") && !dir.mkdir("pic"))
        qDebug() << "on_btn_screenshot_clicked faild";

    QString timestamp = QDateTime::currentDateTime().toString("yyyyMMdd_HHmmss_zzz");
    QString path = dir.filePath(QString("pic/image_%1.png").arg(timestamp));

    // 从共享内存获取图像并保存
//            假设 handlethread 有方法读取图像
    QImage img;
    if (!handlethread->readImageFromSharedMemory(img,1))
    {
        qWarning() << "Failed to read image from shared memory";
        return;
    }
    if (img.isNull())
    {
        qWarning() << "Image is null";
        return;
    }
    if (img.save(path))
    {
        qDebug() << "Image successfully saved to" << path;
    }
    else
    {
        qWarning() << "Failed to save image";
    }
}
