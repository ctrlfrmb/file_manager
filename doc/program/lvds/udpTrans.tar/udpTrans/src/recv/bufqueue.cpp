#include "bufqueue.h"


BufQueue::BufQueue(QObject *parent) : QObject(parent)
{

}


BufQueue* BufQueue::getInstance()
{
    static BufQueue instance;
    return &instance;
}

void BufQueue::inQueue(char *buf)
{
    QMutexLocker locker(&mutex);
    cache.push_back(buf);
}

void BufQueue::outQueue(QList<char*> &buflist)
{
    QMutexLocker locker(&mutex);
    buflist.clear();
    buflist.append(cache);
    cache.clear();
}



BufQueue::~BufQueue()
{

}
