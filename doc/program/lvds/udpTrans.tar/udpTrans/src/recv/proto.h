#ifndef PROTO_H
#define PROTO_H

#include <QObject>

enum CommandType {

    CMD_HARDWARE_VER = 0,
    CMD_SOFTWARE_VER,
    CMD_FS_ADDR = 2,
    CMD_FS_MASK,
    CMD_FS_SIZE,
    CMD_RD_SETTINGS = 10,
    CMD_SV_SETTINGS = 11,
    CMD_DF_SETTINGS = 12,
    CMD_VIDEO_START,
    CMD_VIDEO_STOP,
    CMD_PIC_ON,
    CMD_PIC_ERR_ON,
    CMD_CUSTOM
};

typedef struct
{
    uint64_t reserved_container;
    uint32_t ipaddr_u32;
    uint32_t mask_u32;
    uint32_t gw_u32;
    uint8_t mac_address[8];
} __attribute__ ((__packed__)) config_Settings_t;


#define BD_VIDEO_HEADER_ID              0xAA5555AA
#define SF_HEADER_ID                    0x0FA55AF0//0f a5 5a f0
#define HEADER_SIZE           sizeof(packet_header)
#define FRAME_DATA_SIZE       1200
#define PACKET_SIZE           (HEADER_SIZE + FRAME_DATA_SIZE)

#pragma pack(4)
typedef struct packet_header
{
    quint32 HEAD_ID;     // 0xAA5555AA
    quint32 Channel_ID;
    quint32 SEND_FLAG;
    quint32 Width;
    quint32 Height;
    quint32 total;
    quint32 offset;
    quint32 picseq;
    quint32 frameseq;
    quint32 framesize;
} packet_header;


//一个完整的udp报文由两部分组成：
/**
  *---------------------------------------------------------------
  *| packet_header(消息头) (sizeof(packet_header)字节) | 有效图片数据 (1200字节)|
  *---------------------------------------------------------------
  * */

#pragma pack()

struct ImageHeader
{
    int width;
    int height;
    int format; // QImage::Format
    int dataSize; // 图像数据字节数，方便校验
};


#endif // PROTO_H
