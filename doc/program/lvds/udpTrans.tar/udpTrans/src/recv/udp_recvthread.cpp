#include "udp_recvthread.h"
#include "proto.h"
#include "bufqueue.h"
#include <QDebug>
#include <QHostAddress>
#include <QTimer>

#ifdef Q_OS_WIN
#include <winsock2.h>
#endif

#ifdef Q_OS_LINUX
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#endif

// 设置UDP接收缓存大小（单位：MB）
#define CACHE_SIZE_RECV_MB  32

Udp_RecvThread::Udp_RecvThread(QObject *parent)
    : QThread(parent)
{
#ifdef Q_OS_WIN
    // Windows平台下初始化Winsock库
    WSADATA wsaData;
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0)
    {
        qWarning() << "WSAStartup failed!";
    }
#endif
}

Udp_RecvThread::~Udp_RecvThread()
{
    stopReceiver();

#ifdef Q_OS_WIN
    WSACleanup();
#endif
}

void Udp_RecvThread::startReceiver()
{
    QMutexLocker locker(&m_lock);
    if (isRunning()) stopReceiver();
    bwork = true;
    start();
}

void Udp_RecvThread::stopReceiver()
{
    QMutexLocker locker(&m_lock);
    bwork = false;
    wait();  // 等待线程安全退出
    closeSocket();
}

void Udp_RecvThread::closeSocket()
{
    if (sockfd >= 0) {
#ifdef Q_OS_WIN
        closesocket(sockfd);
#else
        close(sockfd);
#endif
        sockfd = -1;
    }
}

// 初始化socket：创建 + 绑定 + 设置接收缓冲
bool Udp_RecvThread::initSocket()
{
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0){
        qWarning() << "Socket creation failed!";
        return false;
    }

    // 设置地址复用
    int reuse = 1;
    setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, (char*)&reuse, sizeof(reuse));

    // 设置接收缓冲大小
    int nRecvBuf = CACHE_SIZE_RECV_MB * 1024 * 1024;
    int nRet = setsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, (const char*)&nRecvBuf, sizeof(int));
    qDebug() << "setsockopt return:" << nRet;

    // 打印实际生效的缓冲区大小（有的系统会自动缩小）
    int actualSize = 0;
    int optlen = sizeof(actualSize);  // Windows 下直接用 int
    if (getsockopt(sockfd, SOL_SOCKET, SO_RCVBUF, (char*)&actualSize, &optlen) == 0)
    {
        qDebug() << "Actual SO_RCVBUF size =" << actualSize;
    }

    sockaddr_in addr;
    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);              // 绑定指定端口
    addr.sin_addr.s_addr = htonl(INADDR_ANY); // 所有本地IP可用

    if (bind(sockfd, (sockaddr*)&addr, sizeof(addr)) < 0){
        closeSocket();
        qWarning() << "Socket bind failed!";
        return false;
    }

    return true;
}


void Udp_RecvThread::run()
{
    qDebug() << "[RecvThread] run() start";
    if (!initSocket())
    {
        emit serverStarted(false);
        return;
    }

    emit serverStarted(true);
    bwork = true;

    setPriority(QThread::TimeCriticalPriority);  // 提高线程调度优先级

    sockaddr_in clientAddr;
    socklen_t clientAddrSize = sizeof(clientAddr);
    fd_set rfd;
    static char recv_buf[65536] = {0};  // 单帧最大64K缓冲

#ifdef Q_OS_WIN
    // 统一用一个短超时，方便检查退出并周期性做维护
    timeval timeout;
    timeout.tv_sec = 0;
    timeout.tv_usec = 200000; // 200ms
#endif

    while (bwork)
    {
        FD_ZERO(&rfd);
        FD_SET(sockfd, &rfd);

        // select 用超时，以便及时响应 bwork 变化
#ifdef Q_OS_WIN
        int nRet = select(0, &rfd, nullptr, nullptr, &timeout);
#else
        // 必须每次重置 timeout 值（select 会修改）
        timeval tv = timeout;
        int nRet = select(sockfd + 1, &rfd, nullptr, nullptr, &tv);
#endif

        if (nRet < 0)
        {
            qWarning() << "select() error!";
            break;
        }
        if (nRet == 0) continue;

        if (!FD_ISSET(sockfd, &rfd)) continue;

        int nrecv = recvfrom(sockfd, recv_buf, sizeof(recv_buf), 0,
                             (sockaddr*)&clientAddr, &clientAddrSize);

        if (nrecv <= 0) continue;

        // 获取帧头 ID
        quint32 head_id = 0;
        memcpy(&head_id, recv_buf, sizeof(quint32));

        QString straddr = QHostAddress(htonl(clientAddr.sin_addr.S_un.S_addr)).toString();

        if (head_id == BD_VIDEO_HEADER_ID)
        {
            packet_header* phead = reinterpret_cast<packet_header*>(recv_buf);
            int expected_len = sizeof(packet_header) + phead->framesize;

            if (nrecv == expected_len)
            {
                char* buf = (char*)malloc(nrecv);
                if (!buf)
                {
                    qWarning() << "malloc failed!";
                    continue;
                }

                memcpy(buf, recv_buf, nrecv);
                BufQueue::getInstance()->inQueue(buf);
            }
            else
            {
                qWarning() << "Invalid UDP size: actual =" << nrecv
                           << ", expected =" << expected_len;
            }
        }
        else if (head_id == SF_HEADER_ID)
        {
//            qDebug() << "SF_HEADER_ID received.";
            emit soft_cmd_data(QByteArray(recv_buf, nrecv));
        }
        else
        {
            if(straddr == strIP)
            {
                qDebug() << "receive len "<<nrecv;
                if(recv_buf[0] == nrecv)
                {
                    emit board_cmd_data(QByteArray(recv_buf, nrecv));
                }
                else
                {
                    qDebug() << "recv_buf[0] "<<recv_buf[0];
                    qWarning() << "Unknown header ID:" << QString("0x%1").arg(head_id, 8, 16, QLatin1Char('0'));
                }
            }
            else
            {
                QString hexStr;
                for (int i = 0; i < nrecv; i++)
                {
                    hexStr += QString("%1 ").arg(static_cast<unsigned char>(recv_buf[i]), 2, 16, QLatin1Char('0')).toUpper();
                }
                qDebug() <<nrecv << "Received data:" << hexStr;
            }
        }
    }

    emit serverStarted(false);
}


// 主动发送命令到指定IP和端口（IPv4 only）
void Udp_RecvThread::sendCommandToHost(const QString& ip, quint16 port, const QByteArray& data)
{
    if (sockfd <= 0 || data.isEmpty()) {
        qWarning() << "Socket invalid or empty data";
        return;
    }

    sockaddr_in remoteAddr;
    memset(&remoteAddr, 0, sizeof(remoteAddr));
    remoteAddr.sin_family = AF_INET;
    remoteAddr.sin_port = htons(port);
    remoteAddr.sin_addr.s_addr = inet_addr(ip.toUtf8().constData());

    // 检查地址合法性
    if (remoteAddr.sin_addr.s_addr == INADDR_NONE) {
        qWarning() << "Invalid IP address:" << ip;
        return;
    }

    // 发送数据
    int sent = sendto(sockfd, data.constData(), data.size(), 0,
                      (sockaddr*)&remoteAddr, sizeof(remoteAddr));

    if (sent < 0) {
        qWarning() << "Failed to send data to" << ip << ":" << port;
    } else {
        qDebug() << "Sent" << sent << "bytes to" << ip << ":" << port;
    }
}


