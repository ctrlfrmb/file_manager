#ifndef DYNAMICTESTPATTERN_H
#define DYNAMICTESTPATTERN_H

#include "data_process.h"
#include <QTimer>

class DynamicTestPattern : public QObject
{
    Q_OBJECT
public:
    DynamicTestPattern(int width, int height, int blockSize = 100, int fps = 60, QObject *parent = nullptr);
    void start();
    void stop();
    int currentFps;
signals:
    void frameReady(const QPixmap &pixmap);

private slots:
    void updateFrame();
    void updateFps();

private:
    cv::Mat generateFrame();
    void updateBlockPosition();

private:
    int width, height;
    int blockSize;
    int fps;
    int blockX, blockY;
    int velocityX, velocityY;
    std::vector<cv::Scalar> colors;
    QTimer timer;
    QTimer fpsTimer;
    int frameCount;

};


#endif // DYNAMICTESTPATTERN_H
