#ifndef HANDLETHREAD_H
#define HANDLETHREAD_H
#include <windows.h>
#include <QObject>
#include <QThread>
#include <QPixmap>
#include <QMap>
#include <QDebug>
#include <QList>
#include <QMapIterator>
#include <QImage>
#include <QDateTime>
#include <QElapsedTimer>
#include <QByteArray>
#include <QSharedMemory>
#include <QBuffer>
#include <QDataStream>
#include <QMutex>
#include "data_process.h"
#include "bufqueue.h"
#include "proto.h"

#define MAX_CHANNELS 4
#define PER_CHANNEL_SIZE (3840 * 2160 * 3) // 每通道最大图像尺寸 (6MB)
#define DATA_SIZE (MAX_CHANNELS * PER_CHANNEL_SIZE)
#define SHM_NAME L"LVDS_shared_memory"

struct ChannelState
{
    QByteArray frameBuffer;
    int totalSize = 0;
    int expectedFrameCount = 0;
    int currentFrameIndex = 1;
    int lastPicSeq = -1;

    int width = 0;
    int height = 0;

    int frameCount = 0;
    QElapsedTimer timer;
    QElapsedTimer fpsTimer;

    QImage rgbImage;
    QVector<QByteArray> allPackets;  // 保存整帧所有包（包含包头和负载）

    ChannelState() {
        frameBuffer.reserve(HEADER_SIZE + FRAME_DATA_SIZE * 64);
        fpsTimer.start();
    }
};


class HandleThread : public QThread
{
    Q_OBJECT
public:
    explicit HandleThread(QObject *parent = nullptr);

    ~HandleThread();

    void stopHandle();
    QMap<int, ChannelState> channelStates;
    bool writeImageToSharedMemory(const QImage &img, int channelId);
    bool readImageFromSharedMemory(QImage &img, int channelId);

protected:

    void run();

signals:
    void showPixmapSig(QPixmap pix);

    void showMsgSig(QString tips);

private:
    volatile bool bwork = false;
    const int timeoutMs = 1000;

    QMutex shmMutex;  // 用于线程安全
    HANDLE hMapFile = NULL;
    void* pBuf = nullptr;

    void handleTimeoutChannels(QMap<int, ChannelState>& states, int timeoutMs);
    void processPacket(char* data, QMap<int, ChannelState>& states);
    void handleFirstFrameSegment(char* data, ChannelState& state, packet_header* phead, int fsize);
    void handleCompleteFrame(int channelId, ChannelState& state);
    bool initSharedMemory(void);
    void releaseSharedMemory(void);

};

#endif // HANDLETHREAD_H
