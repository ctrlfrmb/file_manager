#ifndef UDP_RECVTHREAD_H
#define UDP_RECVTHREAD_H

#include <QObject>
#include <QThread>
#include <QMutex>

#ifdef Q_OS_WIN
typedef int socklen_t;
#endif

class Udp_RecvThread : public QThread
{
    Q_OBJECT
public:
    explicit Udp_RecvThread(QObject *parent = nullptr);
    ~Udp_RecvThread();

    void startReceiver();
    void stopReceiver();


    // 主动向指定IP和端口发送UDP数据
    void sendCommandToHost(const QString& ip, quint16 port, const QByteArray& data);



    // 当前接收端口（由界面设置）
    quint16 port = 0;

    // 接收过滤：仅处理来自该IP的数据
    QString strIP;

protected:
    void run() override;         // 线程主函数

private:
    // 工作状态标志（主线程控制退出）
    volatile bool bwork = false;
    int sockfd = -1;             //socket 描述符
    QMutex m_lock;
    bool initSocket();           // socket初始化（创建+绑定+设置缓存）
    void closeSocket();

signals:
    void serverStarted(bool bok); // 通知主线程服务启动或停止
    void soft_cmd_data(QByteArray data);
    void board_cmd_data(QByteArray data);
};

#endif // SOCKETRECVTHREAD_H
