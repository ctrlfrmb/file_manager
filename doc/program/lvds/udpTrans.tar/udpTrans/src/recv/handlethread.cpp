#include "handlethread.h"



HandleThread::HandleThread(QObject *parent) : QThread(parent)
{
    initSharedMemory();
}

HandleThread::~HandleThread()
{
    stopHandle();
    releaseSharedMemory();
}

void HandleThread::stopHandle()
{
    bwork = false;
    wait();  // 等待线程安全退出
}

void HandleThread::run()
{
    qDebug() << "handle thread begin to parse datagram" << Q_FUNC_INFO;
    // 提高线程优先级，帮助降低处理阻塞
    QThread::currentThread()->setPriority(QThread::HighPriority);
    bwork = true;
    channelStates.clear();  // 清理状态
    while (bwork)
    {
        QList<char*> buflist;
        BufQueue::getInstance()->outQueue(buflist);

        if (buflist.isEmpty())
        {
            handleTimeoutChannels(channelStates, timeoutMs);
            QThread::msleep(100);
            continue;
        }
        for (char* byteitem : buflist)
        {
            if (byteitem)
                processPacket(byteitem, channelStates);
            free(byteitem);  // 安全释放
        }
    }
}

void HandleThread::handleTimeoutChannels(QMap<int, ChannelState>& states, int timeoutMs)
{
    for (auto it = states.begin(); it != states.end(); ++it)
    {
        ChannelState& state = it.value();
        if (state.currentFrameIndex > 1 && state.timer.elapsed() > timeoutMs)
        {
            qWarning() << QString("Channel %1 timeout. Discarding image.").arg(it.key());
            state.currentFrameIndex = 1;
            state.frameBuffer.clear();
            state.width = 0;
            state.height = 0;
            state.totalSize = 0;
            state.expectedFrameCount = 0;
            state.lastPicSeq = -1;  //
        }
    }
}


void HandleThread::processPacket(char* data, QMap<int, ChannelState>& states)
{
    packet_header* phead = reinterpret_cast<packet_header*>(data);
    const int channelId = phead->Channel_ID;
    const quint32 picseq = phead->picseq;
    const quint32 frameseq = phead->frameseq;
    const quint32 fsize = phead->framesize;

    // 忽略异常包
    if (fsize == 0 || frameseq == 0 || phead->total == 0)
    {
        qWarning() << QString("CH%1 invalid packet: fsize=%2 frameseq=%3 total=%4")
                      .arg(channelId).arg(fsize).arg(frameseq).arg(phead->total);
        ChannelState& st = states[channelId];
        st.currentFrameIndex = 1;
        st.frameBuffer.clear();
        return;
    }

    ChannelState& state = states[channelId];
    state.timer.restart();

    // 新的一帧
    if (picseq != static_cast<quint32>(state.lastPicSeq))
    {
        state.lastPicSeq = picseq;
        state.frameBuffer.clear();
        state.currentFrameIndex = 1;
    }


    if (frameseq == 1)
    {
        handleFirstFrameSegment(data, state, phead, fsize);
        return;
    }

    if (frameseq == state.expectedFrameCount)
    {
        if (frameseq != state.currentFrameIndex)
        {
            state.currentFrameIndex = 1;
            return;
        }

        memcpy(state.frameBuffer.data() + (frameseq - 1) * fsize, data + HEADER_SIZE, fsize);

        if (state.frameBuffer.size() == state.totalSize)
        {
            handleCompleteFrame(channelId, state);
        }

        state.currentFrameIndex = 1;
    }
    else if (frameseq == state.currentFrameIndex)
    {
        memcpy(state.frameBuffer.data() + (frameseq - 1) * fsize, data + HEADER_SIZE, fsize);
        state.currentFrameIndex++;
    }
    else
    {
        if (state.currentFrameIndex != 1)
        {
            QString msg = QString("CH%1 expected %2, got %3 / %4")
                          .arg(channelId)
                          .arg(state.currentFrameIndex)
                          .arg(frameseq)
                          .arg(state.expectedFrameCount);
//            qWarning() << msg;
            emit showMsgSig(msg);
        }
        state.currentFrameIndex = 1;
    }
}


void HandleThread::handleFirstFrameSegment(char* data, ChannelState& state, packet_header* phead, int fsize)
{
    if (phead->Width == 0 || phead->Height == 0 || phead->total == 0)
    {
        qWarning() << "Invalid image size. Skip.";
        return;
    }

    // 预分配：如果已有容量 < total 则 reserve
    if ((quint32)state.frameBuffer.capacity() < phead->total) {
        state.frameBuffer.reserve(phead->total);
    }
    state.frameBuffer.resize(phead->total);
    memcpy(state.frameBuffer.data(), data + HEADER_SIZE, fsize);

    state.width = phead->Width;
    state.height = phead->Height;
    state.totalSize = phead->total;
    state.expectedFrameCount = (state.totalSize + fsize - 1) / fsize;
    state.currentFrameIndex = 2;
}



void HandleThread::handleCompleteFrame(int channelId, ChannelState& state)
{
    if (state.width == 0 || state.height == 0)
    {
        qWarning() << QString("CH%1 invalid image dimension.").arg(channelId);
        return;
    }

    uchar* rawData = reinterpret_cast<uchar*>(state.frameBuffer.data());
    cv::Mat bgrImg(state.height, state.width, CV_8UC3, rawData);
#if 1
    std::vector<cv::Mat> channels(3);
    cv::split(bgrImg, channels);
    std::vector<cv::Mat> reordered = { channels[2], channels[0], channels[1] };
    cv::Mat rgbImg;
    cv::merge(reordered, rgbImg);
    QImage qimg(rgbImg.data, rgbImg.cols, rgbImg.rows, rgbImg.step, QImage::Format_RGB888);
#else
    QImage qimg(bgrImg.data, bgrImg.cols, bgrImg.rows, bgrImg.step, QImage::Format_RGB888);
#endif
    state.rgbImage = qimg.copy();  // 避免悬挂指针

    emit showPixmapSig(QPixmap::fromImage(state.rgbImage));


    if (!writeImageToSharedMemory(state.rgbImage, channelId))
    {
        qWarning() << QString("CH%1 failed to write image to shared memory!").arg(channelId);
    }
    else
    {
//        qDebug() << QString("CH%1 image written to shared memory successfully.").arg(channelId);
    }


    state.frameCount++;
    if (state.fpsTimer.elapsed() >= 1000)
    {
        double fps = state.frameCount * 1000.0 / state.fpsTimer.elapsed();
        QString fpsStr = QString("CH%1 FPS: %2").arg(channelId).arg(fps, 3, 'f', 1);
        emit showMsgSig(fpsStr);

        state.frameCount = 0;
        state.fpsTimer.restart();
    }
}
bool HandleThread::initSharedMemory(void)
{
    hMapFile = CreateFileMappingW(
        INVALID_HANDLE_VALUE,
        NULL,
        PAGE_READWRITE,
        0,
        DATA_SIZE,
        SHM_NAME);

    if (hMapFile == NULL)
    {
        qDebug() << "CreateFileMapping failed:" << GetLastError();
        return false;
    }

    pBuf = MapViewOfFile(hMapFile, FILE_MAP_WRITE, 0, 0, DATA_SIZE);
    if (pBuf == nullptr)
    {
        qDebug() << "MapViewOfFile failed:" << GetLastError();
        CloseHandle(hMapFile);
        hMapFile = NULL;
        return false;
    }

    return true;
}

void HandleThread::releaseSharedMemory(void)
{
    if (pBuf)
    {
        UnmapViewOfFile(pBuf);
        pBuf = nullptr;
    }

    if (hMapFile)
    {
        CloseHandle(hMapFile);
        hMapFile = NULL;
    }
}

bool HandleThread::writeImageToSharedMemory(const QImage &img, int channelId)
{
    if (pBuf == nullptr)
    {
        qWarning() << "共享内存未初始化";
        return false;
    }

    int imgSize = img.byteCount();
    int offset = (channelId - 1) * PER_CHANNEL_SIZE;

    // 写入头部信息 + 数据
    if (offset + sizeof(ImageHeader) + imgSize > DATA_SIZE)
    {
        qWarning() << QString("CH%1 写入超出共享内存范围").arg(channelId);
        return false;
    }

    ImageHeader header;
    header.width = img.width();
    header.height = img.height();
    header.format = static_cast<int>(img.format());
    header.dataSize = imgSize;

    uchar *basePtr = static_cast<uchar*>(pBuf) + offset;
    memcpy(basePtr, &header, sizeof(ImageHeader));
    memcpy(basePtr + sizeof(ImageHeader), img.constBits(), imgSize);

    return true;
}

bool HandleThread::readImageFromSharedMemory(QImage &img, int channelId)
{
    if (pBuf == nullptr)
    {
        qWarning() << "共享内存未初始化";
        return false;
    }

    int offset = (channelId - 1) * PER_CHANNEL_SIZE;
    uchar *basePtr = static_cast<uchar*>(pBuf) + offset;

    ImageHeader header;
    memcpy(&header, basePtr, sizeof(ImageHeader));

    if (header.dataSize <= 0 || header.width <= 0 || header.height <= 0)
    {
        qWarning() << QString("CH%1 图像头信息无效").arg(channelId);
        return false;
    }

    uchar *imageData = basePtr + sizeof(ImageHeader);

    img = QImage(imageData, header.width, header.height,
                 QImage::Format(header.format));

    return !img.isNull();
}
