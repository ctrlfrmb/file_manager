#include "DynamicTestPattern.h"

DynamicTestPattern::DynamicTestPattern(int width, int height, int blockSize, int fps, QObject *parent)
    : QObject(parent),
      width(width),
      height(height),
      blockSize(blockSize),
      fps(fps),
      blockX(500),
      blockY(300),
      velocityX(8),
      velocityY(6),
      frameCount(0),
      currentFps(0)
{
    colors = {
        cv::Scalar(255,0,0), cv::Scalar(0,255,0), cv::Scalar(0,0,255),
        cv::Scalar(255,255,0), cv::Scalar(255,0,255), cv::Scalar(0,255,255),
        cv::Scalar(255,255,255), cv::Scalar(0,0,0)
    };

    connect(&timer, &QTimer::timeout, this, &DynamicTestPattern::updateFrame);
    connect(&fpsTimer, &QTimer::timeout, this, &DynamicTestPattern::updateFps);
}

void DynamicTestPattern::start()
{
    timer.start(1000 / fps);
    fpsTimer.start(1000);
}

void DynamicTestPattern::stop()
{
    timer.stop();
    fpsTimer.stop();
}

void DynamicTestPattern::updateFrame()
{
    cv::Mat frame = generateFrame();
    cv::Mat rgbFrame;
    cv::cvtColor(frame, rgbFrame, cv::COLOR_BGR2RGB);
    QImage img(rgbFrame.data, rgbFrame.cols, rgbFrame.rows, rgbFrame.step, QImage::Format_RGB888);
    emit frameReady(QPixmap::fromImage(img.copy()));
    frameCount++;
}

void DynamicTestPattern::updateFps()
{
    currentFps = frameCount;
    frameCount = 0;
}

void DynamicTestPattern::updateBlockPosition()
{
    blockX += velocityX;
    blockY += velocityY;
    if (blockX <= 0 || blockX + blockSize >= width)
        velocityX = -velocityX;
    if (blockY <= 0 || blockY + blockSize >= height)
        velocityY = -velocityY;
}

cv::Mat DynamicTestPattern::generateFrame()
{
    cv::Mat frame(height, width, CV_8UC3, cv::Scalar(0,0,0));
    int stripeWidth = width / static_cast<int>(colors.size());
    for (int i = 0; i < static_cast<int>(colors.size()); i++)
    {
        cv::rectangle(frame, cv::Point(i*stripeWidth, 0),
                      cv::Point((i+1)*stripeWidth, height), colors[i], cv::FILLED);
    }
    cv::rectangle(frame, cv::Point(blockX, blockY),
                  cv::Point(blockX+blockSize, blockY+blockSize),
                  cv::Scalar(128,128,128), cv::FILLED);
    updateBlockPosition();
    return frame;
}
