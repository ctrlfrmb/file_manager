#-------------------------------------------------
#
# Project created by QtCreator 2019-07-14T17:18:32
#
#-------------------------------------------------

QT       += core gui network

greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

TARGET = recv
TEMPLATE = app

win32 {
    LIBS += -lws2_32
}

CONFIG += c++11

# The following define makes your compiler emit warnings if you use
# any feature of Qt which has been marked as deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS

# You can also make your code fail to compile if you use deprecated APIs.
# In order to do so, uncomment the following line.
# You can also select to disable deprecated APIs only up to a certain version of Qt.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0


SOURCES += \
    DynamicTestPattern.cpp \
    data_process.cpp \
    main.cpp \
#    tcp_cmd_recvthread.cpp \
#    tcp_video_recvthread.cpp \
    udp_recvthread.cpp \
    widget.cpp \
    bufqueue.cpp \
    handlethread.cpp

HEADERS += \
    DynamicTestPattern.h \
    data_process.h \
#    tcp_cmd_recvthread.h \
#    tcp_video_recvthread.h \
    udp_recvthread.h \
    widget.h \
    proto.h \
    bufqueue.h \
    handlethread.h

FORMS += \
        widget.ui


INCLUDEPATH += D:\opencv\install\include\
               D:\opencv\install\include\opencv2\
               D:\opencv\install\include\opencv

LIBS += -L D:\opencv\install\x64\mingw\lib\libopencv_*.a


RC_ICONS = $$PWD/../../favicon.ico

# 指定输出目录
DESTDIR = $$PWD/../../exe

# 运行 windeployqt 自动打包 Qt 所需 DLL（适用于 GUI 程序）
win32 {
    QMAKE_POST_LINK += $$quote(windeployqt $$DESTDIR/$$TARGET.exe $$escape_expand(\\n))

}

