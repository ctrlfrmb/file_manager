#include "tcp_video_recvthread.h"
#include "proto.h"
#include "bufqueue.h"
#include <QDebug>
#include <QNetworkProxy>


Tcp_Video_RecvThread::Tcp_Video_RecvThread(QObject *parent)
    : QThread(parent)
{
}

Tcp_Video_RecvThread::~Tcp_Video_RecvThread()
{
    stopReceiver();
}

void Tcp_Video_RecvThread::setServer(const QString &ip, int port)
{
    serverIp = ip;
    serverPort = port;
}

void Tcp_Video_RecvThread::startReceiver()
{
    QMutexLocker locker(&m_lock);
    if (isRunning())
        stopReceiver();

    bwork = true;
    start();
}

void Tcp_Video_RecvThread::stopReceiver()
{
    QMutexLocker locker(&m_lock);
    bwork = false;

    if (socket)
    {
        socket->disconnectFromHost();
        socket->close();
    }

    wait();
}

void Tcp_Video_RecvThread::closeSocket()
{
    if (!socket)
        return;

    socket->disconnectFromHost();
    socket->close();
    delete socket;
    socket = nullptr;
}


void Tcp_Video_RecvThread::run()
{
    qDebug() << "[Tcp_Video_RecvThread] run() start";

    socket = new QTcpSocket();
    socket->setProxy(QNetworkProxy::NoProxy);
    socket->connectToHost(serverIp, serverPort);

    if (!socket->waitForConnected(2000))
    {
        qWarning() << "[Tcp_Video] connect failed!";
        emit serverStarted(false);
        closeSocket();
        return;
    }

    emit serverStarted(true);
    bwork = true;

    setPriority(QThread::TimeCriticalPriority);

    recvBuffer.clear();

    while (bwork)
    {
//        if (socket->state() != QAbstractSocket::ConnectedState)
//        {
//            qWarning() << "[Tcp_Video] socket disconnected";
//            break;
//        }

        QByteArray data = socket->readAll();
        if (data.isEmpty())
            continue;

        recvBuffer.append(data);
//        qDebug() << "[Tcp_Video] total buffer size:" << recvBuffer.size();

        while (recvBuffer.size() >= 1240)
        {
            /* ===== 解析当前缓存 ===== */
            QByteArray frame = recvBuffer.left(1240);
            recvBuffer.remove(0, 1240);
//            qDebug() << "receive len "<<frame.size();
            quint32 head_id = 0;
            memcpy(&head_id, frame.constData(), sizeof(quint32));

            if (head_id == BD_VIDEO_HEADER_ID)
            {

                char* buf = (char*)malloc(1240);
                if (!buf)
                {
                    qWarning() << "malloc failed!";
                    continue;
                }
                memcpy(buf, frame.data(), 1240);
                BufQueue::getInstance()->inQueue(buf);
            }
            else
            {
                    qDebug() << "receive len "<<frame.size();
//                    QString hexStr;
//                    for (int i = 0; i < frame.size(); i++)
//                    {
//                        hexStr += QString("%1 ").arg(static_cast<unsigned char>(frame[i]), 2, 16, QLatin1Char('0')).toUpper();
//                    }
//                    qDebug() <<frame.size() << "Received data:" << hexStr;
                    recvBuffer.clear();
                    continue;

            }
        }
    }

    closeSocket();
    emit serverStarted(false);
}



void Tcp_Video_RecvThread::sendCommandToHost(const QByteArray &data)
{
    if (!socket || data.isEmpty())
    {
        qWarning() << "[Tcp_Video] socket invalid or empty data";
        return;
    }

    if (socket->state() != QAbstractSocket::ConnectedState)
    {
        qWarning() << "[Tcp_Video] socket not connected";
        return;
    }

    qint64 totalSent = 0;
    const char* ptr = data.constData();
    qint64 totalLen = data.size();

    /* TCP write 可能一次没写完，循环保证发送完成 */
    while (totalSent < totalLen)
    {
        qint64 sent = socket->write(ptr + totalSent, totalLen - totalSent);
        if (sent < 0)
        {
            qWarning() << "[Tcp_Video] write failed:" << socket->errorString();
            return;
        }

        totalSent += sent;

        if (!socket->waitForBytesWritten(1000))
        {
            qWarning() << "[Tcp_Video] waitForBytesWritten timeout";
            return;
        }
    }

    qDebug() << "[Tcp_Video] Sent" << totalSent << "bytes";
}
