#include "tcp_cmd_recvthread.h"
#include <QNetworkProxy>
#include "proto.h"
#include <QDebug>

Tcp_Cmd_RecvThread::Tcp_Cmd_RecvThread(QObject *parent)
    : QThread(parent)
{
}

Tcp_Cmd_RecvThread::~Tcp_Cmd_RecvThread()
{
    stopReceiver();
}

void Tcp_Cmd_RecvThread::setServer(const QString &ip, int port)
{
    serverIp = ip;
    serverPort = port;
}

void Tcp_Cmd_RecvThread::startReceiver()
{
    QMutexLocker locker(&m_lock);
    if (isRunning())
        stopReceiver();

    bwork = true;
    start();
}

void Tcp_Cmd_RecvThread::stopReceiver()
{
    QMutexLocker locker(&m_lock);
    bwork = false;

    if (socket)
    {
        socket->disconnectFromHost();
        socket->close();
    }

    wait();
}

void Tcp_Cmd_RecvThread::closeSocket()
{
    if (!socket)
        return;

    socket->disconnectFromHost();
    socket->close();
    delete socket;
    socket = nullptr;
}

void Tcp_Cmd_RecvThread::run()
{
    qDebug() << "[Tcp_Cmd_RecvThread] run() start";

    socket = new QTcpSocket();
    socket->setProxy(QNetworkProxy::NoProxy);
    socket->connectToHost(serverIp, serverPort);

    if (!socket->waitForConnected(2000))
    {
        qWarning() << "[Tcp_Cmd] connect failed!";
        emit serverStarted(false);
        closeSocket();
        return;
    }

    emit serverStarted(true);
    bwork = true;

    setPriority(QThread::TimeCriticalPriority);

    recvBuffer.clear();

    while (bwork)
    {
        if (socket->state() != QAbstractSocket::ConnectedState)
        {
            qWarning() << "[Tcp_Cmd] socket disconnected";
            break;
        }

        if (!socket->waitForReadyRead(200))
            continue;

        QByteArray data = socket->readAll();
        if (data.isEmpty())
            continue;

        recvBuffer.append(data);

        /* ===== 只负责“解析当前缓存” ===== */
        while (true)
        {
            if (recvBuffer.size() < (int)sizeof(quint32))
                break;

            quint32 head_id = 0;
            memcpy(&head_id, recvBuffer.constData(), sizeof(quint32));

            if (head_id == BD_VIDEO_HEADER_ID)
            {
                recvBuffer.remove(0, 1);
                continue;
            }
            else if (head_id == SF_HEADER_ID)
            {
                QByteArray cmd = recvBuffer;
                recvBuffer.clear();

                emit soft_cmd_data(cmd);
                break;   // 等待下一次网络数据
            }
            else
            {
                if (recvBuffer.isEmpty())
                    break;

                quint8 len = static_cast<quint8>(recvBuffer.at(0));

                if (len > 0 && recvBuffer.size() >= len)
                {
                    QByteArray boardCmd = recvBuffer.left(len);
                    recvBuffer.remove(0, len);

                    emit board_cmd_data(boardCmd);
                    continue;
                }
                else
                {
                    recvBuffer.remove(0, 1);
                    continue;
                }
            }
        }
    }

    closeSocket();
    emit serverStarted(false);
}

void Tcp_Cmd_RecvThread::sendCommandToHost(const QByteArray &data)
{
    if (!socket || data.isEmpty())
    {
        qWarning() << "[Tcp_Cmd] socket invalid or empty data";
        return;
    }

    if (socket->state() != QAbstractSocket::ConnectedState)
    {
        qWarning() << "[Tcp_Cmd] socket not connected";
        return;
    }

    qint64 totalSent = 0;
    const char* ptr = data.constData();
    qint64 totalLen = data.size();

    /* TCP write 可能一次没写完，循环保证发送完成 */
    while (totalSent < totalLen)
    {
        qint64 sent = socket->write(ptr + totalSent, totalLen - totalSent);
        if (sent < 0)
        {
            qWarning() << "[Tcp_Cmd] write failed:" << socket->errorString();
            return;
        }

        totalSent += sent;

        if (!socket->waitForBytesWritten(1000))
        {
            qWarning() << "[Tcp_Cmd] waitForBytesWritten timeout";
            return;
        }
    }

    qDebug() << "[Tcp_Cmd] Sent" << totalSent << "bytes";
}
