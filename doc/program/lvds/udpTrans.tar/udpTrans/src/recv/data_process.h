#ifndef DATA_PROCESS_H
#define DATA_PROCESS_H

#include "opencv2/opencv.hpp"
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/objdetect/objdetect.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <QDebug>
#include <QPixmap>
#include <QImage>

using namespace cv;

QImage cvMat2QImage(const Mat& mat);
Mat QImage2cvMat(QImage image);

#endif // DATA_PROCESS_H
