#ifndef BUFQUEUE_H
#define BUFQUEUE_H

#include <QObject>
#include <QMutex>
#include <QMutexLocker>
#include <QList>

class BufQueue : public QObject
{

public:
    static BufQueue* getInstance();

    void inQueue(char* buf);

    void outQueue(QList<char *> &buflist);

private:
    explicit BufQueue(QObject *parent = nullptr);

    ~BufQueue();

    QMutex mutex;

    QList<char*> cache;

    // 禁止拷贝构造和赋值
    BufQueue(const BufQueue&) = delete;
    BufQueue& operator=(const BufQueue&) = delete;

signals:

public slots:
};

#endif // BUFQUEUE_H
