#ifndef TCP_CMD_RECVTHREAD_H
#define TCP_CMD_RECVTHREAD_H

#include <QThread>
#include <QTcpSocket>
#include <QByteArray>
#include <QMutex>

class Tcp_Cmd_RecvThread : public QThread
{
    Q_OBJECT
public:
    explicit Tcp_Cmd_RecvThread(QObject *parent = nullptr);
    ~Tcp_Cmd_RecvThread();

    void setServer(const QString &ip, int port);
    void startReceiver();
    void stopReceiver();
    void sendCommandToHost(const QByteArray &data);

signals:
    void serverStarted(bool ok);
    void soft_cmd_data(const QByteArray &data);
    void board_cmd_data(const QByteArray &data);

protected:
    void run() override;

private:
    void closeSocket();
    void processRecvBuffer();

private:
    QMutex m_lock;
    QTcpSocket *socket = nullptr;
    QString serverIp;
    int serverPort = 0;
    bool bwork = false;

    QByteArray recvBuffer;   // TCP 接收缓存
};

#endif // TCP_CMD_RECVTHREAD_H
