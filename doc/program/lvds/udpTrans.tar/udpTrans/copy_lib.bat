@echo off

:: 设置路径变量
set EXE_DIR=%~dp0
set DEST=%EXE_DIR%exe
set OPENCV_DLL=D:\opencv\install\x64\mingw\bin
set MINGW_DLL=D:\Qt\Tools\mingw530_32\bin

:: 拷贝 OpenCV DLL
echo Copying OpenCV DLLs...
copy /Y "%OPENCV_DLL%\libopencv_core460.dll" "%DEST%"
copy /Y "%OPENCV_DLL%\libopencv_imgproc460.dll" "%DEST%"
::copy /Y "%OPENCV_DLL%\libopencv_highgui460.dll" "%DEST%"
::copy /Y "%OPENCV_DLL%\libopencv_imgcodecs460.dll" "%DEST%"
::copy /Y "%OPENCV_DLL%\libopencv_videoio460.dll" "%DEST%"
::copy /Y "%OPENCV_DLL%\opencv_videoio_ffmpeg460.dll" "%DEST%"

:: 拷贝 MinGW 的 OpenMP 运行库
echo Copying libgomp-1.dll...
copy /Y "%MINGW_DLL%\libgomp-1.dll" "%DEST%"

:: 打开目标文件夹
echo Done.
start "" "%DEST%"
pause
