TEMPLATE = subdirs
CONFIG += ordered

SUBDIRS += \
    src/recv

CONFIG += utf8

